# 3D Shafts

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Visuals** panel → **3D Shafts**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**3D Shafts** shows every **Shaft Opening** in your model as a **coloured, see-through 3D volume** in a 3D view.

Shafts are coloured by their **Shaft Function** parameter (e.g. *Electrical*, *Plumbing*, *HVAC*). Each function gets its own colour, which you can change.

The coloured volumes are a **temporary overlay**. Nothing is added to the model. The overlay **follows your edits live** and disappears when you close the window.

> 💡 Think of it as switching on X-ray vision for shafts: you see every riser through the building, colour-coded by what runs inside.

📸 *[Screenshot: a 3D view with shafts coloured by function]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change your model | No elements, no transactions, no view overrides. Nothing to undo. |
| Draw in plans, sections or sheets | The overlay only shows in **3D views**. |
| Make the volumes selectable | You can't click, tag or measure them. |
| Keep the overlay after you close the window | Close the window and it's gone. |
| Print or export the overlay | Screen only. *(Screenshots work.)* |
| Show shafts from linked models | Only the model you're working in. |
| Fill in Shaft Function for you | Shafts without a value are grouped as **(Undefined)**. |

---

## 3. Before you start

- [ ] A model with **Shaft Openings** is open.
- [ ] A **3D view** is active (or you'll switch to one).
- [ ] *(Recommended)* Your shafts have a **Shaft Function** value. Otherwise they all show as **(Undefined)**.

---

## 4. How to use it

1. Activate a **3D view**.
2. Click **3D Shafts** on the Visuals panel.
3. The **3D Shafts - Live Visualizer** window opens. Shafts appear in the 3D view straight away. ✅
4. Each **Shaft Function** has a row with a tick box, a colour swatch, its name and **"_ shafts"**.
5. Adjust colours, visibility and transparency as you like (see below).
6. Leave the window open while you work. **Edits to shafts update the overlay live.**
7. Click **Close** when you're done. The overlay disappears.

📸 *[Screenshot: the 3D Shafts - Live Visualizer window]*

### Window controls

| Control | What it does |
|---|---|
| **Status line** (top) | What's being drawn, e.g. **"Drawing 42 of 57 shafts in [3D - Shafts]"**. |
| **Filter box** | Narrows the function list as you type. |
| **Function rows** | **Tick box** = show/hide that function. **Swatch** = its colour. |
| **Double-click a row** | Opens the colour window for that function. |
| **Change Color** | Opens the colour window for the **selected** row. |
| **Show All** / **Hide All** | Shows or hides every function. |
| **Reset Palette** | Gives every function a default colour again. |
| **Transparency** slider | 0% = solid, 100% = fully see-through, in steps of 5. Default **50%**. Outlines stay stronger than the fill. |
| **Selected shafts only** | When ticked, only the shafts you've **selected in Revit** are drawn. Select others and the overlay follows. |
| **Refresh** | Re-reads all shafts from the model and redraws. |
| **Close** | Closes the window and removes the overlay. |
| **Banner** (bottom) | Warnings or errors, e.g. **"Select a function row first."** |

---

## 5. Live updates and saving

- **Editing shafts** (sketch, height, Shaft Function), **adding** or **deleting** them updates the overlay by itself.
- **Moving a level** redraws all shafts.
- **Switching to another 3D view** keeps drawing. Switching to a non-3D view hides the overlay until you come back to 3D.
- **Switching to another open model** reloads that model's shafts.
- **Colours** (per Shaft Function name) and **transparency** are saved **on your computer** when you close the window. They come back next time, in any model.
- **Clicking the button again** while the window is open just brings the window to the front.

---

## 6. How shafts are drawn

Each shaft is drawn by taking its **sketch outline** and extruding it straight up by the shaft's **height**.

> ⚠️ A shaft whose sketch can't be read as **one closed outline** (e.g. a sketch with several separate loops) is **not drawn**. It's still counted in the status line.

> ⚠️ Shafts with **no height** are not drawn.

---

## 7. Undoing

Nothing to undo. The tool never changes the model.

To remove the overlay, click **Close**.

---

## 8. Messages you may see

### 🟡 "Activate a 3D View to see the overlay."
**Why:** The active view isn't a 3D view.
**What to do:** Switch to a 3D view. The window can stay open.

### 🟡 "No Shaft Openings found in this model."
**Why:** The model has no shafts.
**What to do:** Nothing, or open the right model.

### 🔵 "Drawing _ of _ shafts in [view]"
**Why:** Normal status. Hidden functions and (with **Selected shafts only**) unselected shafts aren't drawn.
**What to do:** Nothing.

### 🟡 "_ shafts in this model. Use the filter or 'Selected shafts only' to keep it responsive."
**Why:** The model has more than 1,500 shafts. Drawing them all can be slow.
**What to do:** Hide functions you don't need, or tick **Selected shafts only**.

### 🟡 "Select a function row first."
**Why:** You clicked **Change Color** without selecting a row.
**What to do:** Click a row, then **Change Color** (or double-click the row).

### 🔴 "Rebuild failed: …" / "Color change failed: …" / "Toggle failed: …" / "Reset failed: …" / "Could not read the active view: …"
**Why:** Something unexpected happened.
**What to do:** Click **Refresh**. If it repeats, close and reopen the tool. Still failing? Screenshot it and contact the author.

---

## 9. FAQ

**Does this add anything to my model?**
No. Nothing is created, and nothing goes into the Undo list.

**Why are all my shafts "(Undefined)"?**
They have no **Shaft Function** value, or the model has no parameter with that exact name.

**Why is a shaft missing in 3D?**
Its function may be hidden, **Selected shafts only** may be ticked, or its sketch/height couldn't be drawn (see [Section 6](#6-how-shafts-are-drawn)).

**Are my colours shared with colleagues?**
No. They're saved on your computer.

**Why does a colour in 3D look different from its swatch?**
Transparency and Revit's lighting change how colours look. If a colour is clearly **wrong** (e.g. red shows as blue), tell the author.

**Can I keep working while the window is open?**
Yes. That's the point: the overlay follows your edits.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Nothing drawn | Not in a 3D view, or all functions hidden | Switch to 3D. Click **Show All**. | ❌ |
| Only some shafts drawn | **Selected shafts only** is ticked | Untick it | ❌ |
| One shaft never draws | Sketch has several loops, or no height | Check its sketch and height | ✅ If it looks normal |
| Overlay out of date | Change not picked up | **Refresh** | ✅ If it repeats |
| Overlay stays after closing | Screen not refreshed | Orbit or switch views | ✅ If it stays |
| Colours look swapped (red ↔ blue) | Display issue | Screenshot the swatch and the 3D view | ✅ |
| Slow with many shafts | Large model | Hide functions or use **Selected shafts only** | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window (status line and banner) and of the 3D view
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **3D view** you were in
4. The **IDs** of shafts that misbehave, if you can
5. **What you expected**, and what actually happened
