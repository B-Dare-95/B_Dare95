# Colorize Elements

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Visuals** panel → **Colorize Elements**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Colorize Elements** colours the elements in your **active view** by the value of a parameter. For example: colour all walls by *Fire Rating*, all doors by *Type*, all pipes by *System Type*.

You pick a **category** and a **parameter**. The tool lists every value it finds, gives each value a colour, and applies them to the view.

There are **two modes**:

| Mode | How it colours | Best for |
|---|---|---|
| **By View Filter** *(default)* | Creates one **view filter** per value (named `WPC_…`) and adds it to the view with that colour. | Colours that **stay correct** when elements change or new ones are added. Works with view templates (if released, see below). |
| **By Graphic Override** | Colours **each element** directly in the view (like *Override Graphics in View → By Element*). | Quick one-off colouring, or categories that don't support filters. |

> 💡 Think of it as a highlighter set: one colour per value, applied to the whole view in one go.

📸 *[Screenshot: a plan with walls coloured by Fire Rating]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change element data | Parameters stay as they are. Only the **view's graphics** change. |
| Colour other views | Only the view that was **active when you opened the tool**. |
| Colour elements hidden in the view | Values and elements come from what the view **shows**. |
| Colour linked models | Only elements in the model you're working in. |
| Colour annotation | Only **model** categories are listed. |
| Add filters to a view whose template controls filters | **By View Filter** stops and tells you (see [Section 7](#7-view-templates)). |
| Show a legend | Make one yourself if you need it. |

---

## 3. Before you start

- [ ] The view you want to colour is **active** before you click the button.
- [ ] The elements are **visible** in that view.
- [ ] *(By View Filter)* The view has **no template**, or its template **doesn't control V/G Overrides Filters**.
- [ ] *(By Graphic Override)* You're OK with any **existing element overrides** on that category in this view being replaced (see [Section 6](#6-modes-in-detail)).

---

## 4. How to use it

1. Open the view you want to colour.
2. Click **Colorize Elements** on the Visuals panel.
3. The **Universal Element Colorizer** window opens. Top right shows **Active view: \<name\>**.
4. Under **MODE**, choose **By View Filter** or **By Graphic Override**.
5. Pick a **CATEGORY** on the left (use the search box to find it).
6. Choose **Instance** or **Type** parameters, then pick a **PARAMETER**.
7. Every value appears on the right under **COLOUR ASSIGNMENTS**, each with its own colours.
8. *(Optional)* Change colours, switch values **OFF**, and choose **OVERRIDE TARGETS** (see below).
9. Click **Apply**.
10. A **Done** message confirms what was applied. ✅
11. The window stays open. Pick another parameter or category and **Apply** again, or click **Close**.

📸 *[Screenshot: the Universal Element Colorizer window]*

### Window controls — left side

| Control | What it does |
|---|---|
| **MODE: By View Filter / By Graphic Override** | Chooses how colours are applied. One is always selected. |
| **TEMPLATE: \<name\>** badge (top right) | Shown if the view has a template. **Red** = the template controls filters, so **By View Filter** won't work on this view. |
| **Search categories...** | Narrows the category list. |
| **CATEGORY** list | Model categories. Picking one loads the elements of that category **in the active view**. |
| **Instance / Type** | Lists instance parameters, or type parameters. |
| **Search parameters...** | Narrows the parameter list. |
| **PARAMETER** list | Picking one fills the value list on the right. |

### Window controls — right side

| Control | What it does |
|---|---|
| **VALUE** | Each distinct value found. Special values: **\<No Value\>**, **\<Empty\>** (blank text), **\<None\>** (no element chosen). |
| **N** | How many elements have that value. *(With **Type**, it counts types, not instances.)* |
| **SURF / CUT / PROJ / LINE** swatches | Four colours per value: surface pattern, cut pattern, projection lines, cut lines. Click one to pick a colour. |
| **Sync colours** *(on by default)* | One pick fills all four swatches of that row. Untick it to colour each channel separately. |
| **Re-roll colours** | Gives every value a different set of default colours. |
| **All ON / All OFF** | Switches every value on or off. |
| **ON / OFF** pill | **OFF** = that value is not coloured. |
| **OVERRIDE TARGETS** | What gets coloured (see next table). Swatches for channels you don't use are dimmed. |
| **Weight** | Line weight **1–16** for projection/cut lines. Blank = keep current weight. |
| **Status line** (bottom left) | E.g. **"Walls: 120 element(s) in view, 85 parameter(s)."** |
| **Apply** | Colours the view. |
| **Remove Filters** / **Reset Overrides** | Undoes the tool's colouring in this view (label depends on mode). See [Section 8](#8-removing-the-colours). |
| **Close** | Closes the window. Colours stay. |

### OVERRIDE TARGETS

| Row | Option | Colour used | Default |
|---|---|---|---|
| **SURFACE** | Foreground pattern / Background pattern | **SURF** swatch, solid fill | Foreground ✅ |
| **CUT** | Foreground pattern / Background pattern | **CUT** swatch, solid fill | Foreground ✅ |
| **LINES** | Projection lines | **PROJ** swatch | ❌ |
| **LINES** | Cut lines | **LINE** swatch | ❌ |

---

## 5. About values

- Values come from the elements **visible in the active view** at the moment you pick the category.
- Text is shown as typed. Element values (e.g. Level, Material) show the element's name.
- ⚠️ **Numbers are shown in Revit's internal form**, not your project units: lengths and areas appear in **feet / square feet** (e.g. `3.2808` for 1000 mm), and Yes/No parameters appear as **1** / **0**.
- Values are listed alphabetically.

---

## 6. Modes in detail

### By View Filter

- One filter per value is created in the model, named **`WPC_<Category>_<Parameter>_<Value>`** (special characters become `_`).
- The filter is added to the active view with your colours and turned visible.
- If a filter with that name **already exists** (e.g. from another view), it's **reused** and its rule is updated. Its colours in **other** views don't change.
- New or changed elements pick up the right colour automatically, because filters are rules, not one-off paint.
- Some categories or parameters can't be used in filters. Those values are **skipped**, and the message says so.

### By Graphic Override

- Every element of the chosen category **in the view** first has its element overrides **cleared**, then gets the colour of its value.
- ⚠️ Any overrides you had set by hand on those elements in this view are **lost**.
- Elements added later are **not** coloured. Run **Apply** again.

---

## 7. View templates

If the active view uses a **view template** that controls **V/G Overrides Filters**, Revit won't let anyone add or remove filters on the view.

- The badge **TEMPLATE: \<name\>** turns **red** when you open the tool.
- In **By View Filter** mode, **Apply** and **Remove Filters** stop and show **"View Template Detected"**. Nothing is created.
- **By Graphic Override** still works.

**To use filters on such a view:** edit the filters on the template itself, release **Filters** from the template, or remove the template from the view. Then run the tool again.

---

## 8. Removing the colours

| Mode | Button | What it does |
|---|---|---|
| **By View Filter** | **Remove Filters** | Finds every filter starting with **`WPC_`** on the active view, removes it from the view **and deletes it from the model**. |
| **By Graphic Override** | **Reset Overrides** | Clears element overrides on every element of the **currently chosen category** in the view. |
| — | **Shift + click** the ribbon button | Same as **Remove Filters**, without opening the window and without a message. |

> ⚠️ **Remove Filters deletes the `WPC_` filters from the whole model.** If another view (or view template) uses the same `WPC_` filters, they disappear there too.

---

## 9. Undoing

Every **Apply** or **Remove** is **one** step in Revit's Undo list:

| Action | Name in the Undo list |
|---|---|
| Apply, By View Filter | **Filter Colorize: \<Category\> - \<Parameter\>** |
| Apply, By Graphic Override | **Override Colorize: \<Category\> - \<Parameter\>** |
| Remove Filters | **Remove WPC_ View Filters** |
| Reset Overrides | **Reset Element Overrides** |
| Shift + click | **Remove WPC_ Filters (config)** |

Press **Ctrl + Z** once to reverse the last one.

---

## 10. Messages you may see

### 🟢 "Applied _ view filter(s) for '_' on view '_'." *(title: Done)*
**Why:** Filters were applied. If some values couldn't be filtered, a **Skipped** list follows (up to 10), and possibly **"Note: this category may have limited filter support. First error: …"**.
**What to do:** For skipped values, try **By Graphic Override**.

### 🟡 "Applied 0 view filter(s) …" *(title: Nothing Applied)*
**Why:** No value could be turned into a filter.
**What to do:** Use **By Graphic Override** for this category/parameter.

### 🟢 "Applied overrides to _ of _ element(s)." *(title: Done)*
**Why:** Override mode finished. The first number is how many got a colour.
**What to do:** Nothing. Elements whose value is switched **OFF** (or that lack the parameter) are left uncoloured.

### 🟡 "View Template Detected"
**Why:** The view's template controls filters. Nothing was created or removed.
**What to do:** See [Section 7](#7-view-templates), or switch to **By Graphic Override**.

### 🟡 "No elements found in the active view for this category." *(Nothing to Colorize)*
**Why:** The category has no visible elements in this view.
**What to do:** Pick another category, or open a view where they're visible.

### 🟡 "Please select a parameter from the list." *(No Parameter Selected)*
**What to do:** Pick a parameter.

### 🟡 "No values to colorize." / "Every value is switched OFF - nothing to apply." *(Nothing to Colorize)*
**What to do:** Pick a parameter with values, or switch some values **ON**.

### 🟡 "Tick at least one override target (surface, cut or lines)." *(No Target Selected)*
**What to do:** Tick at least one box under **OVERRIDE TARGETS**.

### 🟡 "Line weight must be a whole number between 1 and 16, or left blank to keep the current weight." *(Invalid Line Weight)*
**What to do:** Fix the **Weight** box or clear it.

### 🔴 "No solid fill pattern found in the document, so pattern overrides cannot be applied." *(Missing Pattern)*
**Why:** The model has no solid fill pattern.
**What to do:** Use line targets only, or ask your BIM manager to add a solid fill pattern.

### 🟢 "Removed _ WPC_ filter(s) from '_'." *(Done)*
**Why:** Remove Filters worked.

### 🟡 "No WPC_ filters found on '_'." *(Nothing to Remove)*
**Why:** The view has no tool filters.

### 🟢 "Overrides cleared for _ element(s)." *(Done)*
**Why:** Reset Overrides worked.

### 🟡 "No elements loaded. Select a category first." *(Nothing to Reset)*
**What to do:** Pick the category whose overrides you want to clear, then click **Reset Overrides**.

### 🔴 "Could not find a parameter definition for '_'." or any other *Error* message
**Why:** Something unexpected happened. Nothing from that action was applied.
**What to do:** Screenshot it and contact the author.

---

## 11. FAQ

**Which mode should I use?**
**By View Filter** for views you'll keep (the colours stay right as the model changes). **By Graphic Override** for a quick check, or when filters aren't supported.

**I applied colours twice with different values. Why are old colours still there?**
In filter mode, old `WPC_` filters stay on the view. Click **Remove Filters** first, then **Apply**.

**Why are my lengths showing as strange decimals?**
They're in **feet**, Revit's internal unit. `3.2808` = 1000 mm.

**Does the tool follow me if I switch views?**
No. It works on the view that was active when you opened it. Close it and reopen in the new view.

**Can I colour several categories?**
Yes, one after another. Pick a category, Apply, pick the next, Apply.

**What does "Re-roll colours" do?**
It gives every value a different default colour. Click a swatch if you want a specific colour.

**Will Remove Filters delete filters I made myself?**
Only if their name starts with **WPC_**.

---

## 12. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Category has no parameters | No elements of it visible in the view | Pick another category or view | ❌ |
| Some values "Skipped" | Category/parameter not supported by filters | Use **By Graphic Override** | ❌ |
| "View Template Detected" | Template controls filters | See [Section 7](#7-view-templates) | ❌ |
| Colours don't show | Target not suitable for the view (e.g. cut pattern in a 3D view) or Visual Style | Tick **Foreground pattern** under **SURFACE**. Check the view's visual style. | ❌ |
| My manual overrides vanished | **By Graphic Override** clears them first | **Ctrl + Z** | ❌ |
| Filters vanished in another view | **Remove Filters** deleted shared `WPC_` filters | **Ctrl + Z**, or re-apply in that view | ❌ |
| Value list shows numbers in feet | Values shown in internal units | See [Section 5](#5-about-values) | ❌ |
| Red error dialog or pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 13. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. The **mode**, **category**, **parameter** and **override targets** you used
2. A **screenshot** of the window and of any message
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **view** and its **view template** (if any)
5. **What you expected**, and what actually happened
