# Ghost Mode

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Visuals** panel → **Ghost Model** (toggle button)
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Ghost Mode** turns the **active view** see-through with one click, and back again with a second click.

| Click | What happens to the active view |
|---|---|
| **1st click — Ghost ON** | Every category becomes **95% transparent**, the visual style switches to **Shaded**, and the **Lines** category (model/detail lines) is hidden. |
| **2nd click — Ghost OFF** | All category overrides in the view are **cleared**, the visual style switches to **Shaded with Edges**, and **Lines** are shown again. |

The button icon changes each time you click, so you can see it's a toggle.

> 💡 Think of it as frosted glass: you can see through the whole building to find what's hidden inside, then switch back to solid.

📸 *[Screenshot: a 3D view before and after Ghost ON]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change elements | Only the **view's graphics** change. |
| Work on views with a view template | It stops and asks you to remove the template first. |
| Remember the state per view | The ON/OFF state is **one switch for you**, across all views and models (see [Section 5](#5-how-the-toggle-remembers)). |
| Restore your previous view settings | **OFF** resets to defaults. It doesn't bring back what you had before. |
| Affect other views | Only the active view. |

---

## 3. Before you start

- [ ] The view you want to ghost is **active**.
- [ ] The view has **no view template** (View Properties → View Template = *\<None\>*).
- [ ] ⚠️ The view has **no category overrides you want to keep**. Turning Ghost **OFF** clears **all** of them, including ones you set yourself.
- [ ] You know the view's current **visual style**. Turning Ghost **OFF** sets it to **Shaded with Edges**, whatever it was before.

---

## 4. How to use it

### Turn Ghost ON

1. Open the view (3D views work best).
2. Click **Ghost Model** on the Visuals panel.
3. The view turns see-through. ✅

### Turn Ghost OFF

1. Stay in the **same view**.
2. Click **Ghost Model** again.
3. The view returns to **Shaded with Edges** with no category overrides. ✅

> 💡 **Tip:** If you want to keep your own view settings, ghost a **duplicate** of the view instead of the original.

---

## 5. How the toggle remembers

The tool remembers **one** ON/OFF state **for you**, saved on your computer. It does **not** check the view.

That means:

- If you turn Ghost **ON** in view A, then click the button in view B, it turns Ghost **OFF** in view B (clearing B's category overrides), even though B was never ghosted.
- After **Undo**, the remembered state doesn't change. The next click may do the opposite of what you expect.

**If the button does the "wrong" thing:** just click it **once more**. Each click flips between ON and OFF.

---

## 6. Undoing

Each click is **one** step in Revit's Undo list:

| Click | Name in the Undo list |
|---|---|
| Ghost ON | **Ghost Model - ON** |
| Ghost OFF | **Ghost Model - OFF** |

Press **Ctrl + Z** to reverse it. Undo after Ghost **OFF** brings back the overrides that were in the view before.

> ⚠️ Undo doesn't flip the button's remembered state. See [Section 5](#5-how-the-toggle-remembers).

---

## 7. Messages you may see

### 🟡 "This View has a View Template. Please turn it off first." *(title: Error)*
**Why:** The active view uses a view template. Nothing was changed, and the toggle state didn't flip.
**What to do:** Set the view's **View Template** to *\<None\>* (or ghost a duplicate without a template), then click again.

### 🔴 "Failed to apply Ghost Mode: …" / "Failed to reset Ghost Mode: …" *(title: Ghost Model Error)*
**Why:** Revit refused the change. The view is unchanged, **but** the toggle state has already flipped.
**What to do:** Click the button again to try once more. If it repeats, screenshot it and contact the author.

### 🔵 "Could not set DisplayStyle: …" (in a pyRevit output window)
**Why:** This view type doesn't have a visual style (e.g. some 2D views). The rest still runs.
**What to do:** Nothing. Ghost Mode is meant mainly for 3D views.

---

## 8. FAQ

**Which views does it work in?**
Any view without a template. It's most useful in **3D views**.

**I turned Ghost OFF and my view looks different from before.**
OFF resets the view to **Shaded with Edges** and clears **all** category overrides. Use **Ctrl + Z** to get the previous look back.

**Why did my model lines disappear?**
Ghost **ON** hides the **Lines** category. Ghost **OFF** shows it again.

**I clicked the button in a new view and nothing went see-through.**
The button thought Ghost was ON (from another view) and turned it OFF. Click once more.

**Does it affect my colleagues?**
Only through the view itself, if they open the same view in a shared model. The ON/OFF memory is yours alone.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| "This View has a View Template…" | View uses a template | Remove the template, or use a duplicate view | ❌ |
| First click turned it OFF instead of ON | Toggle state from another view or after Undo | Click once more | ❌ |
| My V/G overrides are gone | Ghost OFF clears all category overrides | **Ctrl + Z** | ❌ |
| Visual style changed | Ghost ON/OFF set it | Set it back in the View Control Bar | ❌ |
| Lines missing | Ghost is ON in this view | Turn Ghost OFF | ❌ |
| "Ghost Model Error" | Revit refused the change | Click again | ✅ If it repeats |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. Whether you were turning Ghost **ON** or **OFF**
2. A **screenshot** of the view and of any message
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **view** (and its type, e.g. 3D, plan)
5. **What you expected**, and what actually happened
