# 3D Rooms

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Visuals** panel → **3D Rooms**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**3D Rooms** shows your rooms as **coloured, see-through 3D volumes** in a 3D view.

You group rooms into **Sets** (e.g. *Apartments*, *Corridors*, *Wet areas*) and give each Set a colour. Every room in a visible Set is drawn in that colour.

The coloured volumes are a **temporary overlay**. They are **not** added to the model, can't be selected, and disappear as soon as you close the window.

> 💡 Think of it as laying coloured glass blocks over your model to explain the layout, then lifting them off again without leaving a trace.

📸 *[Screenshot: a 3D view with rooms drawn in three Set colours]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change your model | No elements, no transactions, nothing in the Undo list. |
| Draw in plans, sections or sheets | The overlay only shows in **3D views**. |
| Make the volumes selectable | You can't click, tag or measure them. |
| Keep the overlay after you close the window | Close the window and the volumes disappear. |
| Print or export the overlay | It's a screen overlay only. *(Screenshots work.)* |
| Show unplaced or zero-area rooms | Rooms with no area aren't listed. |
| Show rooms from linked models | Only rooms in the model you're working in. |
| Put a room in two Sets | Each room belongs to **one** Set at most. Adding it to another Set moves it. |
| Share your Sets with colleagues | Sets are saved **on your computer**, not in the model. |

---

## 3. Before you start

- [ ] A model **with placed rooms** is open.
- [ ] A **3D view** is active (or you'll switch to one).
- [ ] Rooms are **bounded** properly. Rooms with no geometry are skipped.

---

## 4. How to use it

1. Click **3D Rooms** on the Visuals panel.
2. The **3D Room Visualization - Sets** window opens. Your rooms are listed on the left as **"Number - Name"**.
3. **Tick** the rooms you want in your first Set. Use the search box to find them quickly.
4. Click **New Set from Checked Rooms**.
5. Type a **name** (default *Set 1*) and confirm.
6. Pick a **colour** in the colour window and click **OK**. *(Cancel keeps a suggested colour.)*
7. The rooms are drawn in the 3D view in that colour. Their rows in the list turn that colour too. ✅
8. Repeat steps 3–6 for more Sets.
9. Leave the window open while you look around. **You can keep working in Revit.**
10. Click **Close** when you're done. The overlay disappears.

📸 *[Screenshot: the 3D Room Visualization - Sets window]*

### Window controls — left side (ROOMS)

| Control | What it does |
|---|---|
| **Search box** ("Search rooms...") | Narrows the room list as you type (number or name). |
| **Room list** | Tick rooms here. Rows already in a Set are filled with the Set colour and show **[Set name]**. |
| **Check All** | Ticks every room **currently shown**. Combine with search: type `WC`, then **Check All**. |
| **Uncheck All** | Unticks **every** room, including ones hidden by the search. |
| **"_ checked \| _ of _ in a Set"** | How many rooms are ticked, and how many are already in a Set. |

### Window controls — right side (SETS)

| Control | What it does |
|---|---|
| **Sets list** | Each Set shows a **tick box** (visible / hidden), a colour swatch, its name and **(_ rooms)**. Click a Set to select it. |
| **New Set from Checked Rooms** | Creates a Set from the ticked rooms. Unticks all rooms afterwards. |
| **Rename** | Renames the selected Set. |
| **Color** | Opens the colour window for the selected Set. |
| **Delete** | Deletes the selected Set (asks first). The rooms are untouched. |
| **Add Checked** | Adds the ticked rooms to the selected Set. Rooms in another Set are **moved**. |
| **Remove Checked** | Takes the ticked rooms out of the selected Set. |
| **Check This Set's Rooms** | Ticks exactly the rooms in the selected Set. Handy before **Remove Checked**. |
| **TRANSPARENCY** slider | 0% = solid, 100% = fully see-through. Default **25%**. Room outlines stay a bit stronger than the fill. |
| **Status box** | Tells you what happened and what's drawn (see [Section 8](#8-messages-you-may-see)). |
| **Reload Rooms** | Re-reads all rooms from the model and redraws. |
| **Close** | Closes the window and removes the overlay. |

---

## 5. Working with Sets

### Moving rooms between Sets

1. Select the **target** Set in the Sets list.
2. Tick the rooms you want to move.
3. Click **Add Checked**. The status says **"Added _ room(s) to [Set]. _ moved out of another Set."**

### Hiding a Set for a moment

Untick the box in front of the Set. Its rooms are no longer drawn. Tick it again to bring them back.

### Editing a Set's rooms

1. Select the Set.
2. Click **Check This Set's Rooms**.
3. Untick rooms you want to keep, leaving only the ones to remove ticked. Then click **Remove Checked**.

> 💡 Removed rooms are **not deleted**. They just aren't drawn any more.

---

## 6. Live updates and saving

- **Model changes:** When you edit, add, place or delete rooms, the overlay and the list update by themselves. If something looks out of date, click **Reload Rooms**.
- **Deleted rooms** are removed from their Set automatically.
- **Switching models:** Activating a view in another open model loads that model's rooms and Sets.
- **Saving:** Sets (name, colour, rooms, visible/hidden) and the transparency are saved **automatically on your computer**, per model. They come back the next time you open the tool on that model.
- **Clicking the button again** while the window is open just brings the window to the front.

---

## 7. Undoing

Nothing to undo. The tool never changes the model.

- To get rid of the overlay: click **Close**.
- To remove a Set: select it and click **Delete**.

---

## 8. Messages you may see

### 🟡 "No placed rooms found in the active document."
**Why:** The model has no rooms with an area.
**What to do:** Place rooms first, or open the right model.

### 🟡 "Active view is not 3D. The overlay only renders in 3D views."
**Why:** You're in a plan, section, sheet, etc.
**What to do:** Switch to a 3D view. The window can stay open.

### 🟡 "No Sets yet. Check rooms on the left, then 'New Set from Checked Rooms'."
**Why:** You haven't created any Sets for this model.
**What to do:** Follow [Section 4](#4-how-to-use-it).

### 🟡 "Select a Set in the list first."
**Why:** You clicked Rename, Color, Delete, Add, Remove or Check This Set's Rooms with no Set selected.
**What to do:** Click a Set in the list, then try again.

### 🟡 "Check some rooms first, then create a Set." / "Check the rooms you want to add first." / "Check the rooms you want to remove first."
**Why:** No rooms are ticked.
**What to do:** Tick the rooms first.

### 🟡 "Delete the Set [_]? _ room(s) will become unassigned and stop being drawn. The rooms themselves are untouched."
**Why:** You clicked **Delete**.
**What to do:** **Yes** deletes the Set. **No** keeps it.

### 🟢 "Created [_] with _ room(s). Selection cleared." · "Renamed [_] to [_]." · "[_] is now #RRGGBB." · "Deleted [_]." · "Added _ room(s) to [_]." · "Removed _ room(s) from [_]." · "Checked the _ room(s) in [_]."
**Why:** Your action worked.
**What to do:** Nothing.

### 🔵 "_ room(s) drawn across _ Set(s)." (+ "_ Set(s) hidden." / "_ skipped (no geometry).")
**Why:** Summary after every redraw. **Skipped** rooms have no usable 3D shape (e.g. not properly bounded).
**What to do:** Check skipped rooms in a plan.

### 🔵 "Geometry is view-only: not selectable, not in the model."
**Why:** Always shown as a reminder.
**What to do:** Nothing.

### 🔴 "Reload failed: …" / "Error: …"
**Why:** Something unexpected happened while reading or drawing rooms.
**What to do:** Click **Reload Rooms**. If it repeats, close and reopen the tool. Still failing? Screenshot it and contact the author.

---

## 9. FAQ

**Does this add anything to my model?**
No. No elements, no worksets, no Undo entries.

**Can my colleague see my Sets?**
No. Sets are saved on **your** computer. Each person builds their own.

**Can I print the coloured rooms?**
No. The overlay is screen-only. Take a screenshot instead.

**Why isn't a room in the list?**
Rooms with no area (unplaced, not enclosed, redundant) aren't listed. Fix the room, then click **Reload Rooms**.

**Why does a room show in the list but not in 3D?**
Its Set may be hidden (unticked), or the room has no usable 3D shape (shown as **skipped**).

**Why did the colour in 3D look different from the swatch?**
Transparency and Revit's lighting change how colours look. If a colour looks clearly **wrong** (e.g. red appears blue), tell the author.

**Can I keep working while the window is open?**
Yes. The window doesn't block Revit.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Nothing drawn | Not in a 3D view, no Sets, or all Sets hidden | Switch to 3D. Create or tick a Set. | ❌ |
| A room isn't drawn | Set hidden, or room skipped (no geometry) | Tick the Set. Check the room's boundaries. | ❌ |
| A room is missing from the list | Room has no area | Place/enclose it, then **Reload Rooms** | ❌ |
| Overlay out of date | Change not picked up | **Reload Rooms** | ✅ If it repeats |
| Overlay stays after closing | Screen not refreshed | Orbit or switch views | ✅ If it stays |
| Colours look swapped (red ↔ blue) | Display issue | Screenshot the swatch and the 3D view | ✅ |
| Sets gone after reopening | Different computer, or model saved under a new name/path | Sets are stored per computer and per model file | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window (including the status box) and of the 3D view
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **3D view** you were in
4. The **room numbers** that misbehave
5. **What you expected**, and what actually happened
