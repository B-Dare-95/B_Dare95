# Quick Reports

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **QoL** panel → **Quick Reports** (dropdown)
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🏷️ **Versions:** Parking Count Lister 1.0.0 · Room Area Lister 1.0.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Quick Reports** gives you instant counts and lists from the open model, with **one click** and **no settings**. Each report opens in a pyRevit output window.

The dropdown has **four reports**:

| Report (as shown in the dropdown) | What you get |
|---|---|
| **Items on Levels** | How many model elements sit on each level, broken down by category. Click links to select them. |
| **Parking Count Lister** | Every parking type used, how many of each, and the percentage of the total. |
| **Room Area Lister** | Every room with its name and area. Click a line to select that room. |
| **Workset Counter** | Every workset with its creator, owner, open/closed state and how many elements it holds, by category. |

> 💡 Think of these as quick "health checks" you can run before a meeting, without building a schedule.

📸 *[Screenshot: the Quick Reports dropdown open]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change your model | All four reports only read. Nothing to undo. |
| Look inside linked models | Only the model you're working in is counted. |
| Save or export the report | It's on screen only. Copy, print or screenshot what you need from the output window. |
| Update live | It's a snapshot. Run it again after changes. |
| Depend on the current view | All four reports scan the **whole model**, not just what's in the view. |

---

## 3. Before you start

- [ ] A **project** model is open.
- [ ] *(Workset Counter)* The model is **workshared**, and the worksets you care about are **open**.
- [ ] *(Big models)* Expect **Items on Levels** and **Workset Counter** to take a few seconds. They scan every element.

---

## 4. How to use

1. Open the **Quick Reports** dropdown on the QoL panel.
2. Click the report you want.
3. A pyRevit output window opens with the result. ✅

That's it. There are no windows or options.

---

## 5. Items on Levels

**Title in the output window:** *Elements per Level*

### What's counted

- Only **model** elements (walls, doors, pipes, furniture, rooms…). Annotation and analytical elements are not counted.
- Some "part of something else" categories are **left out** so nothing is counted twice: **Curtain Panels**, **Curtain Wall Mullions**, stair **Runs**, **Landings**, **Supports** and **Stringers/Carriages**, railing **Top Rails**, **Handrails**, **Supports** and **Terminations**.
- **Levels** and **Grids** themselves are not counted.
- The tool finds each element's level from its own level property, or from its usual level parameters (Base Constraint, Reference Level, Start Level, etc.).

### Reading the report

| Part | What it shows |
|---|---|
| **Expand all / Collapse all** (top) | Opens or closes every level block at once. |
| **Level block header** | Level name, its **elevation in mm**, and the number of elements. Click it to open or close the block. Levels are listed from lowest to highest. |
| **"Select every element on this level: select all"** | Selects every counted element on that level in Revit. |
| **Category rows** | Category name, count, and a **select** link for just those elements. Sorted by count, biggest first. |
| ***(no elements)*** | That level has nothing on it. |
| **No Level / Unassigned** | Elements the tool couldn't link to any level. |
| **Totals by Category (all levels)** | The whole-model count per category. |
| **Grand total counted** (bottom) | Total elements and number of levels. |

> 💡 When a list is very long (more than 750 elements), the link is split into several parts, e.g. **select 1-750**, **select 751-1500**. Click each one in turn.

---

## 6. Parking Count Lister

**Title in the output window:** *Parking Type Count Report*

A table with three columns:

| Column | Meaning |
|---|---|
| **Parking Type** | The type name of the parking element |
| **Count** | How many are placed |
| **Percentage** | Share of the total, to one decimal |

The last row is **TOTAL**. Types are sorted alphabetically.

> ⚠️ Types are grouped by **type name only**. Two different parking families that both have a type called e.g. *Standard* are counted together.

---

## 7. Room Area Lister

One line per room in the project:

`Room Name: <name> >> Area = <area>`

- The area is shown in your project's area units.
- Each line is a **link**. Click it to select that room in Revit.
- Rooms are listed in the order the model returns them, not sorted.

> ⚠️ All rooms in the project are listed, including rooms that are **not placed** or **not enclosed**. Their area won't be a real value.

---

## 8. Workset Counter

**Title in the output window:** *Workset Report*

Only **user-created** worksets are reported. View, family and project-standard worksets are left out.

### Summary table

| Column | Meaning |
|---|---|
| **Workset** | Workset name |
| **Kind** | Always **User-Created** |
| **Creator** | Who created it (**\<unknown\>** if Revit doesn't know) |
| **Owner** | Who has it borrowed right now (**-** if nobody) |
| **State** | **Open** or **Closed** in your session |
| **Model Elements** | Model elements on it, plus **Levels** and **Grids**. Sub-parts like mullions or balusters are not counted on their own. |
| **All Elements** | Everything on it, including views, annotations and sub-parts |
| **Categories** | How many different categories its model elements belong to |

Worksets are sorted by **Model Elements**, biggest first.

### Category Breakdown

Below the table, each workset gets its own heading **"<name> — Holds _ Model Elements"**, its creator/owner/state, and a list of categories with counts.

- ***Empty workset*** means nothing at all is on it.
- ***No model elements. Holds _ other element(s) (views, annotations, subcategories, etc.)*** means it only holds non-model items.

The bottom line shows **Total Model Elements Scanned** and the number of **Empty Worksets**.

---

## 9. Undoing

None of the reports change the model. There's nothing to undo.

The **select** links only change your selection. Press **Esc** in the view to clear it.

---

## 10. Messages you may see

### 🟡 "This model is not workshared - there are no worksets to report."
**Why:** You ran **Workset Counter** on a model without worksharing.
**What to do:** Nothing. There are no worksets to count.

### 🟡 "Warning: _ workset(s) are closed in this session, so their elements are not loaded and will report as 0: …"
**Why:** Some worksets are closed in your local copy. Revit hasn't loaded their elements.
**What to do:** Open those worksets (**Collaborate → Worksets**, set them to **Open**), then run the report again.

### 🔵 Empty Parking table (TOTAL 0)
**Why:** The model has no parking elements.
**What to do:** Nothing.

### 🔴 A red pyRevit error window
**Why:** Something unexpected happened.
**What to do:** Screenshot it and contact the author.

---

## 11. FAQ

**Do the reports count elements in linked models?**
No. Open the linked model itself and run the report there.

**Why does Items on Levels show fewer elements than I expected?**
Sub-parts (curtain panels, mullions, stair runs, railing parts…) are left out on purpose, and annotation isn't counted.

**What's in "No Level / Unassigned"?**
Model elements that have no level the tool can find, for example some in-place or level-free elements.

**Is the elevation in Items on Levels in my project units?**
No. It's always shown in **millimetres**.

**Why does a workset show 0 elements when I know it has some?**
It's probably **closed** in your session. See the warning at the top of the report.

**Can I export the reports to Excel?**
Not from the tool. You can copy the tables from the output window.

---

## 12. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the dropdown | B-Dare95 tab missing | Restart Revit. Check the **B-Dare95** tab. | ✅ If still missing |
| Report takes a long time | Very large model | Wait. Items on Levels and Workset Counter scan everything. | ✅ If Revit freezes |
| Workset shows 0 elements | Workset closed | Open it and run again | ❌ |
| "select" link does nothing visible | Elements not visible in the current view | Check the selection count (bottom right) or switch views | ❌ |
| Parking types merged | Same type name in different families | Rename types to be unique | ❌ |
| Room area looks wrong | Room not placed or not enclosed | Check the room in a plan | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 13. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which report** you ran
2. A **screenshot** of the output window and of any error
3. Your **Revit version** (e.g. 2025)
4. The **model name**
5. **What you expected** to see, and what you actually got
