# Get Element ID

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **QoL** panel → **Get Element ID** (dropdown)
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🏷️ **Versions:** Active Element 1.0 · Linked Element 1.2 · What's This ID? 2.0.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

Every element in Revit has a unique number called its **Element ID**. You need it when someone sends you a warning report, a clash report, or asks "can you check element 123456?".

The **Get Element ID** dropdown has **three tools**:

| Tool | Direction | What it does |
|---|---|---|
| **Active Element** | Element → ID | Pick elements in **your model**. You get their names and IDs. |
| **Linked Element** | Element → ID | Pick elements **inside linked models**. You get their names and IDs, grouped per link. |
| **What's This ID?** | ID → Element | Type an ID. The tool finds it in your model **and** in every loaded link, selects it, zooms to it and shows its details. |

> 💡 The first two are like reading a label off a box. The third is like typing a label into a search box and having the warehouse bring you the box.

📸 *[Screenshot: the Get Element ID dropdown open]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change your model | All three tools only read and select. Nothing to undo. |
| Pick linked elements with Active Element | Use **Linked Element** for those. |
| Search unloaded links | **What's This ID?** skips links that aren't loaded. Reload them first. |
| Find element types by ID in a useful way | What's This ID? can find them, but types can't be selected in a view. |
| Keep the output | The lists appear in a pyRevit output window. Copy what you need before closing it. |

---

## 3. Before you start

- [ ] A model is **open** and a view where you can see the elements is **active**.
- [ ] *(Linked Element / What's This ID?)* The links you need are **loaded**.
- [ ] *(What's This ID?)* You have the ID number ready (whole number, no letters).

---

## 4. How to use — Active Element

1. Open the **Get Element ID** dropdown and click **Active Element**.
2. Revit's status bar says **"Select Element"**. Click the elements you want. You can pick several.
3. Click **Finish** on the Options Bar (top left, under the ribbon).
4. A pyRevit output window opens with one line per element:
   `Element Name : <name>>>ID: <number>`
5. Copy the IDs you need. ✅

---

## 5. How to use — Linked Element

1. Open the **Get Element ID** dropdown and click **Linked Element**.
2. Revit's status bar says **"Select Linked Element"**. Hover over a linked model and click the elements you want. You don't need to press **Tab**.
3. You can pick elements from **several links** in one go.
4. Click **Finish** on the Options Bar.
5. The output window lists the results **per link**:

```
Link : <linked model name>:
-Element Name : <name> >> ID: <number>
-Element Name : <name> >> ID: <number>
____________________________________________________________
<number>,<number>
```

6. The last line of each link is a **comma-separated list** of all its IDs, ready to paste (e.g. into Revit's **Select by ID**, in that linked model). ✅

> ⚠️ The IDs belong to the **linked model**, not your model. Typing them into **Select by ID** in your own model will select the wrong thing (or nothing).

---

## 6. How to use — What's This ID?

1. Open the **Get Element ID** dropdown and click **What's This ID?**.
2. A small window asks: **"Enter Element ID to inspect (host or linked):"**. Type the number and confirm.
3. The tool searches **your model** and **every loaded link**.
4. **Found in one place:** the element is selected, the view zooms to it, and a report opens. ✅
5. **Found in several places:** a picker window opens first (see below). Choose the one you meant.

### Why can one ID be in several places?

IDs are only unique **inside one model**. Your model and a link (or two links) can each have an element with the same number. Two copies of the **same link** also count as two places.

### Picker window controls

The window title is **What's This ID?** and the header says **"ID _ exists in _ places"**.

| Control | What it does |
|---|---|
| **Filter box** ("Filter by link, category, family or type...") | Narrows the list as you type. |
| **Rows** | Each row shows where the element lives (**Host model —** or **Link —** name) and its category · family : type. The first row is ticked by default. |
| **Double-click a row** | Chooses it straight away. |
| **Enter** | Same as **Inspect & Select**. |
| **Inspect & Select** | Selects the chosen element and shows the report. |
| **Cancel** / **Esc** | Closes without doing anything. |

📸 *[Screenshot: the picker with a host hit and two link hits]*

### Reading the report

| Line | Meaning |
|---|---|
| **ID** | The number you typed |
| **Source** | **Host model** or **Link — \<linked model\>** |
| **Link Inst.** | *(Linked only)* The link copy in your model, and that copy's own ID |
| **Category / Family / Type** | What the element is |
| **Level** | Its level, as named in the model it lives in |
| **Phase** | Phase Created |
| **Workset** | Its workset, or **Not workshared** |
| **Mark / Comments** | The element's Mark and Comments values |
| **Bounding Box** | Min and max corners of the element's box, in **feet** (Revit's internal unit). For linked elements it's in **your model's** coordinates, marked **[host coords]**. |

A dash (**—**) means the value is empty or doesn't apply.

The last line tells you what happened:

| Footer | Meaning |
|---|---|
| ✔ **Element selected and view zoomed.** | All done. |
| ✔ **Element selected (view not zoomed).** | Selected, but the view couldn't zoom to it. |
| ✘ **Element could not be selected (view-only, non-graphical or an element type).** | The element exists, but it can't be selected in a view (e.g. a type, a view, a sheet). The report is still valid. |
| *The link instance is not visible in the active view.* | The linked element is selected, but its link is hidden in this view, so no zoom. |

---

## 7. Undoing

None of the three tools change the model. There's nothing in the Undo list.

To clear a selection made by **What's This ID?**, press **Esc** in the view.

---

## 8. Messages you may see

### 🟡 "No ID entered."
**Why:** You confirmed the ID box while it was empty.
**What to do:** Run it again and type a number.

### 🟡 "Invalid ID — please enter a whole number."
**Why:** You typed letters, spaces in the middle, or decimals.
**What to do:** Type digits only, e.g. `412893`.

### 🟡 "Invalid ID — please enter a positive whole number."
**Why:** You typed 0 or a negative number.
**What to do:** Check the ID and try again.

### 🟡 "No element with ID _ in the host model or any loaded link."
**Why:** Nothing has that ID. It may have been deleted, or it lives in a link that isn't loaded.
**What to do:** If the message adds **"_ unloaded link(s) could not be searched"**, reload those links in **Manage Links** and try again.

### 🔵 "Selecting linked elements needs Revit 2023 or newer."
**Why:** Shown under the report if Revit can't select linked elements.
**What to do:** Shouldn't appear in Revit 2024+. If it does, contact the author.

### 🔵 Output window (Active Element / Linked Element)
Opens with your list. If you cancel the pick with **Esc**, no window opens and nothing happens.

---

## 9. FAQ

**Can I pick linked elements with Active Element?**
No. Use **Linked Element**.

**What's the comma-separated line for?**
It's every ID from that link in one line, so you can paste it into another tool or a report without editing.

**I typed an ID from a clash report and got three results. Which one is it?**
Check which model the clash report came from. Pick the row with that link name (or **Host model** if it's yours).

**Why are the bounding box numbers so small?**
They're in **feet**, Revit's internal unit, not your project units.

**Does What's This ID? open another view?**
For an element in **your model**, the tool asks Revit to show it. If it isn't visible in the current view, Revit may switch to another view that shows it. For a **linked** element, it only zooms in the current view, and only if the link is visible there.

**Can I use What's This ID? for an element type?**
It will find it and show the report, but types can't be selected, so the footer shows ✘.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Nothing happened after picking | You pressed **Esc** or didn't click **Finish** | Pick again and click **Finish** | ❌ |
| Linked Element won't let me pick | You're hovering your own model, not a link | Hover the linked model's elements | ❌ |
| ID not found | Element deleted, or in an unloaded link | Reload links. Check the ID. | ❌ |
| Found but not zoomed (linked element) | The link is hidden in this view | Open a view where the link is visible, then run again | ❌ |
| Wrong element selected with **Select by ID** | You used a **linked** ID in your own model | Use **What's This ID?** instead | ❌ |
| Red pyRevit error window with **Active Element** in Revit 2026 or newer | Tool incompatibility | Use **What's This ID?** or Revit's own tools meanwhile | ✅ |
| Any other red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which tool** you used (Active Element, Linked Element or What's This ID?)
2. The **ID** you typed, or what you picked
3. A **screenshot** of the result or error
4. Your **Revit version** (e.g. 2025)
5. The **model name**, and the **link name** if it's about a linked element
