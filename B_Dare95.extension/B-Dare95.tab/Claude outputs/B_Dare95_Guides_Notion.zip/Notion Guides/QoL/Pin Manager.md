# Pin Manager

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **QoL** panel → **Pin Manager** (split button)
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🏷️ **Version:** Pin / Unpin Manager 2.0.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

Pinning stops elements from being moved or deleted by accident. **Pin Manager** pins (or unpins) many elements at once instead of one by one.

The button has **two tools** inside it:

| Tool | How to open it | What it does |
|---|---|---|
| **Pin / Unpin Manager** | Click the **main (top) part** of the button | A window where you choose **Pin or Unpin**, **where** (current view, chosen views, or whole project) and optionally **which categories**. |
| **Levels,Grids & Links** | Click the **small arrow** under the button, then choose it | One click: pins **every level, every grid and every Revit link** in the project. No window. |

> 💡 Think of Pin / Unpin Manager as a padlock you can put on a whole shelf at once. **Levels,Grids & Links** locks the "skeleton" of the project in one go.

📸 *[Screenshot: the split button, with the dropdown arrow open]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Pin elements inside linked models | It works on the model you're working in. (The link itself can be pinned.) |
| Ask "are you sure?" | Clicking **Run**, or **Levels,Grids & Links**, acts immediately. Use **Undo** if needed. |
| Unpin anything with **Levels,Grids & Links** | That tool only **pins**. To unpin, use Pin / Unpin Manager. |
| Pin CAD links, scope boxes or reference planes with **Levels,Grids & Links** | Only levels, grids and Revit links. |
| Remember your choices | Pin / Unpin Manager starts fresh each time. |
| Show a message after **Levels,Grids & Links** | It works silently. Check an element's pin icon to confirm. |

---

## 3. Before you start

- [ ] A model is **open**.
- [ ] *(Current View scope)* The view you want to work on is **active**.
- [ ] *(Shared models)* You can **edit** the elements. Elements borrowed by someone else can't be changed.

---

## 4. How to use — Pin / Unpin Manager

1. Click the **main part** of the **Pin Manager** button.
2. The **Pin / Unpin Manager** window opens.
3. Under **ACTION**, choose **📌 PIN** or **📍 UNPIN**. *(PIN is selected by default.)*
4. Under **SCOPE**, choose where:
   - **Current View** — elements visible in the active view *(default)*
   - **Selected Views** — a list appears. Tick one or more views.
   - **Entire Project** — every element in the model
5. *(Optional)* Turn **CATEGORY FILTER** from **OFF** to **ON** and tick the categories you want. Only those categories are changed.
6. Click **▶ Run**.
7. The window closes and a pyRevit output window shows a summary. ✅

📸 *[Screenshot: the Pin / Unpin Manager window with Selected Views and Category Filter open]*

### Window controls

| Control | What it does |
|---|---|
| **📌 PIN / 📍 UNPIN** | Choose the action. One is always selected. |
| **Current View / Selected Views / Entire Project** | Choose the scope. One is always selected. |
| **View search box** *(Selected Views)* | Narrows the view list as you type. Each view shows its type in brackets, e.g. `[FloorPlan]  Level 1`. |
| **View list** | Tick the views to include. Ticks are kept when you change the search. |
| **CATEGORY FILTER  OFF / ON** | Turns the category list on or off. |
| **Category search box** | Narrows the category list as you type. |
| **Category list** | Model categories only. Ticks are kept when you change the search. |
| **Cancel** | Closes the window. Nothing changes. |
| **▶ Run** | Applies the action. |

---

## 5. How to use — Levels, Grids & Links

1. Click the **small arrow** under the **Pin Manager** button.
2. Choose **Levels,Grids & Links**.
3. That's it. Every level, grid and Revit link instance in the project is now pinned. ✅

There's no window and no message.

---

## 6. Understanding scope and categories

| Scope | Without category filter | With category filter |
|---|---|---|
| **Current View** | Everything visible in the active view, **including** annotation (tags, dimensions, text…) | Only the ticked categories, visible in the active view |
| **Selected Views** | Everything visible in the ticked views, **including** annotation | Only the ticked categories, in the ticked views |
| **Entire Project** | **Every element in the model**, including annotation and view-specific items | Every element of the ticked categories, in the whole model |

> ⚠️ **Entire Project + no category filter + UNPIN** unpins **everything**, including levels, grids and links. Use the category filter unless you really mean it.

> 💡 The category list only shows **model** categories. Levels, grids, tags, dimensions and other annotation aren't listed. To pin/unpin those, leave the filter **OFF** and use a view scope (this affects everything in those views).

---

## 7. Reading the summary

| Row | Meaning |
|---|---|
| **📌 Pin Complete** / **📍 Unpin Complete** | Title |
| **Action** | Pin or Unpin |
| **Scope** | **Current View (name)**, **Selected Views (_ views)** or **Entire Project** |
| **Categories** | The ticked categories *(only shown when the filter was on)* |
| **Processed** | Elements the action was applied to. This **includes** elements that were already in that state. |
| **Skipped** | Elements Revit wouldn't let the tool change, marked **(not pinnable)** *(only shown if any)* |

---

## 8. Undoing

| Tool | Name in Revit's Undo list |
|---|---|
| Pin / Unpin Manager | **Pin — Pin/Unpin Manager** or **Unpin — Pin/Unpin Manager** |
| Levels,Grids & Links | **Pin Levels, Grids & Links** |

Each run is **one** undo step. Press **Ctrl + Z** once to reverse the whole run.

---

## 9. Messages you may see

### 🟡 "Please check at least one view."
**Why:** You chose **Selected Views** but didn't tick any view.
**What to do:** Tick at least one view, or choose another scope.

### 🟡 "Category filter is ON but no categories are checked. Please check at least one category, or turn the filter OFF."
**Why:** The filter is on, but nothing is ticked.
**What to do:** Tick a category, or switch the filter **OFF**.

### 🟢 Summary window ("Pin Complete" / "Unpin Complete")
**Why:** The run finished.
**What to do:** Check the **Processed** and **Skipped** counts.

### 🔴 A red pyRevit error window after **Levels,Grids & Links**
**Why:** Revit refused to pin one of the levels, grids or links (e.g. it's borrowed by someone else).
**What to do:** Screenshot it and contact the author.

---

## 10. FAQ

**Why is "Processed" so high?**
It counts every element the action was applied to, including those that were already pinned (or unpinned).

**What does "Skipped (not pinnable)" mean?**
Some elements can't be pinned or unpinned (for example certain view-specific or system items). They're left as they are.

**Does Current View include elements hidden in the view?**
No. Only what the view actually shows.

**Does Levels,Grids & Links also pin CAD imports?**
No, only Revit links.

**I can't find Grids or Levels in the category list.**
They aren't there. Revit treats levels and grids as annotation-type categories, and the list only shows **model** categories. To pin them, use **Levels,Grids & Links**.

**Can I unpin only the grids?**
Not with this tool, because Grids can't be ticked in the category filter. Unpin them the normal Revit way (select them and click **Unpin**).

---

## 11. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| **Run** shows a warning | No view ticked, or filter on with nothing ticked | Tick something, or change scope/filter | ❌ |
| Fewer elements changed than expected | Elements hidden in the view, or category not ticked | Use **Entire Project**, or tick more categories | ❌ |
| Many **Skipped** | Elements that can't be pinned | Normal for some element kinds | ❌ |
| Elements didn't change in a shared model | Borrowed by someone else | Ask them to relinquish, then run again | ❌ |
| Unpinned too much | Entire Project without a filter | **Ctrl + Z** once | ❌ |
| Nothing seems to happen with **Levels,Grids & Links** | It works silently | Select a level or grid and check for the pin icon | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 12. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which tool** you used (Pin / Unpin Manager or Levels,Grids & Links)
2. Your **Action**, **Scope** and **categories**
3. A **screenshot** of the window, the summary and any error
4. Your **Revit version** (e.g. 2025)
5. The **model name** and the **view** you were in
