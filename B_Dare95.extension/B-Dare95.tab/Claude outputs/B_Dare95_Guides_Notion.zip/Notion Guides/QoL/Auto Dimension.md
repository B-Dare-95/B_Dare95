# Auto Dimension

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **QoL** panel → **Easy Dimension**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🏷️ **Version:** 1.1.0
> 🗓️ **Last updated:** [Date]

> ℹ️ The button on the ribbon is labelled **Easy Dimension**. The tool's own messages call it **Auto Dimension**. It's the same tool.

---

## 1. What this tool does

**Auto Dimension** measures the **clear spaces between walls** for you.

You click **two points** in a floor plan. The tool draws an imaginary line between them, finds every wall that line crosses, and places **one dimension for each gap between two walls** (face of wall to face of wall).

It does **not** dimension the wall thicknesses. Only the spaces in between.

You can keep picking pairs of points. The tool keeps going until you press **Esc**, then tells you how many dimensions it made.

> 💡 Think of it as running a tape measure across a row of rooms and writing down every room width in one go.

📸 *[Screenshot: a plan with a row of space dimensions created by the tool]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Dimension wall thickness | Gaps between the two faces of the **same** wall are skipped. |
| Dimension anything other than walls | Columns, doors, grids, furniture, etc. are ignored. |
| Draw diagonal dimensions | The line is always straightened to **horizontal or vertical**, whichever is closer to what you picked. |
| Work in sections, elevations or 3D | You need a plan view. |
| Use walls hidden in the view | Only walls **visible** in the current view are checked. |
| Make one overall dimension string | Each space gets its **own** dimension. |

---

## 3. Before you start

- [ ] A **plan view** is open and active.
- [ ] The walls you want to dimension are **visible** in that view.
- [ ] The walls run roughly **at right angles** to the direction you want to measure (see [FAQ](#7-faq)).

---

## 4. How to use it

1. Click **Easy Dimension** on the QoL panel.
2. Revit's status bar (bottom left) says **"Pick START (ESC to exit)"**. Click a point on one side of the walls you want to measure.
3. The status bar says **"Pick END (ESC to exit)"**. Click a point on the other side.
4. Dimensions appear for every space between the walls the line crossed. ✅
5. The tool asks for a new **START** point straight away. Repeat steps 2–4 as often as you like.
6. Press **Esc** when you're done. A message tells you how many space dimensions were created in total.

> 💡 The dimension line is placed **through your START point**. Pick the start point where you want the dimension string to sit.

> ⚠️ **Snap direction:** If your two points are more apart left-to-right than up-to-down, the line runs **horizontally**. Otherwise it runs **vertically**.

---

## 5. Undoing

Each pair of points you pick is saved as its own step called **"Auto Dimension"** in Revit's Undo list.

- To remove the last pair's dimensions: press **Ctrl + Z** once.
- To remove several pairs: press **Ctrl + Z** once per pair, or use the Undo dropdown.
- You can also select the dimensions and delete them like any other dimension.

---

## 6. Messages you may see

### 🟡 "Open a floor plan view first."
**Why:** The active view isn't a plan view (e.g. a section, 3D view or sheet).
**What to do:** Open a plan view and click the button again.

### 🟢 "Created _ space dimension(s) total."
**Why:** You pressed **Esc**. This is the total for the whole session.
**What to do:** Nothing. If it says **0**, see [Troubleshooting](#8-troubleshooting).

### 🔴 "Failed: …"
**Why:** Revit refused to create a dimension for that pair of points. Nothing from that pair was added. The tool keeps running.
**What to do:** Try a different pair of points. If it keeps happening, screenshot it and contact the author.

### 🔴 "Pick error: …"
**Why:** Something unexpected happened while picking. The tool stops.
**What to do:** Screenshot the message and contact the author.

---

## 7. FAQ

**Does it work with angled walls?**
The dimension line is always horizontal or vertical. Walls that cross it at an angle may not dimension correctly, and Revit may refuse the dimension (you'll see a **"Failed"** message).

**Why didn't a wall get dimensioned?**
The wall must be **visible** in the view and its centre line must actually **cross** the line between your two points. Make sure your points sit **outside** the first and last wall.

**Can I measure to a column or grid?**
No. Only walls are used.

**Why did I get no dimension for a single wall?**
A single wall has no space on either side to measure. You need at least two walls.

**Does it work in ceiling plans?**
The tool accepts any plan-type view. It's designed for floor plans.

---

## 8. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| "Open a floor plan view first." | Not in a plan view | Open a plan view | ❌ |
| Total says **0** | Line didn't cross 2+ visible walls | Pick points further apart, outside the outer walls | ❌ |
| A wall is missing from the string | Wall hidden in the view, or its centre line doesn't cross your line | Check visibility/graphics. Extend your pick points. | ❌ |
| Dimension sits in the wrong place | The line goes through your **START** point | Undo, then pick START where you want the string | ❌ |
| Line went the wrong way (horizontal vs vertical) | Points are more apart in the other direction | Pick points more clearly in one direction | ❌ |
| "Failed: …" on angled or curved walls | Walls not at right angles to the line | Dimension those walls by hand | ✅ If it happens on straight, square walls |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 9. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the plan showing where you picked, and of any message
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **view** you were in
4. **What you expected** to be dimensioned, and what actually was
