# Revit SEO

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **QoL** panel → **Revit SEO**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🏷️ **Version:** 2.1.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Revit SEO** is a **search engine for your model**. You pick a category, optionally add rules like *Fire Rating = 60 min*, and the tool lists **every matching element in the whole model**, wherever it is.

Click any result to jump to that element in Revit.

> 💡 Think of it as "Find" for Revit: instead of hunting through views, you describe what you're looking for and get a clickable list.

It uses the same filter style as **Pre-Filter by Parameter**, but it searches the **whole model** instead of a box you draw in one view.

📸 *[Screenshot: the Found Elements window with results]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change your model | It only searches and navigates. Nothing to undo. |
| Search several categories at once | One category per search. |
| Search linked models | Only the model you're working in. |
| Search annotation | Only **model** categories are listed (walls, doors, pipes…). |
| Support "contains", "greater than", etc. | Values must match **exactly**. You pick them from a list. |
| Export the results | The list is on screen only. |
| Select all results at once | Click a row to jump to one element. **Done** selects the last one you clicked. |

---

## 3. Before you start

- [ ] A model is **open**.
- [ ] You know the **category** you're looking for (e.g. Doors).
- [ ] *(Optional)* You know the **parameter** and **value** to filter by.

---

## 4. How to use it

1. Click **Revit SEO** on the QoL panel.
2. A window opens with the heading **Choose Category**. *(Its title bar says "Pre-Filter by Parameter".)*
3. *(Optional)* Type in the **search box** to shorten the category list.
4. Pick **one** category (round buttons).
5. *(Optional)* Under **PARAMETER FILTERS**:
   - Choose a **Parameter** from the left dropdown.
   - Choose a **Value** from the right dropdown. It only lists values that exist in your model.
6. *(Optional)* Click **+ Add Filter** for another rule. Choose **AND / OR / NOT** on the pills between the rows (see [Section 6](#6-understanding-and--or--not)).
7. Click **Find Elements**.
8. The **Found Elements** window opens with the results. ✅
9. Click a row to jump to that element.
10. Click **Done** when finished. The last element you clicked stays selected.

> 💡 You can skip the parameter rows. You then get **every** element of that category in the model.

📸 *[Screenshot: the Choose Category window with two filter rows]*

### Window controls — Choose Category

| Control | What it does |
|---|---|
| **Search box** | Filters the category list as you type. |
| **Category list** | Choose **one** model category. |
| **Parameter** dropdown | Every parameter found on elements of that category, instance and type. |
| **Value** dropdown | Every value that parameter has in the model. Greyed out until a parameter is chosen. |
| **+ Add Filter** | Adds another rule row. Greyed out until a category is chosen. |
| **AND / OR / NOT** pills | Appear between rows. Set how the new row combines with the rows above. Default is **AND**. |
| **×** | Removes that row. |
| **Find Elements** | Runs the search. Greyed out until a category is chosen, and while a row has a parameter but no value. |
| Window **X** | Closes without searching. |

### Window controls — Found Elements

| Control | What it does |
|---|---|
| **Header** | "_ elements found — \<category\>" |
| **Search box** | Narrows the list by **name** or **level** as you type. |
| **NAME / ELEMENT ID / LEVEL** columns | The element's name (or Mark, or type name), its ID, and its level (**—** if none). |
| **Click a row** | Revit shows and zooms to that element. The line above **Done** says **"Opened: \<name\> (ID _)"**. |
| **Done** | Selects the **last** element you clicked, zooms to it, and closes the window. |
| Window **X** | Closes without changing the selection. |

---

## 5. Where do results come from?

- The search covers the **whole model**, not just the current view.
- Elements are listed in the order Revit returns them (not sorted).
- When you click a row, Revit decides how to show it. If the element isn't visible in the current view, Revit may switch to another view.

---

## 6. Understanding AND / OR / NOT

Rules are read **top to bottom**. Each new row combines with **the result of all the rows above it**.

| Operator | Meaning | Example |
|---|---|---|
| **AND** | Must match the rows above **and** this row | Level = *L01* **AND** Fire Rating = *60 min* → 60-min doors on L01 |
| **OR** | Matches the rows above **or** this row | Level = *L01* **OR** Level = *L02* → doors on either level |
| **NOT** | Must match the rows above, but **not** this row | Level = *L01* **NOT** Type = *D1* → doors on L01, except type D1 |

> ⚠️ **Order matters.** There are no brackets. Put your **OR** rows first and your narrowing **AND** rows after them.

> ℹ️ Unlike Pre-Filter by Parameter, the **first** row has no NOT option here. To find "everything except X", leave the first row as a rule that matches everything you want, then add **NOT** X.

### About values

- Values must match **exactly**. That's why you pick them instead of typing.
- Values are shown the way Revit displays them, including units (e.g. `900 mm`).
- A rule is checked against **both** the element and its type. If either has that value, it counts.
- Empty values aren't listed, so you can't search for "parameter is blank".

---

## 7. Undoing

Revit SEO never changes the model. There's nothing in the Undo list.

To clear the selection after **Done**, press **Esc** in the view.

---

## 8. Messages you may see

### 🟡 "No elements found for category "_"."
**Why:** Nothing in the model matches. If you used filters, the message lists them under **Filters applied**.
**What to do:** Loosen your rules, check the operator order, or check that the category has elements.

### 🟡 "Cannot navigate to this element."
**Why:** You clicked a row, but Revit can't show that element (e.g. it's not visible in any suitable view).
**What to do:** Note the **ELEMENT ID** and look for it another way (e.g. **Get Element ID → What's This ID?**).

### 🔵 "Opened: _ (ID _)"
**Why:** You clicked a row and Revit jumped to it.
**What to do:** Nothing.

### 🔴 A red pyRevit error window
**Why:** Something unexpected happened.
**What to do:** Screenshot it and contact the author.

---

## 9. FAQ

**Does it change anything?**
No. It only finds and shows.

**Can I search linked models?**
No. Only the model you're working in.

**Why does the Parameter dropdown take a moment to fill?**
The tool scans every element of that category in the whole model. Big categories can take a few seconds.

**Clicking a row didn't select the element. Why?**
Clicking only **shows** the element. **Done** selects the last one you clicked.

**Can I search the results by ID?**
No. The search box in Found Elements matches **name** and **level** only.

**The value I want isn't in the list.**
Only values that exist in the model are listed, and blank values are skipped.

**What's the difference to Pre-Filter by Parameter?**
Pre-Filter selects inside a box you draw in one view. Revit SEO lists matches from the **whole model**.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| **Find Elements** is greyed out | No category chosen, or a row has a parameter but no value | Choose a category. Pick a value or remove the row with **×**. | ❌ |
| **+ Add Filter** is greyed out | No category chosen | Choose a category first | ❌ |
| "No elements found" | Rules too strict, or rule order | Try one rule at a time. Move **OR** rows up. | ❌ |
| "Cannot navigate to this element." | Element can't be shown in a view | Use its ID with another tool | ❌ |
| Nothing selected after closing | Closed with **X**, or no row clicked | Click a row, then **Done** | ❌ |
| Windows take long to fill | Very large category | Wait a few seconds | ✅ If Revit freezes |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. The **category**, **parameters**, **values** and **operators** you used
2. A **screenshot** of both windows and any error
3. Your **Revit version** (e.g. 2025)
4. The **model name**
5. **What you expected** to find, and what you actually got
