# Detail to Plan Callout

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Views** dropdown → **Detail to Plan Callout**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

Sometimes a callout is drawn in a floor plan as a **Detail** callout when it should have been a **Floor Plan** callout. Revit can't switch a callout from one kind to the other.

**Detail to Plan Callout** fixes this for you. For each callout you tick, it:

1. Draws a **new floor plan callout** in the same parent plan, over the same area.
2. Carries over the old view's settings, annotations, sheet placement and references (see [Section 6](#6-what-gets-carried-over)).
3. Gives the new view the **same name** as the old one.
4. **Deletes** the old detail view.

> 💡 Think of it as moving house: the tool builds a new room of the right type, moves all the furniture in, puts the same name on the door, and then removes the old room.

📸 *[Screenshot: the Detail to Floor Plan Callout window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Convert details drawn in sections, elevations or other details | Only detail callouts drawn in **plan views** are listed. Details in sections/elevations are normal and are left alone. |
| Convert every callout it lists | Some rows are greyed out with a reason in red (see [Section 5](#5-reading-the-status-column)). |
| Keep the old view | The original detail view is **deleted**. Undo is your only way back. |
| Copy reference markers drawn *inside* the detail | Section, elevation or callout markers drawn inside the old detail are not carried over. The result report tells you how many. |
| Keep a split crop region | If the detail's crop was split, only its outer extents are kept. |
| Guarantee every annotation copies | Anything Revit refuses to copy is listed in the report as "not carried over". |

---

## 3. Before you start

- [ ] Save your model. The tool deletes views, so a fresh save is a good safety net.
- [ ] **Don't have the detail you want to convert open as the active view.** Switch to another view first.
- [ ] In a workshared model, make sure nobody else has **borrowed** the detail view, its parent plan, or its sheet.
- [ ] Decide which **floor plan type** and **view template** the new callouts should get.

---

## 4. How to use it

1. Click **Detail to Plan Callout** in the **Views** dropdown.
2. The **Detail to Floor Plan Callout** window opens. The line under the title tells you how many detail callouts were found and how many can be converted.
3. *(Optional)* Type in the **search box** to find a view by its name, its parent plan or its sheet.
4. **Tick** the callouts you want to convert. You can also click anywhere on a row to tick or untick it.
5. At the bottom, choose a **Floor plan type for the new callouts**.
6. Choose a **View template** option.
7. Click **Convert selected**.
8. The tool runs, then a **report window** opens with the results (see [Section 7](#7-the-result-report)). ✅

### Window controls

| Control | What it does |
|---|---|
| **Search box** | Filters the list by view name, parent plan, or sheet. Upper/lower case doesn't matter. |
| **Select all** | Ticks every convertible row **currently shown** (respects your search). |
| **Select none** | Unticks **everything**, including rows hidden by your search. |
| **Applicable only** (toggle, on by default) | When on, only convertible rows are shown. Turn it off to also see the greyed-out rows and why they can't be converted. |
| **Columns** | **View**, **Parent plan**, **Scale**, **Sheet** (shows `-` if not on a sheet), **Status** |
| **Floor plan type for the new callouts** | **Same type as the parent plan** (default), or any floor plan type in the project. |
| **View template** | See the table below. |
| **Counter** (bottom left) | Shows `_ selected | _ applicable | _ listed`. |
| **Cancel** | Closes the window. Nothing changes. |
| **Convert selected** | Starts the conversion. |

### View template options

| Option | What the new callout gets |
|---|---|
| **Keep the detail's template (parent plan's if not plan-compatible)** *(default)* | The same template the old detail had. If that template can't be used on a plan, the parent plan's template is used instead. If the detail had no template, the new view has none. |
| **Use the parent plan's template** | The template of the plan the callout is drawn in. If the parent has none, or it can't be used, no template is applied. |
| **No template** | No template. |
| **Template: _name_** | That specific floor plan template. |

---

## 5. Reading the Status column

| Status | Meaning | What to do |
|---|---|---|
| 🟢 **Ready** | Can be converted | Tick it |
| 🔴 **Parent is a … - floor plan type not allowed** | The callout is in a plan that isn't a floor plan (e.g. a ceiling plan) | Can't be converted with this tool |
| 🔴 **Parent plan does not accept floor plan callouts** | Revit won't allow a floor plan callout in that parent | Can't be converted with this tool |
| 🔴 **Active view - switch to another view first** | You have this detail open as the active view | Close the window, open another view, run the tool again |
| 🔴 **Is a dependent view** | The detail is a dependent view | Can't be converted |
| 🔴 **Has dependent views** | Other views depend on this detail | Remove or handle the dependents first |
| 🔴 **Has callouts drawn inside it** | Another callout is drawn inside this detail | Handle the inner callout first |
| 🔴 **View, parent or sheet is borrowed by another user** | Someone else owns one of these in a workshared model | Ask them to sync and relinquish, then try again |

---

## 6. What gets carried over

| Item | Notes |
|---|---|
| **Name** | The new view gets the old view's name. |
| **Area** | The crop is rebuilt over the same area, lined up with the parent plan. |
| **Crop shape** | Non-rectangular or rotated crops are reproduced when Revit allows it. Otherwise straight extents are used and a note is added. |
| **Annotation crop offsets** and **crop region visibility** | Copied. |
| **Scale, Detail level, Visual style** | Copied. |
| **Title on Sheet, Phase, Phase filter, Discipline, Annotation crop** | Copied. |
| **Project / shared parameters** (e.g. browser organisation fields) | Copied where the new view has the same parameter. |
| **Visibility/Graphics and filters** | Copied **only if the detail had no view template** (otherwise the template controls them). |
| **Per-element graphic overrides** and **hidden model elements** | Copied. |
| **Annotations** (dimensions, tags, text, detail lines, etc.) | Copied, including annotations that were hidden in the view. |
| **Sheet placement** | Placed back on the same sheet, at the same spot, with the same viewport type, rotation, detail number and title position. |
| **References from other views** | Callout/section/elevation markers and view references elsewhere that pointed to the old view are pointed to the new one. |

---

## 7. The result report

After the run, a report window opens titled **Detail callouts converted to floor plan callouts**.

- A summary line: **_X_ of _Y_ converted.**
- A table with columns **Detail view**, **Result** (`Converted` / `Failed`), **New floor plan callout** (a clickable link to the new view), and **Notes**.

The **Notes** column lists anything that could not be carried over, for example:

- `Detail crop was split - only its outer extents were kept`
- `Non-rectangular / rotated crop could not be reproduced - axis-aligned extents used`
- `_N_ reference marker(s) drawn inside the detail were not carried over`
- `Annotations not carried over: 2 x Text Notes, …`
- `Could not be placed back on its sheet`
- `Template '…' is not valid for plans` / `Parent plan's template applied instead`

> ⚠️ Read the **Notes** column for every converted view and check those views by eye.

---

## 8. Undoing

The whole run is **one step** in Revit's Undo list, called **Detail to Floor Plan Callouts**.

| You want to… | Do this |
|---|---|
| Stop before anything changes | Click **Cancel** or close the window |
| Undo the whole run | Press **Ctrl + Z** once (or pick **Detail to Floor Plan Callouts** in the Undo list). The old details come back and the new callouts are removed. |
| Undo only one view | Not possible. Undo the whole run, then run the tool again with fewer rows ticked. |

---

## 9. Messages you may see

🔴 **"This project has no Floor Plan view type."**
*Why:* The project has no floor plan view type to build the new callouts from.
*What to do:* Create a Floor Plan view type, then try again.

🔵 **"No detail callouts drawn in plan views were found."**
*Why:* There's nothing to convert in this model.
*What to do:* Nothing. Your model is already clean.

🟡 **"Select at least one callout to convert."** (in the counter area)
*Why:* You clicked **Convert selected** with nothing ticked.
*What to do:* Tick at least one row.

🟡 **A row shows `Failed` in the report**
*Why:* That one view could not be converted. The reason is in the **Notes** column, e.g. `The chosen floor plan type is not allowed in '<plan>'`.
*What to do:* Try another floor plan type. If the reason isn't clear, contact the author. The other views in the run are not affected.

---

## 10. FAQ

**Will the new view keep the same name?**
Yes. The old view is deleted first, then the new view takes its name.

**Will my sheets still look the same?**
The new view is placed back on the same sheet at the same spot, with the same detail number. Check the report for `Could not be placed back on its sheet`.

**Will markers in other views still point to it?**
Yes. Markers and view references that pointed to the old view are switched to the new one.

**Why is a detail I know about not in the list?**
Only detail callouts drawn **in plan views** are listed. Details drawn in sections, elevations or other details are not candidates.

**Why can I see fewer rows than the subtitle says?**
**Applicable only** is on. Turn it off to see the greyed-out rows too.

**Can I choose a different type per view?**
No. The type and template you pick apply to every ticked view in that run. Run the tool several times if you need different settings.

**Why didn't my Visibility/Graphics settings copy?**
They're only copied when the old detail had **no view template**. When it had one, the template controlled V/G, so pick a template option instead.

---

## 11. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Look under **Modify** panel → **Views** dropdown. | ✅ If it's still missing |
| A row can't be ticked | It isn't convertible | Read its **Status** (see [Section 5](#5-reading-the-status-column)) | ❌ |
| Nothing happens when I click **Convert selected** | Nothing is ticked | Look at the counter message | ❌ |
| A view shows `Failed` | Type not allowed in that parent, or a Revit error | Read **Notes**. Try **Same type as the parent plan**. | ✅ If the note is unclear |
| Some annotations are missing | Revit refused to copy them | Read **Notes**. Redraw them by hand, or Undo. | ✅ If many are lost |
| The crop looks different | Split, rotated or unusual crop shape | Read **Notes**. Adjust the crop by hand. | ❌ |
| The view is no longer on its sheet | Revit wouldn't place it back | Place it by hand from the Project Browser | ✅ If it repeats |
| Red pyRevit error window | Unexpected problem | Screenshot it. Press **Ctrl + Z** if anything changed. | ✅ |

---

## 12. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. The **names of the views** you tried to convert
2. A **screenshot** of the window (with the Status column) and of the **report**, including the **Notes** column
3. Any **error** screenshot
4. Your **Revit version** (e.g. 2025)
5. The **model name**, and whether it's **workshared**
