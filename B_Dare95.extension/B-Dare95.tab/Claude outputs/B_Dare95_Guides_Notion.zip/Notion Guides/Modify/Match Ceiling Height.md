# Match Ceiling Height

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Ceiling** dropdown → **Match Ceiling Height**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Match Ceiling Height** copies the **Height Offset From Level** of one ceiling onto as many other ceilings as you like.

1. You click a **source** ceiling (the one with the right height).
2. You click **target** ceilings one by one. Each one takes the source's height offset straight away.
3. Press **Esc** when you're done.

> 💡 It works like Revit's **Match Type Properties** brush, but only for the ceiling's height offset.

📸 *[Screenshot: picking a target ceiling]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Copy the **level** | Only the **offset** is copied. A ceiling on another level gets the same offset from **its own** level, not the same absolute height. |
| Copy the ceiling **type** or anything else | Type, material, sketch and other parameters stay as they are. |
| Work on linked models | Only ceilings in the model you're working in can be picked. |
| Pick anything other than ceilings | Other elements can't be clicked while the tool runs. |

---

## 3. Before you start

- [ ] A view where you can **click ceilings** is active (a reflected ceiling plan, section or 3D view works well).
- [ ] You know which ceiling has the **correct height**.

---

## 4. How to use it

1. Click **Match Ceiling Height**.
2. The status bar says **"Select A Ceiling"**. Click the **source** ceiling.
3. A yellow bar appears at the top of the Revit window. Click a **target** ceiling. Its height changes immediately.
4. Keep clicking more target ceilings.
5. Press **Esc** to finish. ✅

> ⚠️ **Heads-up:** The yellow bar at the top reads **"Pick Wall to match base constrains:"**. That text is a leftover; you are picking **ceilings**, not walls.

---

## 5. Undoing

Each target ceiling is changed in its own step. The Undo list shows one **"Match Ceiling Height"** entry **per ceiling you clicked**.

- To undo the last ceiling: press **Ctrl + Z** once.
- To undo all of them: press **Ctrl + Z** once for each ceiling you changed, or use the Undo dropdown to pick several entries.

---

## 6. Messages you may see

🔵 **Script Canceled. — "Script is canceled."**
- **Why:** You pressed **Esc** (or right-click → Cancel) before choosing the source ceiling.
- **What to do:** Nothing changed. Run the tool again.

🔴 **A pyRevit error window**
- **Why:** Something unexpected happened.
- **What to do:** Screenshot it and contact the author.

---

## 7. FAQ

**Does it change the source ceiling?**
No. Only the targets change.

**Can I select several ceilings first and then run the tool?**
No. The tool always asks you to click the source, then each target.

**The target ceiling didn't move to the height I expected.**
It probably sits on a different level. The tool copies the **offset from level**, not the absolute height.

**Does it show a summary at the end?**
No. Pressing **Esc** after the targets ends the tool quietly.

---

## 8. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't click anything | You're hovering over something that isn't a ceiling | Hover over the ceiling itself. Use **Tab** to cycle if it's overlapped. | ❌ |
| Ceilings can't be picked at all | The ceiling category isn't recognised (e.g. Revit in a language other than English) | Note your Revit language | ✅ |
| Height is wrong on another level | Offset is copied, not absolute height | Check each ceiling's **Level** | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 9. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of any error
2. Your **Revit version** (e.g. 2025) and **language**
3. The **model name** and the **view** you were in
4. The source and target ceilings (their **levels** and **offsets**)
