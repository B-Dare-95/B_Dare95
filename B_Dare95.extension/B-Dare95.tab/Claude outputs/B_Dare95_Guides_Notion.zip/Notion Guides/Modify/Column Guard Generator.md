# Column Guard Generator

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Columns** dropdown → **Column Guard Generator**
> 🧩 **Works with:** Revit 2024 and newer · columns in a **linked** Revit model
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🏷️ **Version:** 3.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Column Guard Generator** draws a **railing around each column** you pick from a linked model. Each railing is a rectangle that follows the column's outline and rotation, pushed out by the distance you choose.

The railings are created in **your** model, on the **level of the plan view you have open**.

> 💡 Think of it as wrapping a tape barrier around each column, at the distance you set.

It works with any column shape (rectangular, round, L-shaped, chamfered…). Non-rectangular columns get a **rectangle that fits around them**.

📸 *[Screenshot: a column with its guard railing in plan]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on columns in your own model | You can only pick columns inside a **Revit link**. |
| Follow round or L shapes exactly | The railing is always a **rectangle** around the column. |
| Use the column's own level | Railings go on the **active view's level**, plus your Base Offset. |
| Check for existing guards | Running it twice on the same column makes **two** railings. |
| Use project units | Offsets are always typed in **centimetres**. |
| Pick annotation or other categories | Only **Columns** and **Structural Columns** can be picked. |

---

## 3. Before you start

- [ ] A **plan view** of the level you want the guards on is **open and active**.
- [ ] The **link** with the columns is loaded and visible in that view.
- [ ] Your model has at least one **Railing type**.
- [ ] Ideally, the level is marked as a **Building Story** (see Section 6).

---

## 4. How to use it

1. Open the plan view for the target level.
2. Click **Columns** dropdown → **Column Guard Generator**.
3. The **Column Guard Generator** window opens.
4. Click a **RAILING TYPE** in the list (type in the filter box to find it). It appears next to **Selected:**.
5. Set **FACE OFFSET (CM)** and **BASE OFFSET (CM)** (see table below).
6. Choose **RAILING DIRECTION**: **Normal** or **Flipped**.
7. Click **Select Columns**. The window closes.
8. Click the columns in the link. The status bar says **"Select columns from a Revit link (Finish when done)"**.
9. Click **Finish** on the Options Bar (top left).
10. A summary appears. ✅ A pyRevit output window with a detailed log may also open.

📸 *[Screenshot: the Column Guard Generator window]*

### Window controls

| Control | What it does |
|---|---|
| **Filter railing types…** | Shortens the list as you type. |
| **RAILING TYPE** list | All railing types in your model. Pick one. |
| **FACE OFFSET (CM)** | Gap between the column's face and the railing path. `0` = right on the face. Must be zero or more. |
| **BASE OFFSET (CM)** | Raises (+) or lowers (−) the railing from the view's level. |
| **Normal / Flipped** | Which side of the path the railing sits on. **Flipped** turns each railing to the other side. |
| **Selected:** | Shows the chosen railing type (or **None**). |
| **Select Columns** | Greyed out until a railing type is chosen. Starts column picking. |
| **Cancel** | Closes the window. Nothing is created. |

---

## 5. Reading the summary

The summary lists your settings, then:

| Line | Meaning |
|---|---|
| **Railings** | How many railings were made. Usually one per column, but can be **two** (see below). |
| **Columns done** | Columns that got a guard. |
| **Bbox fallback** | Columns whose shape couldn't be read cleanly. They got a rectangle **aligned to the project axes**, not to the column's rotation. Check these. |
| **Flip failed** | Railings that couldn't be flipped. Flip them by hand. |
| **Offset failed** | Columns whose Base Offset couldn't be set. Check their height. |
| **Level fallback used** | Revit refused the view's level, so the railing was put on a nearby level and moved to the right height. |
| **Skipped** | Columns that got nothing, with a reason. |

> ℹ️ If Revit refuses a closed rectangle, the tool tries **two open railings** (two halves of the rectangle) instead. That's why **Railings** can be higher than **Columns done**.

---

## 6. About levels

- The railing is placed at the **elevation of the active view's level**, not at the column's base.
- If the level isn't marked as a **Building Story**, the summary shows a **WARNING**. That's a common reason Revit refuses railings.
- If Revit refuses the view's level, the tool tries up to **4 nearby levels**. It then sets **Base Offset** so the railing still ends up at the right height. Every time this happens it's listed in the summary.

---

## 7. Undoing

All railings from one run are created in **one step**. To undo, press **Ctrl + Z** once, or pick **Generate Column Guardrails** in Revit's Undo list.

---

## 8. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🟢 Summary with **Railings / Columns done** | The run finished. | Check the lines in Section 5. |
| 🔵 **"No railing type selected. Script cancelled."** | You closed the window or clicked **Cancel**. | Nothing changed. |
| 🔵 Summary ending with **"No columns selected."** | You pressed **Esc** or picked nothing. | Run again and pick columns. |
| 🔴 **"The active view has no associated level. Open a plan view and run again."** | Active view is 3D, section, sheet, etc. | Open a plan view. |
| 🔴 **"No Railing Types found in the Railings category."** | No railing types in your model. | Load or create a railing type. |
| 🟡 **"WARNING: '…' is not flagged as a Building Story."** | The level may refuse railings. | Tick **Building Story** on the level, or expect level fallback. |
| 🟡 Red text **"Face offset must be a number (cm)."** / **"Face offset must be zero or positive."** / **"Base offset must be a number (cm)."** | Bad value in an offset box. | Fix the value. |
| 🟡 **Skipped …: footprint too small to rail** | Column is under about 50 mm on a side. | Draw by hand. |
| 🟡 **Skipped …: refused** | Revit refused the railing on every level tried. | Try another railing type or level. Send the details to the author. |
| 🔴 **"Transaction failed and was rolled back: …"** | Something failed. Nothing was created. | Screenshot it and contact the author. |

---

## 9. FAQ

**Can I pick columns in my own model?**
No. Only columns inside a linked model.

**Why did my round column get a square guard?**
The guard is always a rectangle that fits around the column.

**My guards are at the wrong height.**
They sit on the active view's level plus **Base Offset**. Check you ran it from the right plan, and check the Base Offset value.

**Can I pick the same column twice by accident?**
Duplicates in one pick are ignored. But running the tool again creates new railings.

**Does it update if the linked column moves?**
No. The railings are normal railings. Move or recreate them if the link changes.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab. | ✅ If still missing |
| Can't click columns | Columns are in your own model, or link not visible | Only linked columns can be picked. Check link visibility. | ❌ |
| **Select Columns** greyed out | No railing type chosen | Click a type in the list | ❌ |
| Railing not rotated with column | **Bbox fallback** was used | Check the summary; adjust by hand | ✅ If it happens a lot |
| Railing on the wrong side | Direction setting | Undo and run with **Flipped**, or flip by hand | ❌ |
| Columns skipped as "refused" | Level or railing type not accepted by Revit | Mark level as Building Story; try another railing type | ✅ If it repeats |
| Duplicate railings | Tool run twice | Undo or delete the extras | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the summary, and of the pyRevit output window if it opened
2. Your **Revit version** (e.g. 2025)
3. The **model name**, the **link name** and the **view** you were in
4. The **railing type**, **offsets** and **direction** you used
5. **What you expected**, and what actually happened
