# Duplicate Views

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Views** dropdown → **Duplicate Views**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Duplicate Views** makes **several copies of one view in one go**, using any of Revit's three duplicate options:

| Option | What you get |
|---|---|
| **Duplicate View** | Copies of the view, **without** its annotations (dimensions, tags, text…). |
| **Duplicate with Detailing** | Copies of the view **with** its annotations. |
| **Duplicate as Dependent** | **Dependent** views of the original. You can give each one its own **Scope Box** and a naming pattern. |

> 💡 Think of it as a photocopier with a number pad: choose the page, type how many copies, press go.

📸 *[Screenshot: the Duplicate Views window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Duplicate sheets or schedules | They're not in the list. |
| Duplicate several different views at once | One source view per run. |
| Use the view you have open | You always pick the view from the list. |
| Let you name plain duplicates | Copies are named `<view> - Copy 1`, `- Copy 2`, … Rename them afterwards if needed. |
| Warn you when a scope box can't be applied | If Revit refuses a scope box for a view, it's skipped quietly. Check the new views. |

---

## 3. Before you start

- [ ] Know the **name** of the view you want to copy.
- [ ] Decide **how many** copies you need.
- [ ] For **dependent views**: create the **scope boxes** you want to use first, and give them clear names.

---

## 4. How to use it

1. Click **Duplicate Views** in the **Views** dropdown.
2. The **Duplicate Views** window opens (**Select a View to Duplicate**).
3. Find your view. Type in the **search box**, and/or pick a view type from the dropdown on the right (e.g. **Floor Plans**).
4. **Click** the view in the list.
5. Type the **Number of Duplicates**.
6. Choose a **Duplicate Option**.
7. Click **Continue**.
   - For **Duplicate View** or **Duplicate with Detailing**, the copies are created now.
   - For **Duplicate as Dependent**, a second window opens (see [Section 5](#5-dependent-views-scope-boxes-and-names)).
8. A report tells you how many views were created. ✅

### Window controls

| Control | What it does |
|---|---|
| **Search box** (top left) | Filters the list by view name. Upper/lower case doesn't matter. |
| **View type dropdown** (top right) | **All Views**, or one type: Floor Plans, Reflected Ceiling Plans, Area Plans, Structural Plans, Elevations, Sections, 3D Views, Detail Views, Drafting Views, Legends, Renderings, Walkthroughs. Only types that exist in your model are offered. |
| **View list** | Click one view to select it. |
| **Number of Duplicates** | How many copies. Must be a whole number of 1 or more. Default **1**. |
| **Duplicate Option** | **Duplicate View** (default), **Duplicate with Detailing**, or **Duplicate as Dependent**. |
| **Continue** | Goes to the next step. |
| **Window X** | Closes the window. Nothing is created. |

---

## 5. Dependent views: scope boxes and names

When you choose **Duplicate as Dependent**, the **Dependent Views - Scope Boxes** window opens.

1. There's **one row per dependent view**, labelled `<view name> — #1`, `#2`, …
2. For each row, choose a **Scope Box**, or leave `<None>`.
3. *(Optional)* Type a **Prefix** and/or **Suffix**.
4. Click **Create Views**.

### How dependent views are named

The parts are joined with a hyphen `-`:

| Prefix | Suffix | Result for copy #2 of `L01 Plan` |
|---|---|---|
| *(empty)* | *(empty)* | `L01 Plan-2` |
| `Zone` | *(empty)* | `L01 Plan-Zone-2` |
| `Zone` | `A` | `L01 Plan-Zone-2-A` |

Spaces at the start and end of the prefix and suffix are removed.

### How other duplicates are named

`<view name> - Copy 1`, `<view name> - Copy 2`, and so on.

> 💡 If a name is already taken, the tool adds a number in brackets, e.g. `L01 Plan - Copy 1 (2)`.

---

## 6. Undoing

All views from one run are **one Undo step** called **Duplicate Views**.

| You want to… | Do this |
|---|---|
| Stop before anything is created | Close either window with **X** |
| Undo the run | Press **Ctrl + Z** once, or pick **Duplicate Views** in the Undo list |
| An unexpected error stopped the run | Nothing to undo. Everything was rolled back. |

---

## 7. Messages you may see

### In the first window (red text)

🟡 **"Please select a view."**
*Why:* No view is selected in the list.
*What to do:* Click a view.

🟡 **"Enter a valid whole number of duplicates."**
*Why:* The number is empty, zero, negative, or not a whole number.
*What to do:* Type a number like `3`.

### Pop-up messages

🔵 **"No eligible views were found in the project."**
*Why:* The model has no views that can be duplicated.

🟡 **"The selected view does not support this duplicate option."**
*Why:* Revit doesn't allow that option for that view. For example, some views can't have dependents, and some views can't be duplicated with detailing.
*What to do:* Run the tool again and choose another option.

🟢 **Duplicate Views - Report — "Created _X_ of _Y_ view(s) from '<view>'."**
*Why:* Done. If some copies failed, a **Failed:** list follows with the copy number and Revit's reason.

🔴 **"An unexpected error occurred:"** followed by details
*Why:* Something unexpected stopped the run. Nothing was created.
*What to do:* Screenshot it and contact the author.

---

## 8. FAQ

**Can I duplicate the view I'm looking at without searching for it?**
No. Pick it from the list. Typing part of its name in the search box is the quickest way.

**Two views have the same name (e.g. a floor plan and a ceiling plan both called "Level 1"). Which one is copied?**
The tool finds the view by its **name**, so it may copy the other one, even if you filtered by view type. To be safe, give the view you want a unique name first (you can rename it back afterwards). Then check the report and the new views.

**Can I give each dependent view a different scope box?**
Yes. Each row in the second window has its own **Scope Box** choice.

**My scope box didn't stick on a dependent view.**
Revit may not allow that scope box on that view (e.g. it doesn't cross the view). The tool skips it quietly. Set it by hand in the view's properties.

**Is there a limit to how many copies I can make?**
No. Larger numbers simply take longer.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Look under **Modify** panel → **Views** dropdown. | ✅ If it's still missing |
| My view isn't in the list | It's a sheet, schedule or template, or it's filtered out | Clear the search, set the dropdown to **All Views** | ❌ |
| Wrong view was copied | Two views share the same name | **Ctrl + Z**, give your view a unique name, run again | ✅ Let the author know |
| "does not support this duplicate option" | Revit limitation for that view | Try another option | ❌ |
| Names end in `(2)`, `(3)` | Names were already taken | Rename or delete older views | ❌ |
| Scope box missing on a dependent | Revit refused it | Set it by hand | ❌ |
| Error or nothing happens after **Continue** in dependent mode | The view name may contain special characters (e.g. `&`, `<`, `"`) | Screenshot the error | ✅ |
| "An unexpected error occurred" | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. The **view name** and **view type** you duplicated
2. The **duplicate option** and **number** you chose
3. A **screenshot** of the report or error
4. Your **Revit version** (e.g. 2025)
5. The **model name**
