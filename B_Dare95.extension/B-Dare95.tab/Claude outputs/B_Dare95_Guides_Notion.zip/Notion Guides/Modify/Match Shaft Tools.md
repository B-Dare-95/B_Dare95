# Match Shaft Tools

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Shafts** dropdown → **Match Shaft Base** / **Match Shaft Top** / **Match Both** / **Match Shaft Function**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What these tools do

The four **Match** tools work like Revit's *Match Type Properties* brush, but for **shaft settings**.

You click one **source** shaft, then click as many **target** shafts as you like. Each target gets the source's values straight away.

| Tool | What it copies from the source shaft |
|---|---|
| **Match Shaft Base** | **Base Constraint** + **Base Offset** |
| **Match Shaft Top** | **Top Constraint** + **Top Offset** |
| **Match Both** | Base Constraint + Base Offset + Top Constraint + Top Offset |
| **Match Shaft Function** | The **Shaft Function** value |

> 💡 Think of it as a paint brush: dip it in one shaft, then paint the others.

---

## 2. What these tools do NOT do

| ❌ They do NOT… | What this means for you |
|---|---|
| Copy the shape | Only the values in the table above are copied. The outline stays as it is. |
| Copy Unconnected Height | **Match Shaft Top** / **Match Both** copy Top Constraint and Top Offset only. |
| Work on linked shafts | You can only pick shafts in the model you're working in. |
| Let you pick other elements | Only **Shaft Openings** can be clicked. Everything else is ignored while the tool runs. |
| Work on a selection you made before | You always pick the source and targets **after** clicking the button. |
| Show a summary | There's no "done" message. Check the shafts' properties to confirm. |

---

## 3. Before you start

- [ ] A model is **open**, in a view where you can **see and click** the shafts (plan, section, 3D…).
- [ ] You know which shaft is the **source** (the one with the correct values).
- [ ] For **Match Shaft Function**: the project has the **Shaft Function** parameter (see **Create Shaft Param**), and the source shaft has a value.

---

## 4. How to use them

1. Click the Match tool you need in the **Shafts** dropdown.
2. The status bar (bottom left) says **"Select A Source Shaft"**. Click the shaft whose values you want to copy.
3. A bar appears at the top of the Revit window: **"Pick Shaft to match:"**. The status bar now says **"Select A Shaft"**.
4. Click a target shaft. It's updated **immediately**.
5. Keep clicking more target shafts. Each one is updated as you click it.
6. Press **Esc** when you're done. The tool ends quietly. ✅

📸 *[Screenshot: the "Pick Shaft to match:" bar at the top of Revit]*

> 💡 To reach shafts on several floors in one run, start the tool in a view where they're all visible, such as a 3D view or a section.

---

## 5. Undoing

Every target you click is a **separate** Undo entry, all named **Match Shafts**.

| You want to… | Do this |
|---|---|
| Undo the last shaft only | **Ctrl + Z** once |
| Undo a whole run of 10 shafts | **Ctrl + Z** 10 times, or open Revit's Undo list and pick the 10th **Match Shafts** down |
| Stop before changing anything | Press **Esc** while picking the source |

---

## 6. Messages you may see

🔵 **Script Canceled.** — "Script is canceled."
*Why:* You pressed **Esc** (or right-click → Cancel) while picking the **source** shaft.
*What to do:* Nothing changed. Run the tool again when ready.

🔴 **Parameter not found** — "The Parameter (Shaft Function) was not found, Command will exit now" *(Match Shaft Function only)*
*Why:* The source shaft doesn't have a **Shaft Function** parameter.
*What to do:* Run **Create Shaft Param** first, then try again.

🔴 **A pyRevit error window**
*Why:* Revit refused the change on a target. Examples could be a level combination Revit doesn't allow, or a target without the **Shaft Function** parameter.
*What to do:* Screenshot it and contact the author. Shafts you matched before the error keep their new values.

---

## 7. FAQ

**Can I match a whole selection at once?**
No. You click targets one by one. Each click updates one shaft.

**What if I click the same shaft twice?**
It just gets the same values again. No harm done.

**Can I click the source shaft as a target?**
Yes, but nothing changes, because it already has those values.

**Does Match Shaft Top handle "Unconnected" tops?**
It copies the Top Constraint (which can be *Unconnected*) and the Top Offset. It does **not** copy the Unconnected Height value.

**Can I match shafts in a linked model?**
No. Open the linked model and run the tool there.

**I clicked the wrong target. How do I fix it?**
Press **Ctrl + Z** once. Only that shaft goes back.

---

## 8. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the buttons | B-Dare95 tab not loaded | Restart Revit. Look in **Modify** panel → **Shafts** dropdown. | ✅ If they're still missing |
| Can't click a shaft | It's in a link, hidden, or not a Shaft Opening | Check it's a shaft in your own model and visible in the view | ❌ |
| Target didn't change | You picked a different tool than you meant (e.g. Base instead of Top) | Check the tool name, Undo, run the right one | ❌ |
| **Parameter not found** | Shaft Function parameter missing | Run **Create Shaft Param** | ❌ |
| Red pyRevit error window | Revit refused a value | Screenshot it | ✅ |
| Tool keeps waiting for clicks | That's normal | Press **Esc** to finish | ❌ |

---

## 9. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which Match tool** you used
2. A **screenshot** of any error
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **view** you were in
5. The **Properties** of the source shaft and of the target shaft (screenshots)
