# Match Floor Height

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Floors** dropdown → **Match Floor Height**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Match Floor Height** copies the **Height Offset From Level** of one floor onto as many other floors as you like.

1. You click a **source** floor (the one with the right height).
2. You click **target** floors one by one. Each one takes the source's height offset straight away.
3. Press **Esc** when you're done.

> 💡 It works like Revit's **Match Type Properties** brush, but only for the floor's height offset.

📸 *[Screenshot: picking a target floor]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Copy the **level** | Only the **offset** is copied. A floor on another level gets the same offset from **its own** level, not the same absolute height. |
| Copy the floor **type** or anything else | Type, thickness, sketch and other parameters stay as they are. |
| Work on linked models | Only floors in the model you're working in can be picked. |
| Pick anything other than floors | Other elements can't be clicked while the tool runs. |

---

## 3. Before you start

- [ ] A view where you can **click floors** is active (plan, section or 3D).
- [ ] You know which floor has the **correct height**.

---

## 4. How to use it

1. Click **Match Floor Height**.
2. The status bar says **"Select A Floor"**. Click the **source** floor.
3. A yellow bar appears at the top of the Revit window: **"Pick Floor to match Height:"**. Click a **target** floor. Its height changes immediately.
4. Keep clicking more target floors.
5. Press **Esc** to finish. ✅

---

## 5. Undoing

Each target floor is changed in its own step. The Undo list shows one **"Match Floor Height"** entry **per floor you clicked**.

- To undo the last floor: press **Ctrl + Z** once.
- To undo all of them: press **Ctrl + Z** once for each floor you changed, or use the Undo dropdown to pick several entries.

---

## 6. Messages you may see

🔵 **Script Canceled. — "Script is canceled."**
- **Why:** You pressed **Esc** (or right-click → Cancel) before choosing the source floor.
- **What to do:** Nothing changed. Run the tool again.

🔴 **A pyRevit error window**
- **Why:** Something unexpected happened.
- **What to do:** Screenshot it and contact the author.

---

## 7. FAQ

**Does it change the source floor?**
No. Only the targets change.

**Can I select several floors first and then run the tool?**
No. The tool always asks you to click the source, then each target.

**The target floor didn't move to the height I expected.**
It probably sits on a different level. The tool copies the **offset from level**, not the absolute height.

**Does it show a summary at the end?**
No. Pressing **Esc** after the targets ends the tool quietly.

---

## 8. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't click anything | You're hovering over something that isn't a floor | Hover over the floor edge. Use **Tab** to cycle if it's overlapped. | ❌ |
| Floors can't be picked at all | The floor category isn't recognised (e.g. Revit in a language other than English) | Note your Revit language | ✅ |
| Height is wrong on another level | Offset is copied, not absolute height | Check each floor's **Level** | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 9. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of any error
2. Your **Revit version** (e.g. 2025) and **language**
3. The **model name** and the **view** you were in
4. The source and target floors (their **levels** and **offsets**)
