# Viewport Title Aligner

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Views** dropdown → **Viewport Title Aligner**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Viewport Title Aligner** tidies viewport titles on your sheets. It can do two things (use one or both):

| Option | What it does |
|---|---|
| **Align title under bottom-left corner** | Moves each viewport title so it sits just **below the bottom-left corner** of its viewport. |
| **Fit title line to text length** | Makes the line under the title **as long as the title text**, plus a small extra length you choose. |

You can run it on **selected viewports**, the **active sheet**, or a list of **picked sheets**.

All distances are in **paper millimetres** (as printed on the sheet).

> 💡 Think of it as straightening the labels on a row of picture frames: every label goes to the same corner, and every underline is cut to fit its text.

📸 *[Screenshot: a sheet before and after]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on rotated viewports | They're skipped and listed in the report. |
| Work on viewports with a hidden title | They're skipped and listed in the report. |
| Move the viewports themselves | Only the **titles** move. The views stay where they are. |
| Change the title text or the viewport type | Only the title's **position** and **line length** change. |
| Work on views selected in the Project Browser | **Selection** only uses viewports selected **on a sheet**. |

---

## 3. Before you start

- [ ] Choose how you want to apply it:
  - a few viewports → open the sheet and **select those viewports** first
  - one sheet → **open that sheet**
  - several sheets → you'll pick them in the window
- [ ] Decide your distances (in paper mm). The defaults are a good start (see below).

---

## 4. How to use it

1. *(Optional)* Open a sheet and select the viewports you want.
2. Click **Viewport Title Aligner** in the **Views** dropdown.
3. Under **SCOPE**, choose **Selection (_n_)**, **Active Sheet**, or **Pick Sheets**.
4. If you chose **Pick Sheets**, tick the sheets in the list.
5. Under **LAYOUT (PAPER SPACE)**, tick the options you want and type the distances.
6. Click **Apply**.
7. A result message appears (see [Section 7](#7-messages-you-may-see)). ✅

### Window controls

| Control | What it does |
|---|---|
| **Selection (_n_)** | Works on the viewports you selected before running. Greyed out if none are selected. Chosen for you when you did select some. |
| **Active Sheet** | Works on every viewport on the open sheet. Greyed out when the open view isn't a sheet. |
| **Pick Sheets** | Works on every viewport on the sheets you tick. The sheet list is only usable in this mode. |
| **Search box** (above the sheet list) | Filters sheets by number or name. |
| **Check visible** / **Uncheck visible** | Ticks / unticks the sheets **currently shown** in the list. |
| **Align title under bottom-left corner** | Turns alignment on/off. |
| **Shift right from viewport left edge** (mm) | How far the title starts to the right of the viewport's left edge. Default **0**. |
| **Gap below viewport** (mm) | Space between the bottom of the viewport and the top of the title. Default **2**. |
| **Fit title line to text length** | Turns line fitting on/off. |
| **Line extends past text by** (mm) | How far the line goes past the end of the text. Default **3**. |
| **Cancel** | Closes the window. Nothing changes. |
| **Apply** | Runs the tool. Greyed out when both options are off. |

> 💡 **Your settings are remembered.** Both tick boxes and the three distances come back the next time you open the tool. A comma or a dot can be used for decimals.

---

## 5. Good to know

- "Bottom-left corner" means the corner of the **viewport box** as Revit sees it on the sheet.
- When both options are on, the line is fitted **first**, then the title is moved.
- If something goes wrong with one viewport, that viewport's title is put back the way it was, and it's listed in the report.

---

## 6. Undoing

All changes from one run are **one Undo step** called **Align Viewport Titles**.

| You want to… | Do this |
|---|---|
| Stop before anything changes | Click **Cancel** or close the window |
| Undo the run | Press **Ctrl + Z** once, or pick **Align Viewport Titles** in the Undo list |
| An error stopped the run | Nothing to undo. Everything was rolled back. |

---

## 7. Messages you may see

🟡 **"Offsets must be numbers (mm)."**
*Why:* A distance box is empty or has text in it.
*What to do:* Type a number.

🟡 **"No viewports in the chosen scope."**
*Why:* The sheet(s) you chose have no viewports, or no sheet is ticked in **Pick Sheets**.
*What to do:* Choose another sheet, or tick at least one.

🟢 **Viewport Title Aligner — "_X_ of _Y_ viewport titles updated"**
*Why:* The run finished. The message also shows the **Action** (aligned / line fitted).

🟡 **"_N_ skipped - expand details for the list."**
*Why:* Some viewports were not changed. Expand the details to see them as `sheet number | view name - reason`. Only the first 15 are listed.

| Reason | What to do |
|---|---|
| `Skipped - viewport is rotated` | Fix the title by hand |
| `Skipped - title is not shown` | The viewport type hides the title. Nothing to fix. |
| `Skipped - <other text>` | Revit refused the change. Contact the author if it repeats. |

🔴 **"Failed - nothing changed."** followed by an error
*Why:* Something unexpected stopped the run. Everything was rolled back.
*What to do:* Screenshot it and contact the author.

---

## 8. FAQ

**Are the distances in model units or paper units?**
Paper millimetres, as printed on the sheet.

**Can I put the title above the viewport?**
Not with this tool. It always places the title below the bottom-left corner. A negative **Gap below viewport** moves the title up into the viewport.

**Why is "Selection" greyed out?**
No viewports were selected on a sheet before you clicked the button.

**Will it change titles on every sheet in the project?**
Only on the sheets or viewports you choose.

**Can I only fit the lines without moving the titles?**
Yes. Untick **Align title under bottom-left corner**.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Look under **Modify** panel → **Views** dropdown. | ✅ If it's still missing |
| **Selection** / **Active Sheet** greyed out | Nothing selected / no sheet open | Select viewports on a sheet, or open a sheet | ❌ |
| **Apply** greyed out | Both options are off | Tick at least one | ❌ |
| Sheet list can't be clicked | **Pick Sheets** isn't chosen | Click **Pick Sheets** | ❌ |
| The window or a message went behind Revit | Window lost focus | Use **Alt + Tab** to bring it back | ❌ |
| Title in the wrong spot | Distance values | Check the mm values and run again | ❌ |
| Some titles didn't change | Rotated viewport or hidden title | Expand the details in the result message | ❌ |
| "Failed - nothing changed." | Unexpected error | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your settings
2. A **screenshot** of the result message, with **details expanded**
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **sheet numbers** you ran it on
5. **What you expected**, and what actually happened
