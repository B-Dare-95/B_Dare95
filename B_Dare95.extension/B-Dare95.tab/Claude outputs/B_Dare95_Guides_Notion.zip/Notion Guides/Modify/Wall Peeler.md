# Wall Peeler

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Walls** dropdown → **Wall Peeler**
> 🧩 **Works with:** Revit 2024 and newer · straight Basic walls
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams] *(script credits also list Erik Frits and Joven Mark Gumana)*
> 🏷️ **Version:** 6.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Wall Peeler** splits **one multi-layer wall** into **several separate walls**, one per layer (or per group of layers) that you choose.

For example, a wall made of *Cladding | Insulation | Block | Plaster* can become two walls: a **cladding wall** and a **block wall with insulation and plaster**. Each new wall:

- sits **exactly where its layers were** in the original wall,
- gets its own **wall type**, named by you,
- keeps the original wall's **instance values** (it starts as a copy of it).

Doors, windows and openings are moved onto the **one new wall you choose as the host**.

You work through a window in **three phases**:

| Phase | You decide |
|---|---|
| **Phase 1 — select layers to split** | Which layers become their own wall, and which layers stay together |
| **Phase 2 — pick the host layer** | Which new wall carries the doors, windows and openings |
| **Phase 3 — name resulting walls** | The wall type names, and whether to do this wall only or **all walls of this type** |

> 💡 Think of peeling an onion: you lift off the layers you want, and each one becomes its own piece.

📸 *[Screenshot: the Wall Peeler window in Phase 1]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on curved walls | Curved walls are skipped and listed. |
| Work on curtain or stacked walls | They have no layers to peel. Picking one ends in an error window. |
| Keep the original wall | The original is **deleted**. The new walls have **new element IDs**. |
| Keep zero-thickness layers | Layers with no thickness (e.g. membranes) show as a thin **Core Boundary** line and aren't put into any new wall. |
| Put doors and windows on every new wall | Only the **host** wall gets them. They're removed from the others. |
| Have a Back button | Use **Reset** to start again from Phase 1. |
| Check that names are unique | See [Section 6](#6-how-wall-types-are-named). |

---

## 3. Before you start

- [ ] The wall is a **straight Basic wall** with **two or more layers**.
- [ ] You know which layer should **host** the doors and windows (usually the structural layer).
- [ ] The wall(s) are **editable** (worksharing: you own them or can borrow them) and not pinned.
- [ ] If you'll use **All walls of this type**: every wall of that type in the **whole model** will be changed.
- [ ] You've noted any **tags** or **dimensions** on the wall. The original is deleted, so these may need redoing.

---

## 4. How to use it

1. Click **Wall Peeler**.
2. The status bar says **"Select Wall to Peel"**. Click the wall.
3. The **Wall Peeler** window opens in **Phase 1**. Layers are listed from **exterior (top)** to **interior (bottom)**.
4. **Click the layers** you want to split out. They turn **blue**.
5. *(Optional)* Between two blue layers that sit next to each other, a small **🔗** button appears. Click it to **group** them into **one** wall. They turn **orange**.
6. Click **Next →**.
7. **Phase 2:** click the wall that should **host** doors, windows and openings. It turns **green**. Click **Next →**.
8. **Phase 3:** choose **Selected wall only** or **All walls of this type**. Check or edit each **Wall Type Name**.
9. Click **Confirm**.
10. The new walls are created and a summary appears. ✅

> 💡 To cancel, close the window with the **X**. Nothing changes.

📸 *[Screenshot: Phase 2 with the host wall in green]*
📸 *[Screenshot: Phase 3 with the name boxes]*

### Window controls

| Control | What it does |
|---|---|
| **Phase badge** (top right) | Shows which phase you're in. |
| **Legend** (Phase 1) | **Keep** (grey), **Split out** (blue), **Grouped split** (orange), **Host elements** (green). |
| **Layer rows** | Show the layer's **material**, **function** (Structure, Substrate, Thermal / Air, Finish 1, Finish 2, Membrane…) and **thickness in cm**. The hatch hints at the function. Thicker layers are drawn taller. |
| **🔗 connector** | Appears between two **adjacent** blue layers. Click to group / ungroup them. Unmarking a layer also removes its links. |
| **Info box** | Phase 1: e.g. *"3 layers → 2 output walls. 1 linked group."* Phase 2: the chosen host. Phase 3: how many walls will be created. |
| **Reset** | Clears everything and goes back to Phase 1. |
| **Next →** | Next phase. Greyed out in Phase 1 until at least one layer is marked, and in Phase 2 until a host is chosen. |
| **Apply to** (Phase 3) | **Selected wall only** or **All walls of this type**. |
| **Wall Type Name** boxes (Phase 3) | One per new wall, pre-filled with a suggested name. |
| **Confirm** (Phase 3) | Creates the walls. |
| Window **X** | Cancels. Nothing changes. |

---

## 5. How layers turn into walls

**Every** layer ends up in one of the new walls. Nothing is thrown away (except zero-thickness layers).

| Layers in Phase 1 | Become |
|---|---|
| A **blue** layer on its own | Its own wall (**"Split wall"**) |
| Blue layers joined with **🔗** | One wall together (**"Grouped wall"**) |
| **Grey** (unmarked) layers next to each other | One wall together (**"Combined wall"**) |

**Example:** *Cladding | Insulation | Block | Plaster*

| You mark | Result |
|---|---|
| Cladding | 2 walls: **Cladding** + **Insulation-Block-Plaster** |
| Cladding and Plaster | 3 walls: **Cladding** + **Insulation-Block** + **Plaster** |
| Cladding + Insulation, linked with 🔗 | 2 walls: **Cladding-Insulation** + **Block-Plaster** |
| All four | 4 walls, one per layer |

> ⚠️ The Phase 1 instructions say *"Make sure to select all layers even the layers you don't intend to split"*. You don't have to: unmarked neighbouring layers simply stay together as one wall, as the table shows. Marking every layer gives one wall per layer.

### Where the new walls go

- Each new wall is placed exactly where its layers were, measured from the original wall's **exterior face**.
- The new walls' **Location Line** is set to **Wall Centerline**.
- The new walls are **joined** to each other.
- The exterior side stays on the **same side** as the original.

---

## 6. How wall types are named

- Suggested names list each layer's material and thickness, e.g. **"Concrete Masonry Units (20cm) - Gypsum Plaster (1.5cm)"**. Long names are cut at 100 characters.
- An empty name box falls back to the suggested name.
- New types are made by **duplicating the original wall type** and giving it only the chosen layers.

| A type with your name already exists and… | Result |
|---|---|
| has the **same total thickness** | The **existing type is used** as it is. No new type is made. |
| has a **different thickness** | A new type is made with the thickness added, e.g. **"My Type [200mm]"** |

> ⚠️ The tool checks only the **name and thickness**, not the materials. If an existing type has the same name and thickness but different layers, it's used anyway. Use **new, clear names** to be safe. Giving **two** new walls the same name in Phase 3 isn't blocked either.

---

## 7. Doors, windows and openings

Everything **hosted by** the original wall is handled: doors, windows, rectangular wall openings and wall-hosted families (e.g. lights, panels).

| On the… | What happens |
|---|---|
| **Host** wall (green in Phase 2) | Each hosted element is **moved** onto it at the same position along the wall, with the same flip/hand. |
| Other new walls | Their copies of the hosted elements are **removed**. |

If an element won't move cleanly, the tool **re-creates** it on the host wall with the same type and the same instance values (it gets a new ID). If even that fails, it's named in the summary under **"could NOT be restored"**.

---

## 8. Undoing

Everything is a single step in the Undo list: **"Wall Peeler — Split Layers"**. Press **Ctrl + Z** once to get the original wall(s) back.

This also applies with **All walls of this type**: one **Ctrl + Z** undoes every wall.

> 💡 New wall types made by the tool are removed by the same undo.

---

## 9. Messages you may see

🟢 **"Created N wall(s) from M original wall(s)."**
- **Why:** Success. If hosted elements were involved, it adds *"N hosted element(s) handled:"* with how many were **moved with the host wall**, **rebuilt on the host wall**, or **could NOT be restored** (with their names).
- **What to do:** Check any elements listed as not restored and re-place them.

🟡 **"N wall(s) will be skipped - curved, or the exterior face could not be read. IDs: …"**
- **Why:** Some walls (usually with **All walls of this type**) are curved or unreadable. The others are still processed.
- **What to do:** Click **OK**. Handle the listed walls by hand.

🟡 **"No usable walls. Nothing was changed."**
- **Why:** Every target wall was skipped.
- **What to do:** Use a straight wall.

🟡 **"No wall selected. Exiting."**
- **Why:** You pressed **Esc** instead of picking a wall.
- **What to do:** Run the tool again.

🟡 **"Wall has no real layers to split."**
- **Why:** The wall type has no layers with thickness.
- **What to do:** Choose another wall.

🟡 **"No layers were selected for splitting. Nothing to do."** / **"Nothing to do."**
- **Why:** No layer was marked in Phase 1.
- **What to do:** Run again and mark at least one layer.

🔴 **"No host wall was designated. … Aborted - nothing was changed."**
- **Why:** No host was chosen in Phase 2.
- **What to do:** Run again and pick a host.

🔴 **"Group widths do not add up to the wall thickness. … Aborted - nothing was changed."**
- **Why:** An internal check failed.
- **What to do:** Screenshot the message (it lists the groups) and contact the author.

🔴 **A pyRevit error window**
- **Why:** Something unexpected happened (for example a curtain or stacked wall was picked, or Revit refused a change). Anything started is rolled back.
- **What to do:** Screenshot it and contact the author.

---

## 10. FAQ

**Which way is up in the layer list?**
Top = **exterior** side, bottom = **interior** side.

**Do I have to mark every layer?**
No. Unmarked neighbouring layers stay together as one wall. See [Section 5](#5-how-layers-turn-into-walls).

**Can I group layers that aren't next to each other?**
No. The 🔗 button only appears between **adjacent** marked layers.

**Which new wall holds the doors and windows?**
Only the **host** wall you chose in Phase 2. Check the other new walls around each door in plan and adjust if needed.

**Does "All walls of this type" only affect the current view?**
No. It affects **every wall of that type in the whole model**.

**Do the new walls keep parameters like Comments or Mark?**
Yes. Each new wall starts as a copy of the original wall.

**Do tags on the wall survive?**
The original wall is deleted, so tags and dimensions attached to it may need redoing.

---

## 11. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't pick the wall | Not a wall, or Revit in a language other than English | Hover over the wall. Note your Revit language. | ✅ If walls can't be picked at all |
| Error window right after picking | Curtain or stacked wall | Use a Basic wall | ❌ |
| **Next →** greyed out | No layer marked (Phase 1) or no host chosen (Phase 2) | Mark a layer / click a host | ❌ |
| No 🔗 button | The marked layers aren't adjacent | Mark neighbouring layers | ❌ |
| A membrane layer is missing in the new walls | Zero-thickness layers aren't carried over | Add it back to the new type by hand | ✅ If you need it handled |
| New type has unexpected materials | An existing type with the same name and thickness was reused | Use a unique name | ❌ |
| Name ends with **[NNNmm]** | That name existed with a different thickness | Rename the type if needed | ❌ |
| Door listed as **could NOT be restored** | Couldn't be moved or re-created | Re-place it by hand | ✅ If it happens often |
| Some walls skipped with **All walls of this type** | Curved or unreadable walls | Handle those by hand | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 12. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the summary or error message
2. Screenshots of **Phase 1, 2 and 3** with your choices
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **wall type name** and the **wall ID**
5. Whether you used **Selected wall only** or **All walls of this type**
6. **What you expected**, and what actually happened
