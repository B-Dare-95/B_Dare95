# MEP Wall Openings

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Walls** dropdown → **MEP Wall Openings**
> 🧩 **Works with:** Revit 2024 and newer · MEP from the host model and all loaded links
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**MEP Wall Openings** finds every place where a **pipe**, **duct** or **cable tray** passes **through** a **Basic Wall**, and cuts a **rectangular opening** in the wall there.

- The MEP can be in **your model** or in **any loaded link**.
- Only walls in **your model** are changed.
- Each opening is a separate **wall opening element** hosted by the wall. You can select, schedule, move or delete it like any other opening.
- You add a **clearance** around each element (for example 25 mm around pipes).

It works in two steps: first **Find clashes** (a dry run that only reports), then **Create openings**.

> 💡 Think of it as a coring crew that walks the whole building and drills a sleeve wherever a service crosses a wall.

📸 *[Screenshot: a wall with openings around pipes and a duct]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on curtain or stacked walls | Only **Basic Walls**. Stacked and curtain walls aren't listed. |
| Work on curved walls | Curved walls are left out of the scan without a message. |
| Handle fittings, flex ducts/pipes, conduits or sloped runs that aren't straight | Only **straight** pipes, ducts and cable trays. Elbows, tees, flex and conduits are ignored. |
| Cut where MEP **stops inside** a wall | The element must pass **fully through**. Others are reported as unhandled. |
| Cut round openings | Every opening is a **rectangle**. Round pipes get a square-ish opening. |
| Detect openings that already exist | Running it twice on the same walls makes **a second set of openings**. |
| Follow the MEP afterwards | Openings don't move if the pipe or duct moves later. |
| Change linked models | Links are only read. |
| Look only at the current view | It checks **the whole model** for the wall types you tick. |

---

## 3. Before you start

- [ ] The links with MEP are **loaded**.
- [ ] You know which **wall types** should get openings.
- [ ] The walls you want to cut are **editable** (worksharing: you own them or can borrow them).
- [ ] These walls **don't already have openings** from an earlier run.
- [ ] You've agreed on the **clearance** values with your team.

---

## 4. How to use it

1. Click **MEP Wall Openings**. The **MEP Wall Openings** window opens. It stays open while you keep working in Revit.
2. Under **1 - Wall types**, tick the wall types to process. Each shows how many walls of that type exist, e.g. *"Generic - 200mm (42)"*.
3. Under **2 - Clearance offset (mm)**, check the values for **Pipes**, **Ducts** and **Cable trays**.
4. *(Optional)* Tick **Allow walls in single-instance groups** (see [Section 5](#5-options-explained)).
5. Click **Find clashes**. The **Report** on the right fills in. Nothing changes in the model yet.
6. Read the report. If it looks right, click **Create openings**.
7. A confirmation appears: **"Cut N opening(s) into M wall(s)?"**. Click **Yes**.
8. The report shows each wall as **[ OK ]**, **[ SKIP ]** or **[ WARN ]**, then a **SUMMARY**. ✅
9. Click **Close** when you're done.

> 💡 Clicking the ribbon button again while the window is open brings the same window to the front. It doesn't open a second one.

📸 *[Screenshot: the MEP Wall Openings window after a scan]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** (under *1 - Wall types*) | Hides wall types whose name doesn't contain what you type. |
| **Select all** | Ticks every **visible** wall type. Works with the search box. |
| **Clear** | Unticks **all** wall types, including hidden ones. |
| **Wall type list** | Every Basic Wall type used in the model, with the number of walls. |
| **Pipes / Ducts / Cable trays** (mm) | Clearance added on **every side** of the element. Defaults: **25 / 50 / 50**. |
| **Allow walls in single-instance groups** | See [Section 5](#5-options-explained). |
| **Find clashes** | Scans and reports. **Doesn't change the model.** |
| **Create openings** | Greyed out until a scan finds clashes. Cuts the openings from the **last scan**. |
| **Report** | Read-only log of the scan and the run. |
| **Progress bar** | Under the report. Moves while the tool works. |
| **Status line** (bottom left) | Short status, e.g. *"Done. 37 opening(s) in 12 wall(s)."* |
| **Copy report** | Copies the whole report to the clipboard. |
| **Close** | Closes the window. |

---

## 5. Options explained

### Clearance offset (mm)

The clearance is added to **every side** of the element's outline where it crosses the wall.

| Example | Opening size (approx.) |
|---|---|
| 100 mm pipe (outside diameter), 25 mm clearance | 150 × 150 mm |
| 400 × 200 mm duct, 50 mm clearance | 500 × 300 mm |

- Pipes use their **outside diameter**. Ducts and trays use **width × height** (round ducts use the diameter).
- When a run crosses the wall **at an angle**, the opening is stretched to cover the whole crossing.
- Values must be numbers and can't be negative. Otherwise the status line says, e.g., **"'Pipes' offset is not a number."** or **"'Ducts' offset cannot be negative."**

### Openings that touch are merged

If two openings in the same wall **overlap or come within 5 mm** of each other, they're merged into **one larger rectangle**. That's why **"Openings to cut"** can be smaller than **"Clashes found"**.

### Allow walls in single-instance groups

Walls inside a **model group that is placed only once** make Revit raise a harmless *"group changed outside edit mode"* warning. Normally that warning makes the tool **skip** the wall. Tick this box to dismiss **only that warning** and cut the openings anyway. Every other warning still skips the wall.

---

## 6. Reading the report

### After Find clashes

| Line | Meaning |
|---|---|
| **Wall types selected / Walls in scope** | What you ticked, and how many walls that covers |
| **Offsets (mm)** | The clearances used |
| **Documents searched** | Your model + every loaded link |
| **Clashes found** | MEP crossings found, including the ones that can't be cut |
| **Walls to be edited** | Walls that will get at least one opening |
| **Openings to cut** | Openings after merging overlaps |
| **MEP elements skipped: N (no readable size)** | Elements whose size couldn't be read |
| **Unhandled clashes: N (stops inside the wall (no full penetration))** | MEP ends inside the wall. No opening. |
| **Unhandled clashes: N (runs parallel to / inside the wall)** | MEP runs along inside the wall. No opening. |

### After Create openings

| Tag | Meaning |
|---|---|
| **[ OK   ]** | Openings created in this wall. A line **"...1 opening not cut: …"** means one opening in that wall was dropped. |
| **[ SKIP ]** | Nothing created in this wall, with the reason. |
| **[ WARN ]** | Revit raised a warning, so this wall was **rolled back** (no openings). The warning text is shown. |

The **SUMMARY** lists walls edited, openings created, walls skipped, openings not cut, walls with warnings, and the Undo entry. Skipped and warned walls are listed again at the end with their **wall IDs**, so you can find them with **Manage → Select by ID**.

Common reasons:

| Reason | Meaning |
|---|---|
| **opening smaller than Revit's curve tolerance** | The rectangle is too tiny for Revit. |
| **opening falls outside the wall extents** | The opening would be off the end or above/below the wall. |
| **wall no longer exists** | The wall was deleted after the scan. |
| **stacked walls / curtain walls do not support rectangular openings** | Wall kind not supported. |
| **rolled back: …** (WARN) | Revit warned about something on this wall (e.g. groups, joins). |

---

## 7. Undoing

All openings from one **Create openings** run are a **single step** in the Undo list: **"MEP Wall Openings"**. Press **Ctrl + Z** once to remove them all.

**Find clashes** never changes the model, so there's nothing to undo after a scan.

> 💡 To remove openings later, select them in the model (or from a schedule of wall openings) and delete them.

---

## 8. Messages you may see

🔵 **"Cut N opening(s) into M wall(s)? Everything is committed as one undo step called 'MEP Wall Openings'. Walls that would raise a warning are skipped and listed at the end of the report."**
- **Why:** Confirmation before any change.
- **What to do:** **Yes** to cut, **No** to stop (status shows **"Cancelled."**).

🟡 **"No Basic Wall instances were found in this document."**
- **Why:** The model has no Basic Walls. The window doesn't open.
- **What to do:** Nothing to process.

🟡 **"Select at least one wall type first."** (status line)
- **Why:** You clicked **Find clashes** with nothing ticked.
- **What to do:** Tick one or more wall types.

🟡 **"No clashes found."** (status line)
- **Why:** No straight pipe, duct or tray fully passes through the ticked walls.
- **What to do:** Check the links are loaded and the right wall types are ticked.

🟡 **"Queued - waiting for Revit to become idle..."** (status line)
- **Why:** Revit is busy (e.g. you're in the middle of a command).
- **What to do:** Finish or cancel what you're doing in Revit. The job starts by itself.

🔴 **"The document this window was opened on has been closed. Close this window and start the tool again."**
- **Why:** The model was closed while the window was open.
- **What to do:** Close the window and run the tool from the model you want.

🔴 **"Scan failed: …"** / **"Run aborted - nothing was committed."** / **"Job failed: …"**
- **Why:** Unexpected problem. If it says *nothing was committed*, the model is unchanged.
- **What to do:** Click **Copy report** and send it to the author.

🔵 **"Report copied to clipboard."** / **"Could not access the clipboard."** (status line)
- **Why:** Result of **Copy report**.
- **What to do:** Paste the report where you need it, or try again.

---

## 9. FAQ

**Does Find clashes change anything?**
No. It only reports.

**Can I run it twice?**
It won't notice the openings from the first run, so you'll get **duplicates**. Undo the first run, or delete the old openings, before running again.

**I changed the MEP / ticks / clearances after scanning. Will Create openings use the new values?**
No. **Create openings** uses the **last scan**. Always click **Find clashes** again after changing anything.

**Why is a pipe crossing not cut?**
It may be a fitting, not straight, stop inside the wall, run along the wall, or the wall may be curved. Check the **Unhandled clashes** lines.

**Are openings made in linked walls?**
No. Only walls in your model are changed. Links are only read for their MEP.

**Can I keep working in Revit while the window is open?**
Yes. The window doesn't block Revit.

**Why is a pipe's opening bigger than its size + clearance?**
The pipe crosses the wall at an angle, or several openings were merged.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| **Create openings** greyed out | No scan yet, the scan found nothing, or the last run finished | Click **Find clashes** | ❌ |
| A wall type is missing from the list | It's a curtain/stacked type, or was added after the window opened | Close and reopen the window | ❌ |
| MEP from a link ignored | Link unloaded | Load the link, scan again | ❌ |
| Duplicate openings | Tool was run twice | Delete one set, or undo | ❌ |
| Openings in the wrong place | MEP moved after the scan | Undo, scan again, create again | ❌ |
| Many **[ WARN ]** walls in groups | Single-instance group warning | Tick **Allow walls in single-instance groups** | ❌ |
| **[ WARN ]** with another warning | Revit rejected the change for that wall | Read the warning text | ✅ If unclear |
| Status stuck on **"Queued…"** | Revit is busy | Press **Esc** in Revit to end any running command | ✅ If it stays stuck |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. The **full report** (click **Copy report** and paste it)
2. A **screenshot** of the window and of any error
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **link names**, and the **wall IDs** that went wrong
5. **What you expected**, and what actually happened
