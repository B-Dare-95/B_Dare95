# Create Shaft Param

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Shafts** dropdown → **Create Shaft Param**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🏷️ **Version:** 1.0.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Create Shaft Param** adds the **Shaft Function** parameter to your project in one click.

Several shaft tools in this dropdown read or write **Shaft Function** (for example *Shaft Opening Manager*, *Shaft Function Tag*, *Match Shaft Function*). Run this tool once per project so the parameter is there.

The parameter is created with these settings:

| Setting | Value |
|---|---|
| Parameter Name | **Shaft Function** |
| Category | Shaft Openings |
| Parameter Type | Instance |
| Data Type | Text |
| Group Under | Identity Data |
| Values Vary by Group | Yes |

> 💡 It saves you the trip through **Manage → Project Parameters** and makes sure everyone sets it up the same way.

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Fill in values | The parameter is created **empty**. Fill it in the Properties palette or with **Shaft Opening Manager**. |
| Overwrite an existing parameter | If a parameter called **Shaft Function** already exists in the project, the tool stops and changes nothing. |
| Change your shared parameter file | It uses a temporary file for a moment and then switches Revit back to your own shared parameter file. |
| Add the parameter to linked models | Only the model you're working in gets it. |

---

## 3. Before you start

- [ ] The project you want to set up is **open** and **active**.
- [ ] You're allowed to add project parameters (in a workshared model, you may need the right worksets/permissions).

---

## 4. How to use it

1. Click **Create Shaft Param** in the **Shafts** dropdown.
2. The **Create Project Parameter** window opens. It lists the settings from the table above.
3. Click **OK – Create Parameter** (or press **Enter**).
4. A **Parameter Created** message confirms it. ✅
5. Select any shaft. **Shaft Function** now shows under **Identity Data** in the Properties palette.

To stop, click **Cancel**, press **Esc**, or close the window. Nothing is changed.

📸 *[Screenshot: the Create Project Parameter window]*

> ℹ️ The yellow note in the window says a temporary shared-parameter file is used. That's normal. It's deleted automatically right after.

---

## 5. Undoing

The tool makes **one** change, shown in the Undo list as **Create Shaft Function Parameter**.

Press **Ctrl + Z** right after to remove it. Later, you can remove it in **Manage → Project Parameters**.

> ⚠️ Removing the parameter also removes every value already typed into it.

---

## 6. Messages you may see

🟢 **Parameter Created** — "Parameter 'Shaft Function' was created successfully!"
Lists Category, Type, Group and Vary by Group. All done.

🔵 **Already Exists** — "The parameter 'Shaft Function' already exists in this project. No changes were made."
*Why:* A parameter with that exact name is already in the project.
*What to do:* Nothing. You can use the shaft tools straight away. If the existing one isn't on Shaft Openings, contact the author.

🔴 **Error** — "An error occurred while creating the parameter: …"
*Why:* Revit refused the change. The text after the colon gives the reason. Examples:
- "The 'Shaft Opening' category could not be found in this Revit project…" — this model type doesn't support shafts.
- "Revit could not open the temporary shared-parameter file…" — Windows didn't allow the temporary file.
*What to do:* Screenshot the message and contact the author.

---

## 7. FAQ

**Do I need to run this in every project?**
Yes, once per project. Running it again just shows **Already Exists**.

**Will it mess up my shared parameter file?**
No. Revit is pointed back to your own file when the tool finishes, even if something goes wrong.

**Can I rename the parameter?**
Don't. The other shaft tools look for the exact name **Shaft Function**.

**What does "Values Vary by Group" mean?**
Shafts inside model groups can each have their own Shaft Function value.

---

## 8. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab not loaded | Restart Revit. Look in **Modify** panel → **Shafts** dropdown. | ✅ If it's still missing |
| **Already Exists**, but shafts don't show the parameter | A parameter with that name exists for another category | Check **Manage → Project Parameters** | ✅ |
| **Error** message | Revit refused the change | Screenshot it | ✅ |
| Other shaft tools still say the parameter is missing | Ran it in a different project, or the shafts are in a link | Run it in the model that holds the shafts | ❌ |

---

## 9. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of any message
2. Your **Revit version** (e.g. 2025)
3. The **model name**, and whether it's workshared
4. A screenshot of **Manage → Project Parameters** if the parameter looks wrong
