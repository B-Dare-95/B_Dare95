# Stair Railings

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Stairs** dropdown → **Stair Railings**
> 🧩 **Works with:** Revit 2024 and newer · component stairs and multistory stairs in your own model (not linked models)
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Stair Railings** creates railings on one or more stairs in one go. You pick a **railing type for each side**, and the tool draws the paths for you from the stair's edges.

| Side | What gets created |
|---|---|
| **Inner side** | **One continuous railing** that follows the inner edge of every run and wraps across the landings between them |
| **Outer side** | **One separate railing per run**, along that run's outer edge |

"Inner" is the side of each run **closest to the middle of the stair**, e.g. the edges facing the stairwell gap on a U-shaped stair.

> 💡 Think of a switchback stair from above: the **inner** railing snakes around the stairwell in one piece, the **outer** railings run along the walls, one per flight.

📸 *[Screenshot: a U-shaped stair with the inner (continuous) and outer (per-run) railings]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on linked stairs | Only stairs in the model you're working in. |
| Work on non-component stairs | Older sketch-based stairs are skipped with a note. |
| Delete your existing railings unless you ask | Only if **Delete existing railings on the selected stairs** is ticked. |
| Run outer railings across landings | Outer railings stop at each run's end. Add landing railings by hand if needed. |
| Remember your settings | The window starts with the defaults each time you run the tool. |

---

## 3. Before you start

- [ ] The stair(s) are in **your model**, not in a link.
- [ ] The **railing types** you want exist in the project.
- [ ] The stairs aren't being edited (finish any stair edit mode).
- [ ] *(Optional)* **Select the stairs first.** The tool then skips the picking step.

---

## 4. How to use it

1. *(Optional)* Select one or more stairs in any view.
2. Click **Stair Railings**.
3. If nothing was selected, the status bar says **"Select one or more stairs, then press Finish"**. Click the stairs, then click **Finish** on the Options Bar.
4. The **Stair Railing Manager** window opens. The subtitle shows the stair name, its ID and how many runs and landings it has, or how many stairs you picked.
5. **Inner side:** keep it ticked, pick a railing type, and set the **Inner offset** if needed.
6. **Outer side:** keep it ticked, pick a railing type, and set the **Outer offset** if needed.
7. Set the options at the bottom (see below).
8. Click **Create Railings**.
9. A summary box lists every railing created, with its ID, plus any notes. ✅

📸 *[Screenshot: the Stair Railing Manager window]*

### Window controls

| Control | What it does |
|---|---|
| **Inner side - one continuous railing** (tick box) | Turn the inner railing on or off. |
| **Outer side - one railing per run** (tick box) | Turn the outer railings on or off. |
| **Search boxes** | Filter each railing type list as you type. |
| **Railing type lists** | Pick a type for each side. Nothing is pre-selected, so you must click one. |
| **Inner offset (mm)** / **Outer offset (mm)** | Moves the railing path away from the stair edge. **Positive** = inwards onto the tread. **Negative** = outwards, away from the stair. Default **0** (right on the edge). |
| **Delete existing railings on the selected stairs** | Removes **every** railing already on those stairs before creating the new ones. Off by default. |
| **Host each outer railing on its own run (single-storey only)** | On by default. Each outer railing is attached to its run. When off, it's attached to the whole stair. |
| **Flip the outer railings** | Flips the outer railings to the other side of their path. Off by default. |
| **Plan sketch** (bottom left) | Reminder of which edges are inner (yellow) and outer (blue). |
| **Cancel** | Closes the window. Nothing is created. |
| **Create Railings** | Creates the railings. |

---

## 5. Multistory stairs

- You can pick a **multistory stair**. Every stair inside it is processed.
- Railings on a multistory stair are spread over the same storeys as the stair.
- On multistory stairs, outer railings are always attached to the **whole stair**, even if **Host each outer railing on its own run** is ticked.

---

## 6. Undoing

| You want to… | Do this |
|---|---|
| Stop before anything is created | Press **Esc** while picking, or click **Cancel** in the window. |
| Undo everything the tool did | **Ctrl + Z** once. The whole run, including any deleted railings, is **one** Undo step called **Create Stair Railings**. |

---

## 7. Messages you may see

### Before or in the window

**🔴 "No railing types were found in this project."**
*What to do:* Load or create a railing type, then try again.

**🔴 Status text next to the buttons:** "Enable at least one side." · "Pick a railing type for the inner side." · "Pick a railing type for the outer side." · "The inner offset must be a number in mm." / "The outer offset must be a number in mm."
*What to do:* Fix what the message says, then click **Create Railings** again. Use a dot for decimals.

### In the summary

The summary starts with **"Created [N] railing(s) on [M] stair(s)."**, then one line per railing, e.g. *Stair (id 12345) - inner -> id 67890* or *… - outer run 23456 -> id 67891*. Notes follow under **Notes:**

| Note | Meaning | What to do |
|---|---|---|
| 🔵 "[stair]: deleted N existing railing(s)." | Old railings were removed, as you asked. | — |
| 🟡 "No landing found between two runs - joined them with a straight line." | The inner railing crosses that gap in a straight line. | Check the inner railing at that spot. |
| 🟡 "offset applied per segment" | The offset was applied piece by piece. | Check the corners. |
| 🟡 "offset could not be applied, path left on the edge" | That railing sits right on the stair edge. | Move it by hand if needed. |
| 🟡 "Railing [ID] could not be hosted on the stair." · "Hosting failed for railing [ID]: …" | The railing exists but isn't attached to the stair. | Check that railing. |
| 🟡 "Could not flip railing [ID]: …" | That outer railing wasn't flipped. | Flip it by hand. |
| 🟡 "Could not spread railing [ID] over the storeys: …" · "[stair]: could not read its storey levels: …" | On a multistory stair, the railing may exist on one storey only. | Check the other storeys. |
| 🟡 "[stair]: N run(s) had unreadable edges." | Those runs got no railings. | Add them by hand. |
| 🔴 "[stair]: not a component based stair, skipped." | Sketch-based stair. | Not supported. |
| 🔴 "[stair]: currently in edit mode, skipped." | The stair is being edited. | Finish the edit and run again. |
| 🔴 "[stair]: no run gave a usable pair of side edges." | Nothing created on that stair. | Contact the author. |
| 🔴 "Could not assemble the path: …" · "Revit rejected the path (it must be one open, connected line)." · "Railing.Create returned nothing." | One railing wasn't created. | Screenshot and contact the author. |
| 🔴 "[stair] (id N) failed: …" | Something went wrong on that stair. Other stairs are still done. | Screenshot and contact the author. Check whether its old railings were deleted. |

---

## 8. FAQ

**Which side is "inner" on a single straight flight?**
The tool chooses the side closer to the middle of the stair. On a single straight flight both sides are about the same distance, so either side can end up as "inner". Check the result. If it's the wrong way round, undo and swap the two railing types.

**Can I create only the outer railings?**
Yes. Untick **Inner side** (or the other way round). At least one side must stay ticked.

**What does a positive offset do?**
It moves the railing **inwards onto the treads**. A negative offset pushes it **away** from the stair.

**Will "Delete existing railings" also delete railings I drew myself?**
Yes. It removes every railing on the selected stairs, not just ones made by this tool.

**Can I run it on several stairs at once?**
Yes. Select them all first, or pick them all before clicking **Finish**. The same settings are used for each.

**Does it work on a stair in a linked model?**
No. Open the linked model and run it there.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **Modify** panel → **Stairs** dropdown. | ✅ If it's still missing |
| Can't pick the stair | It's in a link, or you're clicking a railing/landing | Click the stair itself. Linked stairs aren't supported. | ❌ |
| Window doesn't open after selecting | Your selection had no stairs, so the tool asks you to pick | Pick stairs and click **Finish** | ❌ |
| Inner and outer swapped | Single straight flight | See the FAQ | ❌ |
| Railing sits outside / inside the stair | Offset sign | Positive = inwards, negative = outwards | ❌ |
| Outer railing on the wrong face of its path | Flip setting | Tick or untick **Flip the outer railings** | ❌ |
| Inner railing cuts straight across a landing | No landing found between two runs | Check the note | ✅ If there clearly is a landing |
| Old railings gone, no new ones | A stair "failed" after its railings were deleted | Undo (**Ctrl + Z**) | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your settings, and of the summary
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **stair ID(s)**
4. The stair shape (straight, L, U, multistory…)
5. What you **expected**, and what was actually created
