# Callout Creator

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Views** dropdown → **Callout Creator**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Callout Creator** lets you draw **one callout box** in a plan, then place that **same box** in **many plan views at once**, e.g. the same toilet core on every floor.

It has two modes:

| Mode | What it does |
|---|---|
| **View Callout** *(default)* | Creates a callout **and a new plan view** in each chosen view. You set each new view's **name** and **view template**. |
| **Reference Callout** | Creates a callout in each chosen view that **points to a view that already exists** (a plan or drafting view). No new views are created. |

> 💡 Think of it as a stamp: you cut the shape once, then press it onto every floor plan you choose.

📸 *[Screenshot: the Callout Creator window in View Callout mode]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work from sections, elevations, 3D or drafting views | You must start from a **plan view** (floor, ceiling, structural or area). |
| Place callouts in sections or elevations | Only **plan views** are listed as targets. |
| Place callouts in flagged views | Views marked **CROP** or **TEMPLATE** are skipped (see [Section 5](#5-flagged-views-crop-and-template)). |
| Let you choose the view type for new views | Each new view uses the **same view type as the plan it's drawn in**. |
| Draw non-rectangular callouts | The region is always a rectangle. |
| Remember names or settings between runs | Each run starts fresh. |

---

## 3. Before you start

- [ ] Open a **plan view** (floor, ceiling, structural or area plan) where you can see the area you want.
- [ ] Work in a **project**, not a family.
- [ ] For **Reference Callout** mode: the views you want to point to must already exist.
- [ ] Think about names. In **View Callout** mode every new view needs a **unique name**.

---

## 4. How to use it

1. Open a plan view and click **Callout Creator** in the **Views** dropdown.
2. The status bar says **"Pick two opposite corners for the callout region"**. Click two opposite corners of the area.
3. The **Callout Creator** window opens. The top strip shows **REGION SET** with the view you picked in and the size in metres.
4. Under **1 / CALLOUT TYPE**, choose **View Callout** or **Reference Callout**.
5. Under **2 / TARGET PLAN VIEWS**, tick the plan views that should get the callout.
   > ⚠️ **All usable plan views are ticked when the window opens.** Click **None** first, then tick only the views you want.
6. Under **3 / CALLOUT PROPERTIES**, fill in each row (one row per ticked view):
   - **View Callout:** check the **NEW VIEW NAME** and choose a **VIEW TEMPLATE**.
   - **Reference Callout:** choose the **REFERENCED VIEW**.
7. Click **Create _N_ Callouts**.
8. A message tells you how many were created. ✅

### Window controls

| Control | What it does |
|---|---|
| **Re-pick region** | Closes the window so you can pick the corners again. The window then reopens. ⚠️ Names and choices you entered are reset. |
| **Close** (top right) / **Cancel** | Closes the window. Nothing is created. |
| **Title bar** | The window has no standard Windows frame. Drag the top bar to move it. Drag the bottom-right corner to resize it. |
| **View Callout** / **Reference Callout** | Switches the mode. The right-hand table changes to match. |
| **Search box** | Filters the view list by view name. |
| **Applicable only** | When on, hides flagged views (CROP / TEMPLATE). Off by default. |
| **View list** | Tick the plan views that should get a callout. Flagged views can't be ticked. |
| **Footer counter** | `_ selected / _ flagged / _ plan views` |
| **All** / **None** | Ticks every usable view / unticks every view. |
| **Apply row 1 to all** | Copies row 1's **view template** (View Callout mode) or **referenced view** (Reference Callout mode) to every other row. Names are **not** copied. In View Callout mode, the template is only copied to rows where it's available (same plan type). |
| **Summary** (bottom left) | e.g. `3 callouts and 3 new views`, plus how many flagged views will be skipped. |
| **Create _N_ Callouts** | Creates the callouts. Greyed out when no view is ticked. |

### The properties table

| Mode | Columns |
|---|---|
| **View Callout** | **#**, **PARENT VIEW** (where the callout is drawn), **NEW VIEW NAME** (editable), **VIEW TEMPLATE** |
| **Reference Callout** | **#**, **PARENT VIEW**, **REFERENCED VIEW** |

- **NEW VIEW NAME** starts as `Callout of <view name>`. Anything after ` - ` in the view name is dropped. Example: `L01 - Architectural` → `Callout of L01`.
- **VIEW TEMPLATE** lists `(None)` plus templates of the **same plan type** as that row's view (floor plan templates for floor plans, and so on). The row for the view you picked in starts with that view's own template. All other rows start with `(None)`.
- **REFERENCED VIEW** lists every plan view (marked `[plan]`) and every drafting view (marked `[drafting]`). It starts on `-- select a view --`.

---

## 5. Flagged views (CROP and TEMPLATE)

Some views can't show your callout. They're shown with a red tag and can't be ticked.

| Tag | Note shown | Why | What you can do |
|---|---|---|---|
| 🔴 **CROP** | *Region falls outside the active crop box* | The picked area is (partly) outside that view's crop | Enlarge that view's crop, or pick a smaller region |
| 🔴 **TEMPLATE** | *"<name>" turns the Callouts category off* | That view, or its view template, hides **Callouts** in Visibility/Graphics | Turn **Callouts** on in that view or template, then run again |

A view that's already placed on a sheet is **not** flagged. It's a normal target.

---

## 6. Where the callouts go

- Each callout covers the **same rectangle on plan** (same X/Y) in every view you ticked.
- The view you picked the region in is **also in the list**. Untick it if you don't want a callout there.
- In **View Callout** mode, each new view uses the **same view type as its parent view**.
- If a name is taken at the last moment, the tool adds a number, e.g. `Callout of L01 (1)`.

---

## 7. Undoing

All callouts (and new views) from one run are **one Undo step** called **Create Callouts**.

| You want to… | Do this |
|---|---|
| Cancel while picking corners | Press **Esc**. Nothing happens. |
| Close without creating | Click **Cancel** or **Close** |
| Undo the run | Press **Ctrl + Z** once, or pick **Create Callouts** in the Undo list |

---

## 8. Messages you may see

### Before the window opens

🟡 **"Run this from a plan view - floor, ceiling, structural or area."**
*Why:* The active view isn't a plan.
*What to do:* Open a plan view and run the tool again.

🟡 **"Run this in a project, not a family."**
*Why:* You're in the Family Editor.
*What to do:* Switch to a project.

🔵 **"This model has no plan views."**
*Why:* There's nothing to place callouts in.
*What to do:* Create plan views first.

### In the window (bottom left, after clicking Create)

🟡 **"Fix _N_ row(s) before creating"**, followed by the first problem. The problem fields get a **red border**:

| Problem shown | What to do |
|---|---|
| `<view>: new view name is empty` | Type a name |
| `"<name>" is already used by another view in the model` | Choose a different name. Upper/lower case doesn't count as different. |
| `"<name>" is used twice in this list` | Make the names unique. This often happens when two views share the same start, e.g. `L01 - Arch` and `L01 - Mech`. |
| `<view>: no referenced view selected` | Pick a **REFERENCED VIEW** |

### After creating

🟢 **"_N_ callouts created, _N_ new views added."** (View Callout) or **"_N_ reference callouts created."** (Reference Callout)
*Why:* Done.

🟡 **"… _N_ view(s) failed - see the output window."**
*Why:* Revit refused the callout in some views. The output window lists each failed view and the reason. The others were created.
*What to do:* Read the reason. Contact the author if it isn't clear.

---

## 9. FAQ

**Why is every plan view ticked when the window opens?**
That's how the tool starts. Click **None** and tick only the views you need.

**Can I give each new view a different template?**
Yes. Each row has its own **VIEW TEMPLATE** list. Use **Apply row 1 to all** to copy row 1's template.

**Can I choose which view type the new callout views use?**
No. They use the same view type as their parent plan.

**Will the callouts line up between floors?**
Yes. Each one covers the same rectangle on plan.

**I clicked Re-pick region and lost my names.**
Re-picking rebuilds the list for the new region, so names and choices start again.

**Can a reference callout point to a section or a detail view?**
No. Only plan views and drafting views are offered.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Look under **Modify** panel → **Views** dropdown. | ✅ If it's still missing |
| A view I want can't be ticked | It's flagged **CROP** or **TEMPLATE** | See [Section 5](#5-flagged-views-crop-and-template) | ❌ |
| A view I want isn't in the list | It's not a plan view, or it's hidden by search / **Applicable only** | Clear the search, turn off **Applicable only** | ❌ |
| **Create** button greyed out | No view ticked | Tick at least one view | ❌ |
| Callouts appeared in too many views | All views were ticked by default | **Ctrl + Z**, then run again and click **None** first | ❌ |
| My template isn't in the list | It's for a different plan type | Use a template made for that plan type | ❌ |
| Some views failed | Revit refused that callout | Read the output window | ✅ If unclear |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. Which **mode** you used (View Callout or Reference Callout)
2. A **screenshot** of the window, and of the **output window** if something failed
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **view you picked the region in**
5. **What you expected**, and what actually happened
