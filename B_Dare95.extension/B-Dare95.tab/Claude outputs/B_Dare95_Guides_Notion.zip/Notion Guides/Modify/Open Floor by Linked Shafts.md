# Open Floor by Linked Shafts

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Floors** dropdown → **Open Floor by Linked Shafts**
> 🧩 **Works with:** Revit 2024 and newer · flat floors only
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🏷️ **Version:** v5
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Open Floor by Linked Shafts** cuts holes in **one floor** wherever a **shaft opening** passes through it, using the shafts drawn in your **linked models** (and, if you want, in your own model).

The holes follow the **exact shape** of each shaft, curves included. They're drawn into the floor's own boundary, so the result is a normal floor with holes in its sketch.

1. You pick a floor.
2. The tool finds every shaft opening that comes **near that floor**, in every loaded link and in your model.
3. You tick which links to use.
4. The tool rebuilds the floor with the holes cut out and shows a summary.

> 💡 Think of it as a cookie cutter: the linked shafts are the cutters, your floor is the dough.

📸 *[Screenshot: a floor before and after, with linked shafts visible]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Keep the original floor element | The floor is **deleted and replaced** by a new one with the holes. It gets a **new element ID**. See [Section 6](#6-important-the-floor-is-rebuilt). |
| Work on sloped or warped floors | Only flat floors. Sloped ones are refused and nothing changes. |
| Process several floors at once | One floor per run. |
| Update itself when the shafts move | It's a one-time cut. If a shaft moves later, run the tool again on a fresh floor, or edit the sketch by hand. |
| Use links that aren't loaded | Unloaded links are listed but can't be ticked. |
| Use "Opening by Face" or other opening types | Only elements in the **Shaft Opening** category are used. |
| Change the linked models | Links are only read. |

---

## 3. Before you start

- [ ] The floor you want to open is **flat** (not sloped, no shape editing).
- [ ] The links with the shafts are **loaded**.
- [ ] The shafts are drawn as **Shaft Openings** in those links and **reach the floor's height**.
- [ ] Nothing important is **hosted on the floor** (see [Section 6](#6-important-the-floor-is-rebuilt)).
- [ ] The floor is not **pinned** and you can edit it (worksharing: you own it or can borrow it).

---

## 4. How to use it

1. *(Optional)* Select **one** floor first. The tool will use it without asking.
2. Click **Open Floor by Linked Shafts**.
3. If nothing was selected, the status bar says **"Select a floor to open around linked shaft openings"**. Click the floor.
4. The **Floor Opener - Choose Links** window opens. Each card shows a link and how many shafts are near this floor.
5. Tick the links you want to use. Links with shafts near the floor are **ticked for you**.
6. Check the line at the bottom, e.g. **"2 link(s) selected - 14 shaft(s) will be processed"**.
7. Click **Cut openings**.
8. The floor is rebuilt and the **Floor Opener - Done** summary appears. ✅

📸 *[Screenshot: the Choose Links window]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** (top) | Hides cards whose name doesn't contain what you type. |
| **Select all** | Ticks every **visible** card that can be ticked. Works with the search box. |
| **Select none** | Unticks every **visible** card. |
| **Link cards** | One per link, plus **Host document (this model)** at the end. A ticked card gets a yellow border. |
| **Status line** | How many links are ticked and how many shafts will be processed. |
| **Cancel** / window **X** | Closes the window. Nothing changes. |
| **Cut openings** | Starts the cut. If nothing is ticked, it shows **"Select at least one link first."** |

### What the card text means

| Card says | Meaning | Can you tick it? |
|---|---|---|
| **"X near this floor (Y total)"** | X of the file's Y shafts are close to this floor | ✅ |
| **"X shaft(s), none near this floor"** | The file has shafts, but none at this floor's position or height | ❌ |
| **"No shaft openings in this file"** | No shafts at all | ❌ |
| **"Not loaded - cannot be processed"** | The link is unloaded | ❌ |

> 💡 **Host document (this model)** is listed but **not ticked** by default. Tick it only if you also want shafts drawn in your own model to be cut into the sketch.

---

## 5. How the tool decides what to cut

- A shaft counts as **near** the floor when its box overlaps the floor's box in plan **and** its height range reaches the floor (with roughly 30 mm of slack).
- Being "near" is only a first filter. The real check uses the floor's actual outline:

| Shaft position | Result |
|---|---|
| Fully **inside** the floor | A hole is cut. |
| **Across the floor edge** | The floor outline gets a **notch**. Reported as "straddled the floor edge". |
| Inside the floor's box but **outside its real outline** (e.g. in an L-shaped floor's empty corner) | Ignored. Reported as "outside the real outline". |
| Would remove the **whole floor** | Skipped. |

- **Existing holes** in the floor's sketch are kept.
- If the shafts **split the floor into separate pieces**, the tool makes **one floor per piece**.
- If the combined result can't be built as a floor, the tool tries the shafts **one at a time** and skips the ones that cause the problem. The summary tells you when this happened.

---

## 6. Important: the floor is rebuilt

The tool doesn't edit your floor. It **deletes it** and creates a **new floor** with the holes.

**Carried over to the new floor:**
- Floor **type**
- **Level**
- **Height Offset From Level**
- **Structural** setting

**Not carried over:**
- The **element ID** (schedules, notes or other tools that rely on the old ID won't find it)
- Other instance values you typed in, such as **Comments** or **Mark**
- Anything **hosted on** or **attached to** the old floor (for example tags or floor-hosted families)

> ⚠️ After running the tool, check tags, schedules and instance parameters on the new floor.

---

## 7. Undoing

All changes are one step in the Undo list: **"Open Floor Around Linked Shafts"**. Press **Ctrl + Z** once and the original floor comes back.

If the tool stops with a message that says **"Nothing was changed"**, there's nothing to undo.

---

## 8. Messages you may see

All messages appear in a window titled **Floor Opener** (or **Floor Opener - Done** for the summary).

🟢 **"Cut N shaft(s) out of the floor, from M selected source(s)."**
- **Why:** Success. The summary also lists how many floor elements and holes resulted, preserved holes, notches, ignored shafts and skipped items.
- **What to do:** Review the floor. Read any **Skipped** lines.

🟡 **"N floors are selected. Select exactly one floor, or clear the selection to be prompted for a pick."**
- **Why:** More than one floor was selected when you clicked the button.
- **What to do:** Select one floor, or press **Esc** to clear the selection, and run again.

🟡 **"No shaft openings were found near this floor in any loaded link or in the host model. Nothing to cut."**
- **Why:** No shaft overlaps this floor's area and height.
- **What to do:** Check the links are loaded and the shafts reach this level.

🟡 **"No shaft could be cut into this floor. Nothing was changed."**
- **Why:** Every shaft was outside the floor's real outline or was skipped. The message lists them.
- **What to do:** Read the list. See the skip reasons below.

🟡 **"No usable shaft profiles could be built from the selected link(s)."**
- **Why:** The shafts' outlines couldn't be read. The skipped list says why.
- **What to do:** Contact the author with the list.

🔴 **"The floor's boundary is not horizontal (sloped or warped slab). This script only handles flat floors."**
- **Why:** The floor is sloped or shape-edited.
- **What to do:** Not supported. Cut the openings by hand.

🔴 **"Could not read floor sketch: Selected floor has no editable sketch (cannot read its profile)."**
- **Why:** The floor has no sketch the tool can read.
- **What to do:** Contact the author.

🔴 **Other "Could not…" messages** (sketch plane, floor extents, working solid, boundary not flat, boundary encloses no area, no boundary loops)
- **Why:** The floor's own outline couldn't be processed. Nothing was changed.
- **What to do:** Contact the author.

🔴 **"Failed to rebuild floor with openings: …"**
- **Why:** Revit refused the change (e.g. the floor is in a group, pinned, or not editable). Everything was rolled back, so your floor is untouched.
- **What to do:** Check the floor can be edited, then try again. If it repeats, contact the author.

### Skip reasons in the summary

Skipped lines look like **"LinkName.rvt : 481233 - reason"** (link name and the shaft's ID in that link).

| Reason | Meaning |
|---|---|
| **open (unclosed) boundary** / **no boundary curves** / **no closed loops** | The shaft's sketch can't be read as a closed shape. |
| **profile is not horizontal in host coordinates** | The link is tilted relative to your model. |
| **degenerate profile** / **empty profile** | The shaft's shape is too small or has no area. |
| **would consume the entire floor** | The shaft covers the whole floor. |
| **profile became unbuildable, opening not cut** | Revit couldn't build the floor with this hole (often two shafts almost touching). |
| **existing floor hole (… dropped)** | A hole already in the floor couldn't be kept. |
| Other technical reasons | Contact the author. |

---

## 9. FAQ

**Will the holes update if the architect moves a shaft?**
No. The cut is done once. Re-run on a fresh floor or edit the sketch by hand.

**Why did I get two (or more) floors?**
The shafts split the floor into separate pieces. Revit floors must be one piece each, so one floor is made per piece.

**Why is the host model not ticked?**
Shafts in your own model already cut your floors in Revit. Tick it only if you want those shapes drawn into the sketch as well.

**Can I run it on several floors?**
One at a time. Run it again for each floor.

**Is my old floor gone?**
Yes, it's replaced by the new one. **Ctrl + Z** brings it back.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Link card greyed out | Link unloaded, or no shafts near this floor | Load the link. Check the shafts reach this level. | ❌ |
| A shaft wasn't cut | Outside the floor's real outline, or skipped | Read the summary's **outside** and **Skipped** lines | ❌ |
| Floor became several floors | Shafts split it into pieces | Expected behavior | ❌ |
| Tags / Comments / Mark missing afterwards | The floor was rebuilt | Re-add them, or undo and plan ahead | ❌ |
| "not horizontal" for a link's shafts | Link is tilted | Check the link's position | ✅ |
| "Failed to rebuild floor…" | Floor in a group, pinned, or not editable | Check and retry | ✅ If it repeats |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the summary or error message (the full **Skipped** list helps a lot)
2. A screenshot of the **Choose Links** window with your ticks
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the floor's **level** and the **link names**
5. **What you expected** to be cut, and what actually happened
