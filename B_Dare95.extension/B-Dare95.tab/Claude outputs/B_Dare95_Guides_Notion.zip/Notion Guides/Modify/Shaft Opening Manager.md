# Shaft Opening Manager

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Shafts** dropdown → **Shaft Opening Manager**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🏷️ **Version:** 1.0.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Shaft Opening Manager** shows **every shaft in the project** in one table, and lets you edit them all in one place.

For each shaft you can change:

| Column | What you can do |
|---|---|
| **ID** | Read only. **Click** it to select the shaft and zoom Revit to it. |
| **Base Constraint** | Pick a level (or *(Unconnected)*) from a dropdown |
| **Base Offset** | Type a value |
| **Top Constraint** | Pick a level or *(Unconnected)* |
| **Top Offset** | Type a value |
| **Shaft Function** | Type text |
| **✕** | Mark the shaft for **deletion** |

Nothing is changed in the model until you click **Save Changes**. Then all edits and deletions are applied together.

> 💡 Think of it as a schedule for shafts that you can actually edit levels in, without hunting for each shaft in the model.

📸 *[Screenshot: the Shaft Opening Editor window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Edit Unconnected Height | If a shaft's top is *(Unconnected)*, its height can't be changed here. Use the Properties palette. |
| Edit the shape | Only levels, offsets and Shaft Function. |
| Show linked shafts | Only shafts in your own model are listed. |
| Ask before deleting | **✕** hides the row. The shaft is deleted on **Save Changes** without another question. |
| Show a success message | If everything worked, the window just closes. A message appears only when something failed. |
| Sort or filter by column | Use the search box instead. |

---

## 3. Before you start

- [ ] A model is **open** and has at least one shaft.
- [ ] The project has the **Shaft Function** parameter. If not, run **Create Shaft Param** first.
- [ ] You know your **project length units** (offsets are typed in those units, e.g. `1200` for 1200 mm in a millimetre project).
- [ ] In a workshared model, you can edit the shafts.

---

## 4. How to use it

1. Click **Shaft Opening Manager** in the **Shafts** dropdown.
2. The **Shaft Opening Editor** window opens. The title shows how many shafts were found.
3. *(Optional)* Type in the **search box** (top right) to filter rows by ID, level name or Shaft Function.
4. Edit the cells you need:
   - Choose levels from the **Base Constraint** / **Top Constraint** dropdowns.
   - Type new values in **Base Offset**, **Top Offset** or **Shaft Function**.
5. *(Optional)* Click a shaft's **ID** to select it and zoom to it in Revit. The window stays open, so you can look at the model while editing.
6. *(Optional)* Click **✕** at the end of a row to mark that shaft for deletion. The row disappears.
7. Click **Save Changes**. All edits and deletions are applied in one go. ✅

📸 *[Screenshot: a row being edited, with the level dropdown open]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** | Shows only rows whose ID, Base/Top level name or Shaft Function contains the text. Upper/lower case doesn't matter. |
| **ID** (click) | Selects the shaft in Revit and zooms to it. |
| **Level dropdowns** | All levels, lowest first. *(Unconnected)* is at the top. |
| **Offset boxes** | Type a number in project units. You can also type a unit, e.g. `1200 mm`. |
| **Shaft Function box** | Free text. |
| **✕** | Marks the shaft for deletion (applied on Save). |
| **Save Changes** | Applies everything and closes the window. |
| **Cancel** / window **X** | Closes without changing anything. |

---

## 5. Things to know about offsets

- Values are shown the way Revit displays them (e.g. `1200` or `1200 mm`), using your project units and rounding.
- When you **Save**, the value in every box is written back to its shaft, **including rows you didn't touch**.

> ⚠️ Because values are shown rounded, saving can round very small fractions off offsets, even on untouched shafts. If your offsets have more decimals than your project units display, check them after saving, or contact the author.

---

## 6. Undoing

All edits and deletions from one **Save Changes** are **one** Undo entry: **Edit Shaft Opening Properties**.

Press **Ctrl + Z** once to undo everything from that save, including deletions.

Clicking an **ID** only selects the shaft, so it adds nothing to the Undo list.

---

## 7. Messages you may see

🔵 **"No Shaft Openings were found in the current document."**
*Why:* The model has no shafts.
*What to do:* Nothing to manage.

🔴 **"The parameter "Shaft Function" was not found on any Shaft Opening in this document."**
The message suggests adding it via **Manage → Project Parameters**.
*What to do:* The easiest way is to run **Create Shaft Param**, then run this tool again.

🟡 **Shaft Editor — Warnings** — "Some changes could not be applied:"
Followed by up to 20 lines like `ID 123456 — Base Offset: <reason>` or `ID 123456 — delete failed: <reason>`.
*Why:* Revit refused that one value, e.g. an offset that isn't a number, or a level combination that doesn't work. Everything else was still saved.
*What to do:* Fix those shafts in the Properties palette or run the tool again.

🔴 **"Transaction failed: …"** (first line of the warnings)
*Why:* The whole save was refused by Revit.
*What to do:* Nothing was changed. Screenshot it and contact the author.

---

## 8. FAQ

**Do my changes apply as I type?**
No. Nothing happens to the model until **Save Changes**.

**I clicked ✕ by mistake. Can I get the row back?**
Click **Cancel** and start again. If you already saved, press **Ctrl + Z**.

**I cleared the search and a row I deleted came back.**
It's still marked for deletion and will be deleted on Save. To keep it, click **Cancel** and start again.

**Can I set the top to *(Unconnected)*?**
Yes. Pick *(Unconnected)* in **Top Constraint**. The height isn't editable here, so check it in Properties afterwards.

**Can I set the Base Constraint to *(Unconnected)*?**
No. A shaft needs a base level. Revit refuses it, and the row shows up in the warnings.

**Can I edit linked shafts?**
No. Open the linked model and run the tool there.

**Does the search update after I change a value?**
No. The search looks at the values as they were when the window opened.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab not loaded | Restart Revit. Look in **Modify** panel → **Shafts** dropdown. | ✅ If it's still missing |
| "Shaft Function not found" | Parameter missing | Run **Create Shaft Param** | ❌ |
| An offset came out hugely wrong | The value couldn't be read in project units | Type the value with its unit, e.g. `1200 mm`. Undo and retry. | ✅ If it repeats |
| Some changes not applied | Revit refused those values | Read the warning lines | ❌ |
| A deleted row reappeared | Search was changed | It's still marked for deletion. Cancel if you want to keep it. | ❌ |
| Clicking an ID doesn't zoom | The shaft isn't visible in the active view | Switch to a plan or 3D view where it's visible | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the editor window before you saved
2. A **screenshot** of any warning message
3. Your **Revit version** (e.g. 2025) and **project length units**
4. The **model name** and the **IDs** of the shafts involved
5. **What you expected**, and what actually happened
