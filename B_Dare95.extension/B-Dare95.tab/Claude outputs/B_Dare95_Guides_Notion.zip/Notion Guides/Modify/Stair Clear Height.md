# Stair Clear Height

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Stairs** dropdown → **Stair Clear Height**
> 🧩 **Works with:** Revit 2024 and newer · section and elevation views · stairs in your model or in a loaded Revit link
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Stair Clear Height** draws a **clear-height line** above a stair run in a section or elevation.

The line follows the **pitch of the stair**: it passes through the **nosing tip** of every step, then it's lifted straight up by the height you choose (default **2100 mm**). Anything that cuts below that line is a headroom clash you can spot at a glance.

- A **straight** run gets **one** line.
- A **curved** run gets a chain of short lines, one between each pair of steps.
- You choose the line style and height once, then click run after run. Press **Esc** to finish.
- At the end, a **report window** lists what was drawn for each run.

> 💡 Think of it as an imaginary ceiling floating 2100 mm above the stair's slope. Anything below it is in someone's way.

📸 *[Screenshot: a stair in section with the clear-height line above it]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Check for clashes | It only draws the line. You check what crosses it. |
| Work outside sections and elevations | Plans, 3D and drafting views are refused. |
| Draw over landings | Lines are drawn per run only. |
| Update itself | The lines are plain detail lines. If the stair changes, delete them and run again. |
| Show the line in other views | Lines are drawn **only in the view you ran it in**. |
| Remember your settings | The window starts with the defaults each time you run the tool. |

---

## 3. Before you start

- [ ] A **section or elevation** view is open and active.
- [ ] The stair is **visible** in the view. A section cut **along** the stair works best.
- [ ] You know whether the stair is in **your model** or in a **linked model**.
- [ ] The **line style** you want exists in the project.

---

## 4. How to use it

1. Open the section or elevation and click **Stair Clear Height**.
2. A box asks **"Where is the stair?"** Click **Active model** or **Linked model**.
3. The **Stair Clear Height Line** window opens. The yellow label confirms your choice (Active model / Linked model).
4. Pick a **Line style**. The first style in the list is pre-selected.
5. Set the **Vertical offset (mm)**. The default is **2100**.
6. Keep or untick **Measure from the nosing tip** (see [Section 5](#5-the-nosing-option)).
7. Click **Start Picking**.
8. **Click a stair or a single run.** The line appears straight away. If you click a whole stair, every run gets its own line.
9. Keep clicking other runs or stairs.
10. Press **Esc** when you're done. The **report window** opens. ✅

📸 *[Screenshot: the Stair Clear Height Line settings window]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** | Filters the line style list as you type. The first match is selected. |
| **Line style** list | The style for the clear-height line. |
| **Vertical offset (mm)** | How far above the nosing line the clear-height line is drawn. |
| **Measure from the nosing tip (include nosing projection)** | Ticked by default. See below. |
| **Cancel** | Closes the window. Nothing is drawn. |
| **Start Picking** | Starts picking runs. |

---

## 5. The nosing option

| Setting | Where the line is measured from |
|---|---|
| ✅ **Ticked** (default) | The **front edge of each nosing**, using the nosing length set in the stair run type. |
| ⬜ **Unticked** | The **face of each riser**, ignoring the nosing. |

If the run type has no nosing, both settings give the same line.

---

## 6. The report window

After you press **Esc**, the **Stair Clear Height Line - Report** window opens.

- The **yellow summary** at the top says one of:
  - 🟢 *"[N] line(s) created across [M] run(s), offset [X] mm, line style '[style]'. All of it is one undo step."*
  - 🔵 *"Nothing was created."*
  - 🔴 *"Finished with errors - see the log below."*
- The **log** below it has one line per run, e.g.
  `Run 123456 | 12 risers @ 175 mm | 12 nosing points | nosing 25 mm | 1 line(s)`
  Notes about that run appear indented underneath.
- Use the **search box** to filter the log, e.g. type a run ID.
- Click **Close** when you're done.

---

## 7. Undoing

| You want to… | Do this |
|---|---|
| Stop before anything is drawn | Click **Cancel** in the box or the window, or press **Esc** right away. |
| Undo everything | **Ctrl + Z** once. All lines from the whole session are **one** Undo step called **Stair Clear Height Line**. |
| Remove a single line later | Select it and delete it. |

---

## 8. Messages you may see

### When starting

**🔴 "Open a section or elevation view and run the tool again."**
*What to do:* Open a section or elevation.

**🔴 "This tool only runs in a Section or Elevation view. Current view is a [view type]."**
*What to do:* Switch to a section or elevation.

**🔴 "No line styles found in this project."**
*What to do:* Create a line style, then try again.

**🔴 "Pick a line style first."** · **"The vertical offset must be a number in millimetres."**
*What to do:* Select a style, or type a plain number (e.g. `2100`). Use a dot for decimals.

### In the report log

| Log line | Meaning | What to do |
|---|---|---|
| 🔵 "Run [ID] \| already drawn, skipped." | You picked that run twice in this session. | Nothing. It's only drawn once. |
| 🔵 "Nothing usable was picked - pick again or press Esc." | The click didn't land on a usable stair. | Pick again. |
| 🔵 "No runs were picked." | You pressed **Esc** without picking. | — |
| 🟡 "Riser height was not published by the API - derived from the run geometry." | The riser height was calculated. | Check the line looks right. |
| 🟡 "Path elevation disagreed with the run geometry by X mm - base taken from the top of the solid instead." | The tool corrected the height using the run's 3D shape. | Check the line height. |
| 🔵 "Run footprint runs X mm past the riser span - points anchored on the risers, not on the ends of the path." | The run's last tread runs past the top riser. The line still stops at the riser. | Nothing. |
| 🟡 "Riser span exceeds the path length - points spread evenly along the path instead of by tread depth." · "Tread depth unavailable - points spread evenly along the path." | The steps were spaced evenly instead. | Check the line follows the nosings. |
| 🔴 "Run [ID] \| resulting line is too short, skipped." | The line would be too short to draw, e.g. the run is seen end-on in this view. | Use a section cut along the stair. |
| 🔴 "Run [ID] \| Could not read the run path: …" · "GetStairsPath() returned nothing for this run." · "Riser height could not be read from the run, the parent stair, or derived from the geometry." · "Riser count could not be established." | The tool couldn't read this run. Nothing drawn for it. | Contact the author if it's a normal run. |
| 🔴 "Run [ID] \| creation failed, that pick was rolled back: …" | Revit refused to draw the line(s) for that pick. | Try another line style. If it repeats, contact the author. |
| 🔴 "Selection failed: …" · "Could not assimilate the transaction group: …" | Something unexpected happened. | Screenshot and contact the author. |

---

## 9. FAQ

**Why 2100 mm?**
It's only the default. Type any height you need in **Vertical offset (mm)**.

**Can I draw the line below the stair?**
The tool accepts any number, including negative ones. A negative offset draws the line below the nosings.

**I clicked the whole stair. Why are there several lines?**
Each run gets its own line. The landings in between aren't covered.

**The line came out vertical or very short.**
The run is seen end-on in this view. Use a section that cuts **along** the run.

**Does it work on linked stairs?**
Yes. Choose **Linked model** at the start. The lines are drawn in your model, in the current view.

**My chosen line style caused "creation failed".**
Some special system styles (e.g. *&lt;Room Separation&gt;*, *&lt;Area Boundary&gt;*) appear in the list but can't be used for normal lines. Pick a regular style.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **Modify** panel → **Stairs** dropdown. | ✅ If it's still missing |
| Tool refuses to start | Not in a section/elevation | Open a section | ❌ |
| Can't click the stair | Wrong choice in "Where is the stair?" | Restart and choose the other option | ❌ |
| Line is at the wrong height | Wrong offset, or nosing option | Check the offset and the nosing tick box | ❌ |
| Line is short or vertical | Run seen end-on | Use a section along the stair | ❌ |
| "creation failed" for every pick | System line style chosen | Pick a regular line style | ❌ |
| Second stair in a link skipped as "already drawn" | Same run ID seen earlier in this session | Run the tool again for that stair | ✅ |
| Line doesn't follow the nosings | Steps spaced evenly (see log) | Check the notes in the report | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the settings window and of the **report window**
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **section/elevation** you were in
4. Whether the stair was in your model or in a **link**
5. The **run ID(s)** from the report, and what you **expected** the line to look like
