# Room Letter Case

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Rooms** dropdown → **Room Letter Case**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Room Letter Case** changes the letter case of a room text parameter (for example the room **Name**) for **every room in the model** in one go. It can also add a **prefix** and/or **suffix** at the same time.

| Option | Example: `Meeting room` becomes… |
|---|---|
| **UPPERCASE** | `MEETING ROOM` |
| **lowercase** | `meeting room` |
| **Title Case** | `Meeting Room` |
| Prefix `L01-` + UPPERCASE | `L01-MEETING ROOM` |

> 💡 Think of it as "Change Case" in Word, but for all your room names at once.

📸 *[Screenshot: the Room Name Formatter window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on a selection | It changes **all rooms in the model**, including unplaced rooms. You can't limit it to one level or a few rooms. |
| Remember a prefix/suffix it added before | Running it again with the same prefix adds it **again** (`L01-L01-…`). |
| Keep spaces at the start or end of the prefix/suffix | Leading and trailing spaces are removed. `L01 - ` becomes `L01 -`. |
| Keep acronyms in Title Case | **Title Case** makes the rest of each word lowercase: `HVAC ROOM` → `Hvac Room`. |
| Change rooms in linked models | Only rooms in the model you're working in. |

---

## 3. Before you start

- [ ] The model has **rooms**.
- [ ] You know which **parameter** you want to change (usually **Name**).
- [ ] If you plan to add a prefix/suffix, make sure it isn't **already there** (see Section 2).
- [ ] If you work in a shared model, the rooms aren't owned by someone else.

---

## 4. How to use it

1. Click **Rooms** dropdown → **Room Letter Case**.
2. The **Room Name Formatter** window opens.
3. Pick the **Room Parameter**. **Name** is chosen for you if it exists.
4. Click a **Casing Operation**: **UPPERCASE**, **lowercase** or **Title Case**. The chosen one is highlighted (UPPERCASE is the default).
5. *(Optional)* Type a **Prefix** and/or **Suffix**.
6. Click **Apply**.
7. A message shows how many rooms were updated, and the window closes. ✅

### Window controls

| Control | What it does |
|---|---|
| **Room Parameter** | Lists every **text** parameter found on your rooms (Name, Number, Comments, Department…). |
| **UPPERCASE / lowercase / Title Case** | Choose one. The highlighted button is the one that will be used. |
| **Prefix (optional)** | Text added **in front** of every value. |
| **Suffix (optional)** | Text added **at the end** of every value. |
| **Apply** | Changes all rooms and closes the window. |
| **Cancel** | Closes the window. Nothing changes. |

> ⚠️ **Empty values:** if a room's parameter is empty, it gets only the prefix and suffix (e.g. just `L01-`).

---

## 5. Undoing

All changes are made in **one step**. To undo everything, press **Ctrl + Z** once, or pick **Room Name Formatter** in Revit's Undo list.

---

## 6. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🟢 **"Done!  _N_ room(s) updated."** | The tool finished. | Check a few rooms. |
| 🟡 **"_N_ room(s) skipped (read-only or error)."** (under the Done line) | Some rooms couldn't be changed. | Check those rooms aren't in a group, or owned by someone else. |
| 🔵 **"No rooms found in the project."** | The model has no rooms. | Nothing to do. |
| 🔵 **"No text parameters found on rooms."** | The rooms have no text parameters. | Contact the author if this looks wrong. |
| 🔵 **"Please select a parameter."** | No parameter was chosen. | Pick one from **Room Parameter**. |

---

## 7. FAQ

**Does it change only the rooms I selected?**
No. It changes **every room** in the model.

**Does the "updated" number mean values actually changed?**
Not always. It counts every room the tool wrote to, even if the value was already in that case.

**Can I remove a prefix with this tool?**
No. It only adds. Remove it by hand or undo the run.

**Why did my spaces disappear from the prefix?**
Spaces at the start and end of the prefix and suffix are trimmed. Spaces in the middle are kept.

**Can I use it on Number or Comments?**
Yes. Any text parameter in the list can be used.

---

## 8. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If still missing |
| Prefix appears twice | Tool run twice with the same prefix | Undo, then run once | ❌ |
| Acronyms became `Hvac`, `Mep` | Title Case lowercases the rest of each word | Use **UPPERCASE**, or fix those rooms by hand | ❌ |
| Some rooms didn't change | Parameter read-only, rooms in a group, or not owned by you | Check worksharing ownership and groups | ❌ |
| My parameter isn't in the list | It isn't a text parameter | Only text parameters are listed | ✅ If it should be there |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 9. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your choices, and of any message
2. Your **Revit version** (e.g. 2025)
3. The **model name**
4. The **parameter**, **case option**, **prefix** and **suffix** you used
5. **What you expected**, and what actually happened
