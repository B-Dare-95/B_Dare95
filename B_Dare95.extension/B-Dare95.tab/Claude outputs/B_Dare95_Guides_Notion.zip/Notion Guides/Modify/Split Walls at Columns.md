# Split Walls at Columns

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Walls** dropdown → **Split Walls at Columns (Select)**
> 🧩 **Works with:** Revit 2024 and newer · columns from the host model and all loaded links
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Split Walls at Columns** cuts walls **at the columns** that sit in them. Each wall is broken into separate pieces that **stop at the column faces**, so the wall no longer runs through the columns.

- Columns can be in **your model** or in **any loaded link**.
- Both **Columns** and **Structural Columns** count.
- You choose the walls by **drawing a box** around them.
- Before anything changes, the tool tells you how many walls need splitting and asks you to confirm.
- When a round is done, you can **select more walls** without restarting the tool.

> 💡 Think of it as cutting a long ribbon wherever it passes behind a post, and throwing away the bits hidden by the posts.

📸 *[Screenshot: a wall running through three columns, before and after]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Keep the wall inside the column | The part of the wall **inside the column's footprint is removed**, not just split. |
| Keep the original wall element | The wall is **replaced by copies**, one per piece. Each piece has a **new element ID**. |
| Work on curved, stacked or curtain walls | Only **straight Basic** walls. Others are skipped and counted. |
| Change linked models | Columns in links are only read. Only walls in your model change. |
| Split columns, floors or other elements | Walls only. |
| Use the column's exact shape | It uses the column's **outer box**. Round or rotated columns can cut a slightly bigger gap. |

---

## 3. Before you start

- [ ] A **plan view** (or any view where you can box-select walls) is active.
- [ ] Linked models with columns are **loaded**. Unloaded links are skipped.
- [ ] The walls are **editable** (worksharing: you own them or can borrow them) and not pinned.
- [ ] You've noted any **tags** or **dimensions** on the walls. The original wall is deleted, so these may need redoing.

---

## 4. How to use it

1. Click **Split Walls at Columns (Select)**.
2. The status bar says **"Draw a rectangle around the walls to process (only walls will be picked)"**. Drag a box around the walls. Only walls are picked.
3. A summary appears, e.g.:
   *"Selected 12 wall(s). 5 of them need splitting, into 14 wall segment(s) total. 2 skipped (curved/stacked/curtain/unreadable/no column). Proceed with the split?"*
4. Click **Yes** to split, or **No** to cancel this round.
5. The **Round complete.** message shows what happened. It ends with **"Select more walls to process?"**
6. Click **Yes** to draw another box, or **No** to finish. ✅

> 💡 Press **Esc** while drawing the box to stop the tool at any time.

---

## 5. How the split works

### Which columns count

A column cuts a wall when:
- it **touches the wall**, or stands within about **150 mm** of the wall's line, **and**
- its height range **overlaps** the wall's height range.

### Which pieces are kept

| Situation | Result |
|---|---|
| Wall passes through a column | Two pieces, each ending at a column face |
| Two columns closer than about **150 mm** to each other | Treated as one column. The tiny piece between them isn't kept. |
| A piece at the wall's end shorter than about **30 mm** | Not kept |
| The whole wall is inside columns | Skipped, nothing changes (*"wall fully consumed by column(s)"*) |
| No column touches the wall | Left alone (not counted as skipped in the round report) |

### What happens to doors, windows and openings

- Each door, window or opening **stays on the piece it sits in**, with its type and values unchanged.
- If it sits **inside a column** or **straddles a column face**, it can't be kept. It's **removed** and its **ID is listed** in the round report so you can re-place it.

### Wall joins

- The new ends at the column faces are allowed to **join** with what's around them.
- The outer ends keep the **same join setting** as the original wall.

---

## 6. Undoing

Each **round** (one box + **Yes**) is a single step in the Undo list: **"Split Walls at Columns (Selection)"**. Press **Ctrl + Z** once to undo the whole round. If you ran several rounds, undo once per round.

If you answered **No** at the confirmation, nothing changed and there's nothing to undo.

---

## 7. Messages you may see

All messages appear in a window titled **Split Walls at Columns**.

🟢 **"Round complete. Walls split: X / Y"**
- **Why:** The round finished. It may also list *"Skipped in this selection"*, walls that failed, hosted elements that couldn't be kept, and unloaded links.
- **What to do:** Read any extra lines. **Yes** to continue, **No** to finish.

🔵 **"Selected N wall(s). … Proceed with the split?"**
- **Why:** Confirmation before any change.
- **What to do:** **Yes** to split, **No** to cancel this round.

🔵 **"Split cancelled. Select more walls?"**
- **Why:** You answered **No** at the confirmation. Nothing changed.
- **What to do:** **Yes** to draw a new box, **No** to finish.

🟡 **"None of the N selected wall(s) need splitting. … Select more walls?"**
- **Why:** No column touches the walls you boxed, or they were all skipped (curved, stacked, curtain, fully inside columns).
- **What to do:** Box different walls, or check the columns are loaded.

🟡 **"No walls were picked. Select more walls?"**
- **Why:** The box didn't catch any walls.
- **What to do:** **Yes** and draw a bigger box.

🟡 **"Hosted elements that could NOT be preserved (inside a column footprint, or straddling a column face) - please re-place manually:"** followed by IDs
- **Why:** Those doors, windows or openings were removed with the original wall.
- **What to do:** Note the IDs. Either re-place those elements by hand, or **undo** the round (**Ctrl + Z**), use **Manage → Select by ID** to find them, move them clear of the columns, and run again.

🟡 **"Unloaded links skipped: …"**
- **Why:** Some links weren't loaded, so their columns weren't used. Shown once, in the first round report.
- **What to do:** Load the links and run again if their columns matter.

🔴 **"Walls skipped due to errors (no changes made to these):"** followed by **"Wall 123456: …"**
- **Why:** Revit refused to split those walls. They're left as they were.
- **What to do:** Note the IDs and the message. Contact the author if unclear.

🔴 **"No columns found in the active document or any loaded links (checked "Columns" and "Structural Columns" categories). Nothing to do."**
- **Why:** No columns in the model or loaded links.
- **What to do:** Load the structural link, then try again.

---

## 8. FAQ

**Why is the wall now missing inside the columns?**
That's the purpose of the tool: walls stop at column faces instead of running through them.

**Do the new pieces keep the wall's type and parameters?**
Yes. Each piece is a copy of the original wall.

**Do tags on the wall survive?**
The original wall is deleted, so tags and dimensions attached to it may need redoing.

**Can I select walls first and then click the button?**
No. The tool always asks you to draw a box.

**Why didn't a column split the wall?**
It may be more than about 150 mm from the wall, at a different height, or in an unloaded link.

**Can I run several rounds?**
Yes. Answer **Yes** to *"Select more walls to process?"*. Each round is its own Undo step.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Wall not split | No column close enough, or wall curved/stacked/curtain | Check distance and wall type | ❌ |
| Linked columns ignored | Link unloaded | Load it, run again | ❌ |
| Gap wider than the column | Round or rotated column (its outer box is used) | Adjust the wall ends by hand | ❌ |
| Small piece between two columns vanished | Columns less than ~150 mm apart | Expected behavior | ❌ |
| Door or window disappeared | It was inside or across a column face | Check the round report's ID list | ❌ |
| Tags or dimensions lost | Original wall was deleted | Re-tag / re-dimension | ❌ |
| Walls listed under errors | Revit refused the change | Note the message | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the round report or error
2. A screenshot of the **plan** showing the wall and columns
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **view**, and the **wall IDs** involved
5. **What you expected**, and what actually happened
