# Corner Guard Placer

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Columns** dropdown → **Corner Guard Placer**
> 🧩 **Works with:** Revit 2024 and newer · **2D plan views only** (floor, ceiling, structural or area plan)
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🏷️ **Version:** 2.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Corner Guard Placer** puts a **corner guard family** on every outside corner of the columns you pick, already turned to face the right way.

- Columns can be in **your model** or in a **linked model**.
- The guards are always created in **your** model, on the **level of the plan view you have open**.
- It reads the column's real outline, so **rotated** columns and shapes like **L** or **T** columns work too.

> 💡 Think of it as snapping a protective corner strip onto every sharp outside corner of the column, all at once.

📸 *[Screenshot: a column in plan with four corner guards placed]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Guard round or curved corners | Only **straight, roughly 90°** corners (within 5°) get a guard. Round columns get none. |
| Guard inside corners | The inner corner of an **L** or **T** column is skipped. |
| Guard chamfered corners | A chamfer isn't a 90° corner, so it's skipped. |
| Use the column's own level | Guards go on the **active view's level**. |
| Check for existing guards | Running it twice places **two** guards on each corner. |
| Run in 3D, section or elevation views | It stops and asks you to open a plan view. |
| Fix a wrongly-built family | The guard family must be drawn to fit a **top-left corner** when not rotated (see Section 5). |

---

## 3. Before you start

- [ ] A **plan view** of the level you want the guards on is **open and active**.
- [ ] A **corner guard family** is loaded. It should be a **Specialty Equipment** or **Generic Model** family (others can be shown, see Section 4).
- [ ] The family is **not hosted** (doesn't need a wall or face) and fits a **top-left** corner at 0° rotation.
- [ ] If the columns are in a link, the link is **loaded and visible**.

---

## 4. How to use it

1. Open the plan view for the target level.
2. Click **Columns** dropdown → **Corner Guard Placer**.
3. A dialog asks **"Where are the columns?"**. Click:
   - **Active document** — columns modelled in this project, or
   - **Linked model** — columns inside a loaded Revit link.
4. The **Corner Guard Placer** window opens. The top lines show the source and **"Placing on _Level_ (from view _View_)"**.
5. Click a family type under **GUARD FAMILY TYPE** (type in the box above the list to filter).
6. Click **Pick columns and place**. The window closes.
7. Click the columns. Revit's status bar says **"Pick columns in the active document, then Finish"** or **"Pick columns in a link, then Finish"**.
8. Click **Finish** on the Options Bar (top left).
9. A summary appears. ✅

📸 *[Screenshot: the Corner Guard Placer window]*

### Window controls

| Control | What it does |
|---|---|
| **Source** line (yellow) | "Source: active document" or "Source: linked model". |
| **Placing on…** line | The level the guards will go on, and the view it came from. |
| Search box | Filters the family type list as you type. |
| **GUARD FAMILY TYPE** list | Family types as **Family : Type**. By default only **Specialty Equipment** and **Generic Models**. |
| **Show all categories** | Lists family types from **every** category. |
| **Pick columns and place** | Starts column picking. |
| **Cancel** | Closes the window. Nothing is placed. |

---

## 5. How guards are placed and turned

- A guard is placed exactly **at each outside corner point**, at the **height of the view's level**.
- Each guard is **rotated** to face out from its corner.
- The rotation assumes your family, when placed **unrotated**, fits the **top-left** corner of a column. If your guards come out facing the wrong way, the family is probably built for a different corner. Contact the author.

---

## 6. Undoing

All guards from one run are placed in **one step**. To undo, press **Ctrl + Z** once, or pick **Place Corner Guards** in Revit's Undo list.

---

## 7. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🟢 **"_N_ guards placed on _N_ columns. Level: … (from view …)."** | Done. | Check the guards. |
| 🟡 **"_N_ columns skipped entirely."** (in the summary) | Those columns had no usable corner. | Usually round/curved columns. Place by hand if needed. |
| 🟡 **"_N_ guards failed."** (in the summary) | Some guards couldn't be placed or rotated. | Check those columns. Contact the author if it repeats. |
| 🔵 **"No columns picked. Script cancelled."** | You pressed **Esc** or picked nothing. | Run again. |
| 🔴 **"Corner Guard Placer only runs in a 2D plan view (floor, ceiling, structural or area plan)…"** | Active view isn't a plan. | Open a plan view. |
| 🔴 **"The active view is a view template…"** | A view template is active. | Open a real plan view. |
| 🔴 **"The active plan view '…' has no associated level…"** | The plan has no level. | Use a plan view that belongs to a level. |
| 🔴 **"No placeable corners found."** + a list of columns | None of the picked columns had a usable corner. Reasons include "no solid geometry", "no usable footprint (round column, or cut base)" and "no convex 90-degree corners". | Pick rectangular columns, or place by hand. |
| 🟡 Top line turns to **"Pick a family type before running."** | No type selected. | Click a type in the list. |
| 🔴 **"Run failed and was rolled back: …"** | Something failed. Nothing was placed. | Screenshot it and contact the author. |

> ℹ️ Clicking **Cancel** on the "Where are the columns?" dialog or in the window ends the tool quietly, with no message.

---

## 8. FAQ

**How many guards does a column get?**
One per outside 90° corner. A rectangle gets 4. An L-shaped column gets 5 (its inside corner is skipped).

**Why are my guards on the wrong level?**
They go on the level of the **plan view you had open**. To guard columns on Level 3, open the Level 3 plan and run.

**Why can't I find my family in the list?**
By default only Specialty Equipment and Generic Model types are listed. Tick **Show all categories**.

**My guards face the wrong way.**
The family probably isn't built for the top-left corner at 0°. Contact the author.

**Does it work on sloped or tapered columns?**
It uses the column's **bottom** outline. Results on sloped columns may not match higher up.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab. | ✅ If still missing |
| Tool stops right away | Active view isn't a plan | Open a floor/ceiling/structural/area plan | ❌ |
| Can't click columns | Wrong source chosen, or link not visible | Run again and pick the other source | ❌ |
| Family not listed | Category filter | Tick **Show all categories** | ❌ |
| Round column has no guards | Only straight 90° corners are used | Place by hand | ❌ |
| Guards face the wrong way | Family not set up for top-left at 0° | Check the family | ✅ |
| Guards at wrong height | Wrong active view | Undo, open the right plan, run again | ❌ |
| Double guards | Tool run twice | Undo or delete the extras | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the summary or error, and of a guard that came out wrong
2. Your **Revit version** (e.g. 2025)
3. The **model name**, the **view** you were in, and whether the columns were in a **link**
4. The **guard family and type** you used
5. **What you expected**, and what actually happened
