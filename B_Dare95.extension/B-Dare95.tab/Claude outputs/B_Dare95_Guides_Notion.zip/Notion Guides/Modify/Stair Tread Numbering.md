# Stair Tread Numbering

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Stairs** dropdown → **Stair Tread Numbering**
> 🧩 **Works with:** Revit 2024 and newer · plan views · stairs in your model or in a loaded Revit link
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Stair Tread Numbering** puts a **numbered bubble** on each tread of a stair run in your plan view: a **circle** with the **tread number** in the middle.

You pick a stair run, and the tool walks **up** the run one step at a time:

- Every tread is numbered, **up to the view's cut plane**. The first tread that sits above the cut plane is the **last one numbered**.
- If the walk hasn't reached the cut plane yet, the **landing at the top** of the run gets the next number too.
- Numbers **continue through the whole stair**. If you pick the second run, it carries on from the run below. It doesn't restart at 1.
- The first number comes from the stair's **Tread/Riser Start Number** property. If the stair doesn't have it, numbering starts at **1**.

You can keep picking runs one after the other until you press **Esc**.

> 💡 Think of it as someone walking up the stair with a stamp, numbering each step until their head reaches the cut plane.

📸 *[Screenshot: a stair in plan with numbered bubbles on each tread]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Use a tag family | Each bubble is a **detail circle + a text note**. They don't update if the stair changes. |
| Update itself | If the stair is edited later, delete the old bubbles and run the tool again. |
| Check for existing numbers | Picking the same run twice puts **a second set of bubbles** on top of the first. |
| Work outside plan views | Sections, elevations, 3D and drafting views are refused. |
| Number past the cut plane | Treads above the first one that crosses the cut plane are left out. That's on purpose. |
| Show the bubbles in other views | The circles and text are drawn **only in the view you ran it in**. |

---

## 3. Before you start

- [ ] A **plan view** is open and active.
- [ ] The view's **cut plane** is set where you want numbering to stop.
- [ ] You know whether the stair is in **your model** or in a **linked model**.
- [ ] The text note type and line style you want for the bubbles exist in the project.
- [ ] *(Optional)* The stair's **Tread/Riser Start Number** is set to the first number you want.

---

## 4. How to use it

1. Open the plan view and click **Stair Tread Numbering**.
2. The **Stair Tread Numbering** window opens. The top shows the view name and its cut plane (e.g. *Cut plane: Level 01 +1200 mm*).
3. Choose the **Stair source**: **Active Model** or **Linked Model**.
4. Pick a **Text note type** for the numbers.
5. Pick a **Circle line style** for the bubbles.
6. Set the **Circle diameter**, **Bubble position** and **Offset** (see [Section 5](#5-bubble-size-and-position)).
7. Click **Start Numbering**. The window closes.
8. **Click a stair run** in the view. Press **Tab** to cycle if the run is hard to click. The bubbles appear straight away.
9. Pick the **next run**, and so on.
10. Press **Esc** when you're done. ✅

> 💡 Your choices are **remembered** for next time: source, text type, line style, diameter, position and offset.

📸 *[Screenshot: the Stair Tread Numbering window]*

### Window controls

| Control | What it does |
|---|---|
| **Active Model / Linked Model** | Where the stair lives. **Linked Model** is greyed out if the project has no loaded links. |
| **Text note type** (search + list) | The text style used for the numbers. Type in the search box to shorten the list. |
| **Circle line style** (search + list) | The line style used for the circles. Search works the same way. |
| **Circle diameter (mm)** | Size of the circle. **0** = the circle is as wide as one tread is deep. |
| **Left / Center / Right** | Which side of the run the bubbles go on, **as seen walking up** the run. |
| **Offset from stair edge (mm)** | Gap between the run's edge and the bubble's edge. Greyed out when **Center** is chosen. |
| **Cancel** | Closes the window. Nothing is drawn. |
| **Start Numbering** | Checks your choices and starts picking. |

---

## 5. Bubble size and position

| Setting | Effect |
|---|---|
| Diameter **0** | Each circle fills one tread depth. |
| Diameter **> 0** | Fixed circle size in mm, e.g. `250`. Negative values aren't allowed. |
| **Center** | Bubbles sit on the middle line of the run. The offset is ignored. |
| **Left** / **Right** | Bubbles sit near that edge of the run, as seen walking **up**. |
| Offset **positive** | The bubble sits **inside** the run, that far from the edge. |
| Offset **negative** | The bubble sits **outside** the run. |
| Offset **0** | The bubble touches the run edge from the inside. |

> 💡 You can type decimals with a dot or a comma (`12.5` or `12,5`).

---

## 6. How the numbers are worked out

- The count is by **risers climbed**, so a landing also uses up one number.
- Runs **below** the one you pick are counted, so numbering flows through the stair.
- The landing at the top of a run gets a number only if the walk didn't stop at the cut plane first.
- If a run ends level with its landing, the landing doesn't get an extra bubble, because the last tread already has that number.

---

## 7. Undoing

| You want to… | Do this |
|---|---|
| Close the window without drawing | Click **Cancel** or the window's **X**. |
| Stop picking | Press **Esc**. Everything already drawn stays. |
| Undo the last run | **Ctrl + Z** once. Each run is one Undo step called **Number Stair Treads**. |
| Undo several runs | Press **Ctrl + Z** once per run. |
| Remove bubbles later | Select the circles and text notes and delete them. |

---

## 8. Messages you may see

**🔴 "Open a plan view first - the numbering stops at that view's cut plane."**
*Why:* The active view isn't a plan view.
*What to do:* Open a floor plan and run the tool again.

**🔴 "No text note types or line styles found."**
*Why:* The project has no text note types, or no line styles the tool can use.
*What to do:* Create at least one text note type and one line style, then try again.

**🔴 Red text in the window:** "Choose a text note type." · "Choose a line style for the circle." · "Circle diameter must be a number, 0 or larger." · "Offset must be a number (mm)."
*Why:* Something is missing or not a valid number.
*What to do:* Fix the field named in the message and click **Start Numbering** again.

**🟡 "'Tread/Riser Start Number' was not found on these stairs - numbering starts at 1."**
*Why:* The stair doesn't have that property, or it's empty.
*What to do:* Nothing, if starting at 1 is fine. This message appears only once per session.

**🔴 "Run [ID]: could not read the tread layout." (followed by a reason)**
*Why:* The tool couldn't read this run's path, tread count or riser height.
*What to do:* That run is skipped. You can keep picking other runs. Contact the author if it keeps happening on a normal stair.

**🔴 "Run [ID]: numbering failed and was rolled back." (followed by a reason)**
*Why:* Revit refused to draw the bubbles for this run. Nothing was added for it.
*What to do:* Screenshot the message and contact the author.

---

## 9. FAQ

**Why did numbering stop halfway up the stair?**
It stops at the view's **cut plane**. The first tread above the cut plane is the last one numbered. Raise the cut plane in **View Range** if you want more.

**Why does the second run start at 8 instead of 1?**
On purpose. Numbers continue through the whole stair. Treads and landings below the picked run are counted.

**Can I start from a number other than 1?**
Yes. Set the stair's **Tread/Riser Start Number** property before you run the tool.

**I picked the same run twice. Now the numbers look bold.**
There are two sets of bubbles on top of each other. Undo once, or delete one set.

**The stair changed. Do the bubbles follow?**
No. They're plain circles and text. Delete them and number again.

**Can I number a stair in a linked model?**
Yes. Choose **Linked Model** in the window. The bubbles are drawn in your model, in the current view.

**Some line styles are missing from the list.**
Special system styles that can't be used for normal lines (e.g. *&lt;Room Separation&gt;*, *&lt;Sketch&gt;*) are hidden on purpose.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **Modify** panel → **Stairs** dropdown. | ✅ If it's still missing |
| Tool refuses to start | Not in a plan view | Open a floor plan | ❌ |
| **Linked Model** greyed out | No loaded links | Load the link in **Manage Links** | ❌ |
| Can't pick anything | Wrong source chosen, or you're clicking the whole stair | Check **Active / Linked**. Press **Tab** to reach the run. | ❌ |
| Too few treads numbered | Cut plane is low | Check the view's **View Range** | ❌ |
| Only one bubble on an upper run | That run starts above the cut plane, so its first tread is the last one numbered | Use a view whose cut plane is higher | ❌ |
| Numbers don't start where expected | **Tread/Riser Start Number** not set | Check the stair's properties | ❌ |
| Bubbles on the wrong side | Left/Right is judged walking **up** the run | Switch Left ↔ Right | ❌ |
| Bubbles outside the stair | Negative offset | Use a positive offset | ❌ |
| "Could not read the tread layout" on a normal stair | Unusual run | Screenshot the message | ✅ |
| "Numbering failed and was rolled back" | Revit refused the drawing | Screenshot the message | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your settings, and of any message
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **view** you were in
4. Whether the stair was in your model or in a **link**
5. Which **run** you picked, and the numbers you **expected** vs. what you **got**
