# Grid Head Aligner

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Views** dropdown → **Grid Head Aligner**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Grid Head Aligner** tidies the grids in your views in one go. It can do two things (you can use one or both):

| Option | What it does |
|---|---|
| **Set grid bubbles** | Chooses on which **side of the view** (Top, Bottom, Left, Right) grid bubbles are shown. |
| **Align grid ends to crop** | Lines up all grid ends at a set distance from the view's **crop region**, so every grid stops at the same place. |

You can run it on the **active view**, the **active sheet**, **selected views**, or a list of **picked sheets**.

> 💡 Think of it as a ruler you lay along each edge of the crop box: every grid line is trimmed or stretched to meet it, and the bubbles go where you ask.

The changes apply **only in the views the tool works on**. Other views of the same grids are not touched.

📸 *[Screenshot: the Grid Head Aligner window with the preview]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on views with the crop region turned off | Those views are skipped and listed as `crop region is off`. |
| Work on views that can't show grids | Legends, drafting views, 3D views, schedules etc. are quietly ignored. |
| Change multi-segment grids | They're skipped and listed in the details. |
| Align curved grids | Bubbles are still set, but the ends aren't moved. |
| Move grid ends that have a **leader** (elbow) | That end is left where it is. |
| Move grids in other views | Only the views you chose are changed. |

---

## 3. Before you start

- [ ] The views you want to fix have their **crop region turned on** (it doesn't need to be visible, just active).
- [ ] Choose how you want to apply it:
  - one view → open it so it's the **active view**
  - one sheet → open the sheet
  - several views → **select their viewports** on a sheet, or **select the views in the Project Browser**, *before* clicking the button
  - several sheets → you'll pick them in the window
- [ ] Know your offset. It's a **model distance in millimetres**, not a paper distance. At 1:100, an offset of `1000` mm is about 10 mm on the printed sheet.

---

## 4. How to use it

1. *(Optional)* Select viewports on a sheet, or views in the Project Browser.
2. Click **Grid Head Aligner** in the **Views** dropdown.
3. Under **Apply to**, choose one: **Active view**, **Active sheet**, **Selected views (_n_)**, or **Picked sheets**.
4. If you chose **Picked sheets**, tick the sheets in the list.
5. Tick **Set grid bubbles** and choose the sides where bubbles should show.
6. Tick **Align grid ends to crop** and type the offset for each side.
7. Check the **Preview** on the right.
8. Click **Apply**.
9. A result message appears (see [Section 8](#8-messages-you-may-see)). ✅

### Window controls

| Control | What it does |
|---|---|
| **Active view** | Works on the view you have open. Greyed out when a sheet is open. |
| **Active sheet** | Works on every view placed on the open sheet. Greyed out when the open view isn't a sheet. |
| **Selected views (_n_)** | Works on the viewports / views you selected before running. Greyed out if nothing was selected (hover for a hint). When you did select something, this is chosen for you. |
| **Picked sheets** | Works on every view on the sheets you tick in the list below. |
| **Search sheets** | Filters the sheet list by number or name. Only active with **Picked sheets**. |
| **All** / **None** | Ticks / unticks the sheets **currently shown** in the list. |
| **"_ of _ selected" counter** | How many sheets are ticked. |
| **Sheet list** | Sheet number, sheet name, and how many views on it can be processed. |
| **Preview** | A small example drawing that updates as you change options. Dashed box = crop box, yellow = offset. |
| **Set grid bubbles** | Turns the bubble option on/off. |
| **Top / Left / Right / Bottom** | Highlighted (yellow) = show the bubble on that side of the view. Not highlighted = hide it. |
| **Align grid ends to crop** | Turns the alignment option on/off. |
| **Offset boxes** (Top / Left / Right / Bottom) | Distance in mm from that crop edge. **Positive = outside the crop, negative = inside.** A comma or a dot can be used for decimals. |
| **Same offset on all sides** | Copies the **Top** value to all sides, and keeps them the same while you type. |
| **Cancel** | Closes the window. Nothing changes. |
| **Apply** | Runs the tool. |

---

## 5. How the sides work

The tool looks at each grid **as it appears on screen**:

| Grid runs mostly… | Its ends belong to… | Bubble buttons that apply |
|---|---|---|
| Up–down (e.g. grids 1, 2, 3) | **Top** and **Bottom** | Top / Bottom |
| Left–right (e.g. grids A, B) | **Left** and **Right** | Left / Right |

For a slanted grid, it uses whichever direction is stronger.

> 💡 Default bubbles are **Top** and **Left**. Default offsets are **1000 mm** on every side.

---

## 6. Good to know

- **Your settings are remembered.** Bubble sides, offsets, both options, **Same offset on all sides**, and the **Apply to** choice are restored next time. (**Selected views** is never remembered, since a selection is a one-off.)
- **Grid ends become 2D in that view.** To change one view without moving the grid in other views, the tool switches grid ends to view-specific (2D) extents in the views it works on.
- **Non-rectangular crops** are treated as their outer rectangle.
- A view placed on two of your picked sheets is only processed **once**.

---

## 7. Undoing

All changes from one run are a single Undo step called **Align Grid Heads**.

| You want to… | Do this |
|---|---|
| Stop before anything changes | Click **Cancel** or close the window |
| Undo the whole run | Press **Ctrl + Z** once, or pick **Align Grid Heads** in the Undo list |
| An error stopped the run | Nothing to undo. The tool already rolled everything back. |

---

## 8. Messages you may see

### In the window (red text at the bottom)

🟡 **"Turn on at least one option."**
*Why:* Both **Set grid bubbles** and **Align grid ends to crop** are off.
*What to do:* Tick at least one.

🟡 **"Enter a number (mm) for every offset."**
*Why:* An offset box is empty or has text in it.
*What to do:* Type a number in all four boxes.

🟡 **"Active view: crop region is off."**
*Why:* The open view has no active crop region.
*What to do:* Turn on **Crop View** for that view, then try again.

🟡 **"Active view: … views can't show grids."** / **"Active view: not a usable view."**
*Why:* The open view is a type that doesn't show grids (e.g. 3D, drafting, legend) or is a template.
*What to do:* Open a plan, section or elevation.

🟡 **"Pick at least one sheet."**
*Why:* **Picked sheets** is chosen but nothing is ticked.
*What to do:* Tick at least one sheet.

### After you click Apply

🟢 **Grid Head Aligner — "_X_ grids updated in _Y_ of _Z_ views"**
*Why:* The run finished. The message also shows the **Actions** used (bubbles / crop alignment).
*What to do:* Check the views.

🔵 **"_N_ views on the sheets can't show grids (legends, drafting, 3D, schedules) and were ignored."**
*Why:* Normal. Those views have no grids.
*What to do:* Nothing.

🟡 **"_N_ issues - expand details for the list."**
*Why:* Some views or grids were skipped. Click **Show details** to see which. Each line names the view and grid, followed by one of:

| Detail | Meaning |
|---|---|
| `crop region is off` | The view has no active crop. Turn it on and re-run. |
| `multi-segment grid - skipped` | Multi-segment grids aren't supported. Adjust by hand. |
| `curved grid - ends not aligned` | Curved grids aren't aligned (bubbles still set). |
| `end with a leader left in place` | That grid end has a leader, so it wasn't moved. |
| `offsets would collapse the grid - not aligned` | Your negative offsets are so large the grid would vanish. Use smaller numbers. |
| `runs along the view direction - skipped` | The grid is seen end-on in this view (e.g. in a section). |
| `Revit rejected the new extents` | Revit refused the new length. Adjust by hand. |
| `no curve in this view` / `failed: …` | Unexpected. Contact the author if it repeats. |

Only the first 25 lines are listed, then "… and _N_ more".

🔴 **"Failed - nothing changed."** followed by an error
*Why:* Something unexpected stopped the run. Everything was rolled back.
*What to do:* Screenshot the message and contact the author.

---

## 9. FAQ

**Is the offset measured on paper or in the model?**
In the model, in millimetres. The same offset looks smaller on paper at 1:200 than at 1:50.

**Can I bring the grids inside the crop?**
Yes. Use a negative offset.

**Will this move my grids in other views?**
No. Only the views you chose are changed.

**Why weren't some grids counted as "updated"?**
A grid is only counted if something actually changed. Grids that already matched your settings aren't counted.

**Why is "Selected views" greyed out?**
You didn't select anything before clicking the button. Select viewports on a sheet, or views in the Project Browser, then run it again.

**Does it work in sections and elevations?**
Yes. Floor, ceiling, structural and area plans, sections, elevations and detail views are supported.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Look under **Modify** panel → **Views** dropdown. | ✅ If it's still missing |
| **Active view** or **Active sheet** greyed out | The open view is (or isn't) a sheet | Open the right view, or use **Picked sheets** | ❌ |
| **Selected views** greyed out | Nothing selected before running | Select viewports or views first | ❌ |
| Sheet list can't be clicked | **Picked sheets** isn't chosen | Click **Picked sheets** | ❌ |
| Grids barely moved / moved a lot | Offset is a model distance | Adjust the mm value for your view scale | ❌ |
| A view was skipped | Crop region is off | Turn on **Crop View** | ❌ |
| Some grids didn't change | Leader, curved or multi-segment grid | Expand the details in the result message | ❌ |
| "Failed - nothing changed." | Unexpected error | Screenshot it | ✅ |
| Anything else unexpected | — | Press **Ctrl + Z**, then try again on one view | ✅ If it repeats |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your settings
2. A **screenshot** of the result message, with **details expanded**
3. Your **Revit version** (e.g. 2025)
4. The **model name**, and the **views / sheets** you ran it on
5. **What you expected**, and what actually happened
