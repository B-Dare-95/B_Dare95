# Shafts Open Above

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Shafts** dropdown → **Shafts Open Above**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Shafts Open Above** draws "open above" annotation for shafts in your plan views, in one go, across many views.

A shaft is "open above" in a plan when it is hosted on the view's level but **starts higher up** (it has a positive **Base Offset**), so it begins **above the view's cut plane**. Revit doesn't show it in that plan, but you still want to mark the opening on the drawing.

For every such shaft, in every plan view you tick, the tool draws:

| What | Details |
|---|---|
| **Shaft outline** | Detail lines following the shaft boundary |
| **X mark** | Two diagonal detail lines across the shaft (optional) |
| **Label** | A text note centred **below** the shaft. Default text: `OPEN ABOVE` |
| **Shaft Function** | The shaft's **Shaft Function** value, written inside the **bottom-left corner** (optional) |

All of these are **pinned**, so they don't get moved by accident.

It works with shafts in **your model** and in **loaded Revit links**.

> 💡 Think of it as a stamp: it finds every opening that's "floating" above your cut plane and stamps the standard open-above graphics on it for you.

📸 *[Screenshot: a plan view with a shaft outline, X mark, "OPEN ABOVE" label and function text]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Annotate shafts that cut through the plan | Only shafts that **start above** the cut plane are included. For shafts the plan cuts through, see **Shaft Function Tag**. |
| Work in ceiling plans, sections or 3D views | Only **Floor Plans** and **Structural Plans** are listed. |
| Check for existing annotation | Running it twice on the same view draws **everything again**, on top of the old graphics. |
| Update itself | The lines and text are ordinary detail lines and text notes. If the shaft changes later, the annotation does not follow. |
| Use shafts based on a different level | The shaft's **Base Constraint** must be the view's own level (for links: a link level at the same height, within 10 mm). |
| Use hidden links | Links that are hidden in the view, or with the Revit Links category turned off, are ignored for that view. |
| Change the shafts | Shafts (host and linked) are only read. |

---

## 3. Before you start

- [ ] A model is **open**.
- [ ] The model has at least one **Floor Plan** or **Structural Plan** (not a template).
- [ ] Your open-above shafts use the **plan's level** as Base Constraint, with a **positive Base Offset**.
- [ ] Any links you want included are **loaded** and **visible** in the views.
- [ ] *(Optional)* Shafts have a **Shaft Function** value if you want it written on the plan.
- [ ] You know which **line style** and **text type** your office uses for this.

---

## 4. How to use it

1. Click **Shafts Open Above** in the **Shafts** dropdown.
2. The **Shafts - Open Above** window opens. The top line tells you how many shafts with a positive Base Offset were found (host and linked).
3. In **PLAN VIEWS**, tick the views to annotate. The view you're in is ticked already if it has open-above shafts.
4. In **SOURCES**, choose host shafts, linked shafts, or both.
5. Choose the **Line style**, the **Label** settings and the **Shaft Function** settings (see the table below).
6. Check the status line at the bottom, e.g. `3 views selected · 7 shafts to annotate`.
7. Click **Draw**.
8. A summary message tells you what was drawn in each view. ✅

📸 *[Screenshot: the Shafts - Open Above window]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** ("Search views or levels...") | Filters the view list by view name or level name. |
| **Only views with open-above shafts** | On by default. Hides views that have nothing to annotate. |
| **All** / **None** | Ticks / unticks every view **currently shown** in the list. |
| **View list** | Each row shows the view name, its level, its type (Floor Plan / Structural Plan) and how many open-above shafts it has (host / linked / outside crop). Greyed rows have none. |
| **Host model shafts** | Include shafts from your model. |
| **Linked model shafts** | Include shafts from loaded links. Greyed out with "(no loaded links)" if there are none. |
| **Line style (boundary + X mark)** | The line style for the outline and the X. |
| **Draw X mark** | Adds the two diagonals. |
| **Label text (below shaft)** | The text under the shaft. Default `OPEN ABOVE`. Leave it **empty** to skip the label. |
| **Label text type** | Text note type for the label. |
| **Gap below shaft (paper mm)** | Distance between the shaft and the label, in **printed** millimetres. Default `2`. |
| **Write the Shaft Function value** | Writes the shaft's function in its bottom-left corner. Shafts without a value get no function text. |
| **Function text type** | Text note type for the function text. |
| **Inset from bottom-left corner (paper mm)** | How far inside the corner the function text sits, in printed millimetres. Default `1`. |
| **Skip shafts outside the view's crop region** | On by default. Shafts outside the view's active crop box are left out. |
| **Draw** | Starts drawing. Greyed out while there are **0 shafts to annotate**. |
| **Cancel** | Closes the window. Nothing is drawn. |

> 💡 "Paper mm" means the distance on the printed sheet. The tool multiplies it by the view scale, so the gap looks the same at 1:50 and 1:200.

---

## 5. Which shafts are picked up

A shaft is annotated in a view when **all** of these are true:

| Rule | Host shafts | Linked shafts |
|---|---|---|
| Base level | Base Constraint is **the view's level** | Base Constraint is a link level at the **same height** as the view's level (within 10 mm) |
| Base Offset | **Positive** (greater than zero) | Same |
| Height | The shaft bottom is **above the view's cut plane** | Same |
| Visibility | — | The link is not hidden in the view, and the Revit Links category is on |
| Crop | Inside the crop box (if **Skip shafts outside…** is ticked) | Same |
| Boundary | The tool can read the shaft's outline | Same |

> ⚠️ **Example:** View on *Level 02*, cut plane at 1200 mm. A shaft on *Level 02* with Base Offset 2500 mm → **included**. Same shaft with Base Offset 800 mm → **not** included (it starts below the cut plane, so the plan already cuts it).

---

## 6. Undoing

Everything from one **Draw** goes into **one** Undo entry: **Shafts - Open Above**.

Press **Ctrl + Z** once (or pick it from Revit's Undo list) to remove all the lines and text notes from that run, in every view.

> ⚠️ The graphics are **pinned**. If you want to delete some by hand later, unpin them first.

---

## 7. Messages you may see

🔴 **"No Floor Plan or Structural Plan views found."**
*Why:* The model has no floor or structural plans with a level.
*What to do:* Create a plan view, then run again.

🔴 **"No line styles found in the document."** / **"No text note types found in the document."**
*Why:* The model has no line styles or no text note types to choose from.
*What to do:* Very unusual. Contact the author.

🟡 **"No Shaft Openings with a positive Base Offset were found in the host model or in any loaded link."**
*Why:* No shaft starts above its base level, so nothing can be "open above".
*What to do:* Check the shafts' Base Offset values. Make sure the links are loaded.

🟡 **"Tick at least one source (host or linked)."**
*Why:* Both **Host model shafts** and **Linked model shafts** are unticked.
*What to do:* Tick at least one.

🟡 **"Select at least one plan view."**
*What to do:* Tick a view in the list.

🟡 **"Select a line style."** / **"Select the text note types."**
*What to do:* Pick a value in the empty dropdown.

🟡 **"Gap and inset must be numbers of 0 or more (paper mm)."**
*Why:* A gap or inset box has text, or a negative number.
*What to do:* Type a plain number like `2` or `1.5`.

🟢 **Summary message, e.g. "7 shaft(s) annotated in 3 view(s)."**
One line per view: `Level 02 Plan: 4 host, 1 linked, 2 outside crop (skipped)`. It may also list:
- **failed** — some shafts couldn't be drawn. The **Failures** section names them.
- **[view rolled back: …]** — nothing was kept for that view. Contact the author with a screenshot.
- **Shafts with no readable boundary (ignored)** — the tool couldn't read those shafts' outline.

---

## 8. FAQ

**Does this change my shafts?**
No. It only adds detail lines and text notes to the views you ticked.

**I ran it twice and now there are double lines.**
The tool doesn't check for earlier graphics. Undo the second run (**Ctrl + Z**), or unpin and delete the duplicates.

**Why is a view greyed out in the list?**
It has no open-above shafts for the sources you ticked. Untick **Only views with open-above shafts** to see all views.

**Why does a view say "no view range"?**
The tool couldn't read that view's view range, so it can't tell what's above the cut plane. That view gets nothing.

**Why wasn't the Shaft Function written for some shafts?**
Those shafts have no **Shaft Function** value (or no such parameter).

**Can I use my own label text, like "VOID OVER"?**
Yes. Type it in **Label text (below shaft)**.

**My linked shafts aren't showing up.**
Check that the link is loaded, visible in the view, and that its level is at the same height as your view's level.

**Can I use it on a ceiling plan?**
No. Only Floor Plans and Structural Plans are listed.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab not loaded | Restart Revit. Look in **Modify** panel → **Shafts** dropdown. | ✅ If it's still missing |
| **Draw** is greyed out | 0 shafts to annotate for your selection | Tick a view with shafts. Check the sources and the crop option. | ❌ |
| A shaft you expected is missing | Base Offset is 0 or negative, shaft starts below the cut plane, or it's based on another level | Check the shaft's Base Constraint and Base Offset, and the view range | ❌ |
| Shaft listed as "outside crop" | It's outside the view's crop box | Untick **Skip shafts outside the view's crop region**, or widen the crop | ❌ |
| Linked shafts not counted | Link hidden, unloaded, or levels at different heights | Check Visibility/Graphics and the link's levels | ❌ |
| Label sits too close / too far | Gap setting | Change **Gap below shaft (paper mm)** | ❌ |
| Double graphics | Tool run twice | Undo, or delete the duplicates | ❌ |
| "failed" or "view rolled back" in the summary | Unexpected problem | Screenshot the summary | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your settings
2. A **screenshot** of the summary message or error
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **view names**, and whether the shafts are in your model or a link
5. **What you expected** to be drawn, and what actually was
