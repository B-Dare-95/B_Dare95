# Curtain Wall Dimension

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Walls** dropdown → **Curtain Wall Dimension**
> 🧩 **Works with:** Revit 2024 and newer · plan, elevation and section views · host model and loaded links
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Curtain Wall Dimension** adds dimensions to curtain walls for you. Each wall you pick gets **two dimension strings**:

| String | Measures | Position |
|---|---|---|
| **Detailed** | Wall start → **every curtain grid** → wall end | Closer to the wall |
| **Overall** | Wall start → wall end | Further out |

What gets measured depends on the view:

| View | Measures | Placed |
|---|---|---|
| **Plan** (floor, ceiling, structural, area plan) | The wall's **length** (vertical grids) | **Above** the wall (walls running up/down the screen get it on the **left**) |
| **Elevation / Section / Detail** | The wall's **height** (horizontal grids) | To the **left** of the wall |

The gap between the wall and the two strings is worked out from the **text size** of the dimension type you choose and the **view scale**, so the strings don't overlap.

> 💡 Think of it as a dimension assistant that finds every grid line for you and lines up two tidy strings.

📸 *[Screenshot: a curtain wall in plan with both dimension strings]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Dimension curved curtain walls in plan | Only **straight** walls in plan. Curved ones are reported and skipped. |
| Work in 3D views, drafting views or sheets | Plan, elevation, section and detail views only. |
| Dimension mullion sizes or panel widths | Only grid positions and the wall ends. |
| Mix host and linked walls in one run | Choose **Host model** or **Linked models** in the window. |
| Update the strings later | They're normal Revit dimensions. If the wall changes, they follow Revit's normal rules or need redoing. |
| Show a "done" message when everything went fine | It only shows a message if something needs your attention. |

---

## 3. Before you start

- [ ] A **plan**, **elevation**, **section** or **detail** view is active.
- [ ] The curtain walls are **visible** in the view.
- [ ] For linked walls: the link is **loaded**.
- [ ] *(Optional)* Select the walls first. You can select the **wall**, a **panel** or a **mullion**; the tool uses the curtain wall they belong to.

---

## 4. How to use it

1. Open a supported view.
2. *(Optional)* Select one or more curtain walls.
3. Click **Curtain Wall Dimension**. The **Curtain Wall Dimension** window opens.
4. Choose a **dimension type** from the list (use the search box to find it).
5. Under **PICK FROM**, choose **Host model** or **Linked models**.
6. *(Optional)* Change the **SPACING FACTOR**. Watch the preview line underneath.
7. Click **Start Picking** (or double-click a dimension type).
8. **If you selected walls in step 2:** they're dimensioned straight away.
   **Otherwise:** click curtain walls one by one. Each one is dimensioned as you click. The status bar says **"Pick a curtain wall (Esc to finish)"** (or **"…inside a link…"** for linked walls).
9. Press **Esc** to finish. ✅

> 💡 In elevation the cursor usually lands on panels or mullions, not the wall itself. That's fine: clicking a panel or mullion picks its curtain wall.

📸 *[Screenshot: the Curtain Wall Dimension window]*

### Window controls

| Control | What it does |
|---|---|
| **Subtitle** | Shows the view type and scale, and where the strings will go (e.g. *"Plan view 1:100 - dimensions the wall length, placed above the wall."*). |
| **DIMENSION TYPE** search box | Filters the list as you type. |
| **Dimension type list** | Every linear dimension type in the project, with its text size (e.g. *"Linear - 2.5mm Arial · 2.5 mm text"*). The project's default type is selected at the start. Double-click to start picking. |
| **Host model** / **Linked models** | Where the walls come from. **Linked models** shows **"No loaded links"** and is greyed out if there are none. It's chosen for you if you pre-selected linked walls only. |
| **SPACING FACTOR** | Multiplies the estimated gaps. `1.0` = default; `1.5` = 50 % further out; `0.8` = closer. Must be a positive number (a comma works as a decimal point). |
| **Preview line** | E.g. *"Text 2.5 mm · detailed line 600 mm · overall line 1200 mm from the wall edge"* (model distances). |
| **Cancel** / window **X** | Closes. Nothing is created. |
| **Start Picking** | Closes the window and starts dimensioning. |

---

## 5. Undoing

Each wall is dimensioned in its own step. The Undo list shows one **"Curtain Wall Dimension"** entry **per wall**.

- Undo the last wall: **Ctrl + Z** once.
- Undo several: press **Ctrl + Z** once per wall, or pick several entries from the Undo dropdown.
- Or simply select the dimensions and delete them.

---

## 6. Messages you may see

🔴 **"Run this tool in a plan, elevation or section view."**
- **Why:** The active view isn't supported (3D, drafting, sheet, schedule, template…).
- **What to do:** Open a plan, elevation, section or detail view.

🔴 **"No linear dimension types found in this project."**
- **Why:** The project has no linear dimension types.
- **What to do:** Load or create one, then try again.

🟡 **"Spacing factor must be a positive number."** (in the window)
- **Why:** The factor box is empty, zero, negative or not a number.
- **What to do:** Type a number such as `1.0`.

🟡 **"Select a dimension type."** (in the window)
- **Why:** Your search hides every type, so nothing is selected.
- **What to do:** Clear or change the search.

🟡 **"Dimensioned N wall(s)."** followed by a list
- **Why:** Shown at the end only if at least one wall needs attention. Each line reads **"Wall 123456: …"** or **"Wall 123456 in link 'Name': …"**.
- **What to do:** Check the walls listed. The reasons are below.

| Reason in the list | Meaning | What to do |
|---|---|---|
| **"only straight curtain walls are supported in plan"** | Curved wall in a plan view | Dimension it by hand |
| **"no curtain grids between the wall ends (…) - overall dimension only"** | No grids run across the measuring direction | Expected for a wall without grids in that direction. Only the overall string was placed. |
| **"N of M grids could not be referenced (…)"** | Revit wouldn't accept some grid lines | The detailed string skips those grids. Add them by hand. |
| **"detailed string was rejected by Revit"** | The detailed string couldn't be placed | Only the overall string was placed |
| **"could not find references at the wall ends"** / **"Revit rejected every end reference found (…)"** | No usable wall ends in this view | Nothing was placed for this wall. Try another view or contact the author. |
| **"wall has no location line"** | The wall can't be measured | Contact the author |
| **"dimension creation failed (…)"** | Unexpected Revit error | Nothing was placed for this wall. Contact the author. |

🔴 **A pyRevit error window**
- **Why:** Something unexpected happened.
- **What to do:** Screenshot it and contact the author.

---

## 7. FAQ

**Nothing happened after I picked walls. Did it work?**
Probably yes. When every wall succeeds, the tool doesn't show a message. Look for the new dimensions in the view.

**Why are the strings too close to (or too far from) the wall?**
The gap comes from the text size and the view scale. Change the **SPACING FACTOR** and try again.

**Can I dimension linked curtain walls?**
Yes. Choose **Linked models** and click the walls in the link.

**I selected walls, but the tool still asked me to pick.**
Your selection didn't match the **PICK FROM** choice. For example, you selected host walls but chose **Linked models**. Pre-selected walls are only used when they match.

**Where do dimensions go in a section that cuts through the wall?**
On the section's cut plane, to the left of the wall.

**Can I pick the same wall twice?**
Yes, but you'll get a second set of dimensions on top of the first.

---

## 8. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't click the wall | Not a curtain wall, or the wrong **PICK FROM** choice | Check the wall type. Switch **Host model** / **Linked models**. | ❌ |
| **Linked models** greyed out | No loaded links | Load the link | ❌ |
| Only the overall string appears | No grids in that direction, or Revit rejected them | Read the end message | ❌ |
| Some grids missing from the detailed string | Revit wouldn't accept those grid lines | Add them by hand | ✅ If it happens often |
| Strings overlap text or other elements | Spacing too small for this scale | Increase the **SPACING FACTOR** | ❌ |
| Curved wall skipped in plan | Not supported | Dimension it by hand | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 9. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the end message or error
2. A screenshot of the **view** with the wall and the dimensions that were (or weren't) placed
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **view name**, and whether the wall was in the **host** or a **link**
5. The **dimension type** and **spacing factor** you used
