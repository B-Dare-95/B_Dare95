# Merge Shafts

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Shafts** dropdown → **Merge Shafts**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Merge Shafts** cleans up models with lots of small, separate shaft openings. It combines shafts that have **the same settings** into **one** shaft element.

The tool scans every shaft in the project and puts them in **groups**. Shafts land in the same group when **all** of these match:

| Must match | Notes |
|---|---|
| **Shaft Function** | Shafts with no value form their own group (shown as `<none>`) |
| **Base Constraint** | The base level |
| **Base Offset** | Tiny differences (below about 0.03 mm) are ignored |
| **Top Constraint** | The top level, or *Unconnected* |
| **Top Offset** | Same small tolerance |
| **Unconnected Height** | Only when the top is *Unconnected* |

Every group with **2 or more** shafts can be merged. The result is a **single new shaft** whose sketch holds the outlines of all its members.

> 💡 The shafts **don't need to be near each other**. Two "Electrical" shafts from Level 01 to Roof at opposite ends of the building are merged into one shaft element with two outlines.

📸 *[Screenshot: the Merge Shafts window with the group list]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Group by location | Shafts are grouped by settings only. Use the search box and untick groups you don't want merged. |
| Touch shafts inside Revit groups | Shafts in model groups are **skipped**. |
| Touch linked models | Only shafts in your own model are used. |
| Keep the original shaft IDs | The merged shaft is a **new** element with a new ID. |
| Merge a single shaft | Groups with only one shaft aren't listed. |
| Copy every parameter | Only parameters with the **same value on every member** are copied (if that option is on). |

---

## 3. Before you start

- [ ] A model is **open**.
- [ ] *(Recommended)* **Save** the model first. Merging deletes the original shafts.
- [ ] Shafts you want merged have the **same Shaft Function, levels and offsets**. Fix them first with **Shaft Opening Manager** or the **Match** tools if needed.
- [ ] You've thought about **tags or dimensions** on the original shafts. If the originals are deleted, anything attached to them is affected.
- [ ] In a workshared model, you can edit the shafts (they aren't owned by someone else).

---

## 4. How to use it

1. Click **Merge Shafts** in the **Shafts** dropdown.
2. The **Merge Shafts** window opens. The header says how many groups were found, how many shafts will collapse, and how many were skipped.
3. Each line is one group, for example:
   `[3 shafts]   Function: Plumbing   •   Base: Level 01 (0)   •   Top: Roof (0)`
   All groups are **ticked** by default.
4. Untick any group you **don't** want to merge. Use the **search box** to find groups by function or level name.
5. Set the three options at the bottom (see below).
6. Click **Merge Selected**.
7. A **Merge Shafts** message shows how many groups were merged, failed and deleted. ✅
8. The full report is in the **pyRevit output window**.

### Window controls

| Control | What it does |
|---|---|
| **Search box** | Filters the group list as you type (function, level names, offsets). |
| **Select All** / **Select None** | Ticks / unticks every group **currently shown**. |
| **Group list** | One tick box per group of mergeable shafts. |
| **Union overlapping / touching outlines** | On by default. Outlines that overlap or touch are fused into one clean outline. |
| **Delete original shafts** | On by default. Removes the original shafts after the new one is made. Untick to keep them (you'll then have duplicates to check). |
| **Copy parameters shared by all members** | On by default. Any editable parameter that has **the same value on every member** (e.g. Comments, Mark) is copied to the new shaft. |
| **Merge Selected** | Runs the merge for the ticked groups. |
| **Cancel** | Closes the window. Nothing changes. |

---

## 5. The three options explained

| Option | Ticked ✅ | Unticked ⬜ |
|---|---|---|
| **Union** | Overlapping or touching outlines become one outline | Every original outline is kept as its own loop, even if they overlap |
| **Delete originals** | You end up with just the merged shaft | Originals stay. The new shaft sits on top of them. |
| **Copy parameters** | Matching values (e.g. Comments) move over | The new shaft only gets its levels, offsets and its outline |

> ⚠️ If the union can't be worked out for a group, the tool quietly keeps the separate outlines instead. The report shows `unioned` only when outlines were actually fused.

> ⚠️ **Shafts with a hole inside** (an inner loop): with **Union** on, that inner loop may be filled in. If any of your shafts have islands, untick **Union** for that run.

---

## 6. Reading the report

The pyRevit output window shows **Merge Shafts - Report**:

- A summary line: **"X group(s) merged, Y failed, Z shaft(s) deleted."**
- One line per group:
  - `OK | … | merged 3 shafts into ID 123456 (2 loop(s), unioned)` — success. The ID is the new shaft.
  - `… - originals kept` — you unticked **Delete original shafts**.
  - `FAIL | … | <reason>` — that group wasn't changed.
- **Skipped shafts**: one line per shaft that was left out, with the reason:
  - `inside a Revit group`
  - `no readable boundary sketch`
  - `Base/Top Constraint parameter not found`

> 💡 Copy the new ID, then use Revit's **Select by ID** to find the merged shaft.

---

## 7. Undoing

Each merged group is **one** Undo entry called **Merge shaft group**.

| You merged… | To undo everything |
|---|---|
| 1 group | **Ctrl + Z** once |
| 5 groups | **Ctrl + Z** five times, or pick the 5th **Merge shaft group** in Revit's Undo list |

A failed group is rolled back automatically. It doesn't appear in the Undo list.

---

## 8. Messages you may see

🔵 **"No shaft openings share the same Shaft Function, Base Constraint, Base Offset, Top Constraint and Top Offset."**
Followed by how many combinations were found and how many shafts were skipped.
*Why:* Every shaft is unique, so there's nothing to merge.
*What to do:* Nothing, or align shaft settings first if you expected matches.

🟢 **Merge Shafts summary** — "X group(s) merged. Y group(s) failed. Z original shaft(s) deleted. See the pyRevit output window for the full report."
*What to do:* Check the output window, especially for **FAIL** lines.

🟡 **Revit warnings** after merging
*Why:* The tool lets Revit's own warnings through (for example about overlapping sketch lines).
*What to do:* Read the warning. If it doesn't make sense, contact the author.

🔴 **FAIL lines in the report** (e.g. "base or top level could not be resolved", "no boundary loops found", or a Revit message)
*What to do:* That group was left as it was. Screenshot the line and contact the author.

---

## 9. FAQ

**Why are shafts on opposite sides of the building in the same group?**
Grouping uses settings only, not position. Untick the group if you don't want them combined.

**Why is one of my shafts not in any group?**
Either it's unique (no other shaft has exactly the same settings), it's inside a Revit group, or the tool couldn't read its sketch. Check **Skipped shafts** in the report.

**Two shafts look identical but aren't grouped.**
Something differs: maybe the Shaft Function spelling, a small offset, or one is *Unconnected*. Compare them in **Shaft Opening Manager**.

**I clicked Merge Selected and nothing happened.**
If no group was ticked, the tool closes without doing anything.

**What happens to tags on the old shafts?**
When the originals are deleted, tags attached to them are removed by Revit. You'll need to re-tag the merged shaft.

**Can I split a merged shaft again?**
Not with this tool. Use **Undo**, or edit the shaft sketch by hand.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab not loaded | Restart Revit. Look in **Modify** panel → **Shafts** dropdown. | ✅ If it's still missing |
| Fewer groups than expected | Small differences in settings | Compare shafts in **Shaft Opening Manager** | ❌ |
| Shaft skipped "inside a Revit group" | It's in a model group | Ungroup it, or leave it | ❌ |
| Merged outline looks wrong | Union fused outlines you wanted separate, or filled a hole | Undo, run again with **Union** unticked | ❌ |
| Duplicate shafts after merging | **Delete original shafts** was unticked | Delete the originals, or Undo and run again | ❌ |
| Lost tags | Originals were deleted | Re-tag the merged shaft | ❌ |
| **FAIL** lines in the report | Revit refused the new shaft | Screenshot the report | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the Merge Shafts window with your ticks and options
2. A **screenshot** of the pyRevit output report (especially FAIL and Skipped lines)
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **IDs** of the shafts involved
5. **What you expected**, and what actually happened
