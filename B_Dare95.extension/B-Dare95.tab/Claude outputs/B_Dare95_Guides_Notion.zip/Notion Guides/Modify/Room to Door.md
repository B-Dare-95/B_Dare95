# Room to Door

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Rooms** dropdown → **Room to Door**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Room to Door** copies information from a **room** into the **doors** of that room. For example, it can write the room number into each door's **Mark**.

Every door in Revit knows the room on each side of it: **FromRoom** and **ToRoom**. You choose which side to read from.

| Mode / option | What it does | Example result |
|---|---|---|
| **Single** | Copies **one** room parameter into a door parameter | `101` |
| **Combine** | Joins **several** room parameters with a separator | `101 - OFFICE` |
| **Add Designator for shared rooms** | When several doors get the same value, adds a letter or number to each | `101-A`, `101-B` |

> 💡 Think of it as labelling each door with the name tag of the room it belongs to.

📸 *[Screenshot: the Room to Door Parameter Transfer window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on a selection | It writes to **every door** in the model that has a room on the chosen side. |
| Use your view's phase | Rooms are looked up in the **last phase** of the project. |
| Write to doors with no room | Doors with no room on the chosen side are left alone and counted as "had no room". |
| Write empty values | If the room value is empty, that door is skipped. |
| Order designators by position | **A, B, C** are given in the order the doors were created, not left-to-right. |
| Show level or type names for ID-type parameters | Room parameters that point to another element (e.g. **Level**, **Phase**) are copied as an internal ID number, not as a name. |

---

## 3. Before you start

- [ ] The model has **rooms** and **doors**.
- [ ] Your doors point to the right rooms (check a door's **From Room / To Room** in Properties). Use **Flip** on doors if needed.
- [ ] Your rooms exist in the **last phase** of the project.
- [ ] The door parameter you'll write to is **editable** (not greyed out in Properties).

---

## 4. How to use it — Single mode

1. Click **Rooms** dropdown → **Room to Door**.
2. The **Room to Door Parameter Transfer** window opens.
3. At the top left, choose **FromRoom** or **ToRoom**.
4. Make sure **Mode** (top right) is **Single**.
5. In **ROOM PARAMETERS** (left), click the room parameter to copy (e.g. `Number`).
6. In **DOOR PARAMETERS** (right), click the door parameter to write to (e.g. `Mark`).
7. *(Optional)* Tick **Add Designator for shared rooms** (see Section 6).
8. Click **Run Transfer**.
9. The status line at the bottom shows the result. **The window stays open**, so you can run another transfer. ✅
10. Click **Cancel** (or the window's **X**) when you're done.

## 5. How to use it — Combine mode

1. Set **Mode** to **Combine**. A **COMBINE ORDER** panel appears.
2. In **ROOM PARAMETERS**, select one or more parameters (use **Ctrl + click** for several), then click **+ Add**.
3. Use **Up** / **Down** to set the order, and **- Remove** to take one out.
4. Set the **Separator** (default ` - `, with spaces).
5. Pick the **DOOR PARAMETER** and click **Run Transfer**.

> Example: `Number` + `Name` with separator ` - ` → `101 - OFFICE`.

> ⚠️ If one of the combined values is empty, its place stays empty: `101 -  - OFFICE`.

### Window controls

| Control | What it does |
|---|---|
| **FromRoom / ToRoom** | Which side of the door to read the room from. The note next to it confirms ("Using FromRoom"). |
| **Mode: Single / Combine** | One parameter, or several joined together. |
| Search box above each list | Shortens the list as you type. Clears the selection in that list. |
| **ROOM PARAMETERS** | All parameters found on rooms (instance and type). |
| **DOOR PARAMETERS** | All parameters found on doors (instance and type). Pick **one**. |
| **+ Add / - Remove / Up / Down** | *(Combine only)* Build and order the combine list. |
| **Separator** | *(Combine only)* Text put between combined values. |
| **Add Designator for shared rooms** | Turns on suffixes for doors that get the same value. Shows the options below. |
| **Type: A, B, C / 1, 2, 3** | Letters or numbers for the designator. |
| **Separator:** (designator) | Text between the value and the designator (default `-`). |
| **Run Transfer** | Writes the values. |
| **Cancel** | Closes the window. |

> ℹ️ In **Single** mode the room list still lets you select several items. Only the **first** selected one is used.

---

## 6. Designators explained

When **Add Designator for shared rooms** is ticked:

- Doors that would get the **same value on the same level** are grouped.
- If a group has **2 or more** doors, each gets a suffix: `101-A`, `101-B`, `101-C`… (or `101-1`, `101-2`…).
- A door that is **alone** in its group gets **no** designator.
- Letters continue after Z as `AA`, `AB`…
- The designator **restarts on each level**, so `101` on Level 1 and `101` on Level 2 are handled separately.

> ⚠️ Grouping is by **value**, not by room. If you copy **Name** and two different rooms on the same level are both called `CORRIDOR`, their doors are lettered together (`CORRIDOR-A`, `CORRIDOR-B`…). Use **Number** for designators.

---

## 7. Undoing

Each click on **Run Transfer** is **one step** in Revit's Undo list, named **Room to Door Parameter Transfer**. Close the window, then press **Ctrl + Z** once per run you want to undo.

---

## 8. Messages you may see

All messages appear in the **status line** at the bottom of the window.

| Message | Why | What to do |
|---|---|---|
| 🔵 "Select a room parameter and a door parameter, then click Run." | Starting text | — |
| 🟢 **"Transfer complete — _N_ updated \| …"** | Done. Extra parts may follow (see below). | Check a few doors. |
| 🟡 "_N_ had no room" | Doors with no room on the chosen side (in the last phase) | Try the other side, or check the door's rooms. |
| 🟡 "_N_ skipped" | Room value was empty, or the value couldn't be written | Check the room has a value, and that the value suits the door parameter. |
| 🟡 "_N_ missing param" | Those doors don't have the chosen door parameter | Pick a parameter all doors have. |
| 🟡 "_N_ read-only" | The door parameter can't be edited | Pick an editable parameter. |
| 🔵 "_N_ designators assigned" | How many doors got a designator | — |
| 🟡 "Please select a door parameter." | No door parameter picked | Click one on the right. |
| 🟡 "Please select a room parameter." | No room parameter picked (Single) | Click one on the left. |
| 🟡 "Add at least one room parameter to the combine list." | Combine list is empty | Select parameters and click **+ Add**. |
| 🔴 "Error: …" | Something failed. Nothing from this run was written. | Screenshot it and contact the author. |

---

## 9. FAQ

**Which should I use, FromRoom or ToRoom?**
Usually the room the door **opens into** or **belongs to**. Check one door's **From Room / To Room** in Properties to see which side gives the room you want.

**Why does a door have no room?**
It has no room on that side (e.g. an external door's outside), or the room isn't in the project's last phase.

**Can I write into a number or length parameter?**
The value is entered as if typed into that field. If the text doesn't fit (e.g. `OFFICE` into a number), that door is counted as skipped.

**Can I run several transfers without reopening the tool?**
Yes. The window stays open after each run.

**Will running it again overwrite door values?**
Yes. Each run replaces the door parameter value.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab. | ✅ If still missing |
| Many "had no room" | Wrong side, door flipped, or rooms not in the last phase | Switch FromRoom/ToRoom. Check door rooms and phases. | ❌ |
| Wrong room's value on a door | Door's From/To rooms are reversed | Flip the door, then run again | ❌ |
| Value shows a number instead of a name | ID-type room parameter (e.g. Level) | Use a text parameter instead | ✅ If you need it |
| Unexpected letters on doors | Same value shared by different rooms | Use **Number** for designators | ❌ |
| Selection lost in a list | Typing in the search box resets that list | Search first, then click | ❌ |
| "Error: …" in the status line | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your choices and the status line
2. Your **Revit version** (e.g. 2025)
3. The **model name**, and the project **phases** in use
4. One or two **door IDs or marks** that came out wrong
5. **What you expected**, and what actually happened
