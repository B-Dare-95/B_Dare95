# Stair Run Dimension

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Stairs** dropdown → **Stair Run Dimension**
> 🧩 **Works with:** Revit 2024 and newer · plan views (floor, ceiling, structural, area) · stairs in your model or in a loaded Revit link
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Stair Run Dimension** places one **linear dimension** along the length (going) of a stair run in plan, and writes the tread breakdown in front of it.

The finished dimension reads like this:

> **10 EQ. TREADS @ 275MM = 2750 MM**

- `10 EQ. TREADS @ 275MM = ` is written into the dimension's **Prefix**.
- `2750` is the **real measured value** from Revit.
- `MM` is written into the dimension's **Suffix**.

You choose your settings once, then click run after run. Each one gets its dimension straight away. Press **Esc** to finish.

> 💡 It saves you from drawing the dimension, counting the treads and typing the text by hand for every flight.

📸 *[Screenshot: a stair run in plan with the finished dimension]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work outside plan views | Sections, elevations and 3D views are refused. For heights, use **Stair Riser Chain**. |
| Dimension curved or spiral runs | Only straight runs. Curved runs show an error. |
| Override the dimension value | Revit's measured value is shown as is. Only the Prefix and Suffix are written. |
| Remember your settings | The window starts with the defaults each time you run the tool. |
| Update the text later | If the stair changes, the Prefix text stays as it was. Delete the dimension and run the tool again. |
| Dimension landings | Only runs. |

---

## 3. Before you start

- [ ] A **plan view** is open and active (floor, ceiling, structural or area plan).
- [ ] The stair is **visible** in the view.
- [ ] You know whether the stair is in **your model** or in a **linked model**.
- [ ] The linear **dimension type** you want exists in the project.

---

## 4. How to use it

1. Open the plan view and click **Stair Run Dimension**.
2. A box asks **"Where is the stair?"** Click **Host model** or **Linked model**.
3. **Click the stair** (or one of its runs) in the view.
4. The **Stair Run Dimension** window opens. The subtitle shows which model the stair is in.
5. Pick a **Dimension type** on the left.
6. In the **Run** list, check that the run you want is highlighted. The tool pre-selects the run nearest to where you clicked.
7. Adjust the **Offset**, **Prefix template** and **Suffix** if needed. Watch the **Preview**.
8. Click **Start Dimensioning**. The dimension is placed. ✅
9. **Click the next stair or run.** It's dimensioned straight away with the same settings. The window doesn't open again.
10. Press **Esc** when you're done. A summary box shows how many dimensions were created, plus any notes.

📸 *[Screenshot: the Stair Run Dimension window]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** (above the type list) | Filters the dimension types as you type. |
| **Dimension type** list | Only **linear** dimension types are listed. The first one is pre-selected. |
| **Run** list | Every run of the stair you clicked, e.g. *Run 1 \| 10 treads @ 275 mm = 2750 mm*. Choose the one to dimension. |
| **Offset from run edge (mm)** | Distance from the run's side edge to the dimension line. Default **500**. A **negative** number puts it on the other side. |
| **Prefix template** | The text in front of the value. `{N}` = number of treads, `{D}` = tread depth. Default `{N} EQ. TREADS @ {D}MM = ` |
| **Suffix** | The text after the value. Default `MM`. Leave it empty for no suffix. |
| **Preview** | How the dimension should read. |
| **Status line** (bottom left) | Tips, or the reason **Start Dimensioning** is greyed out. |
| **Cancel** / **X** | Closes the window and ends the tool. |
| **Start Dimensioning** | Places the first dimension and continues picking. |

> 💡 The window has no normal title bar. Drag it by its **header** to move it.

---

## 5. Picking more runs

- Settings from the window are used for **every** run you pick after that.
- From the second pick on, the tool dimensions the run **nearest to where you clicked**. Click right on the run you want.
- If you click a whole stair with several runs, only **one** run is dimensioned per click: the nearest one.

---

## 6. Undoing

| You want to… | Do this |
|---|---|
| Stop before anything is placed | Click **Cancel** in the box or the window, or press **Esc** while picking. |
| Undo the last dimension | **Ctrl + Z** once. Each dimension is one Undo step called **Stair Run Dimension**. |
| Remove a dimension later | Select it and delete it. |

---

## 7. Messages you may see

### When starting

**🔴 "Open a 2D plan view and run the tool again."**
*Why:* No usable view is active.
*What to do:* Open a plan view.

**🔴 "This tool only runs in a 2D plan view (floor, ceiling, structural or area plan). Current view is a [view type]."**
*Why:* You're in a section, elevation, 3D or other view.
*What to do:* Switch to a plan view.

**🟡 "No type reported a Linear style, so every dimension type in the project is listed instead. Pick a linear one."**
*Why:* The tool couldn't confirm which types are linear.
*What to do:* Pick a **linear** type from the full list.

**🔴 "No DimensionType elements were found in this document at all."**
*Why:* The project has no dimension types.
*What to do:* Load or create a linear dimension type.

### While picking

**🔴 "That link is not loaded." · "That pick did not come from a Revit link." · "Nothing usable was selected." · "Selected element is a [type], not a stair." · "That stair has no runs."**
*Why:* The thing you clicked can't be dimensioned.
*What to do:* Click **OK** and pick a stair run. Picking continues.

**🔴 "The pick returned the link instance rather than an element inside it. Nested links are not supported."**
*Why:* The stair is inside a link that is itself inside another link.
*What to do:* Open the linked model directly.

**🔴 "Selection failed: …"**
*Why:* Something unexpected happened while picking. The tool stops.
*What to do:* Screenshot it and contact the author.

### In the window (status line)

| Message | What to do |
|---|---|
| "This run is curved / spiral - a single linear dimension does not apply." | Choose another run, or **Cancel**. |
| "Could not read the run path (GetStairsPath returned nothing)." · "The run path has no horizontal extent." · "Tread depth could not be read from the run, the parent stair, or derived from the geometry." · "Calculated tread count is less than 1." | That run can't be used. Choose another run, or contact the author. |
| "Pick a valid run first." · "Pick a dimension type." | Select a run and a dimension type. |
| "Offset must be a number (mm)." | Type a plain number, e.g. `500`. Use a dot for decimals. |

### In the summary at the end

The summary starts with **"Dimensions created: [N]"**, then lists notes per run:

| Note | Meaning | What to do |
|---|---|---|
| 🟡 "Run N: reads X mm but N treads x D mm = E mm - check nosing or an extended top/bottom riser." | The dimension **was placed**, but Revit's measured value doesn't match treads × depth. | Check the run's nosing and top/bottom riser settings. Edit the text by hand if needed. |
| 🔵 "Run N: Run width unavailable - offset measured from the run centreline." | Placed, but the offset is measured from the middle of the run. | Move the dimension line if needed. |
| 🔵 "Run N: Tread depth was not published by the API - derived from the run geometry, so the printed depth may be a rounding of the real value." | Placed, but the depth in the text was calculated. | Double-check the depth number. |
| 🔴 "Run N: no dimensionable riser faces at the run ends (sloped or non-planar risers)." | Not placed. The run ends can't be dimensioned. | Dimension by hand. |
| 🔴 "Run N: end faces sit X mm / Y mm off the run path ends - skipped rather than dimensioned wrong." | Not placed, to avoid a wrong dimension. | Dimension by hand, or contact the author. |
| 🔴 "Run N: geometry unreadable - …" · "Run N: dimension line has zero length." · "Run N: creation failed - …" | Not placed. | Screenshot and contact the author. |

> 💡 **"Run N"** is the run's position in its stair (Run 1, Run 2…). If you clicked a single run on its own, it's always shown as **Run 1**.

---

## 8. FAQ

**Can I change the wording, e.g. "TREADS @" to "GOINGS x"?**
Yes. Edit the **Prefix template**. Keep `{N}` and `{D}` where you want the numbers to appear.

**Why does the dimension value differ from the Preview?**
The Preview shows treads × depth. The dimension shows what Revit actually measures between the run ends. If they differ by more than 1 mm, you'll get a note in the summary.

**The dimension is on the wrong side of the stair.**
Use a **negative** offset (e.g. `-500`) to flip it to the other side.

**Can I dimension several runs of the same stair?**
Yes. After the first one, click each other run in turn.

**Does it work on linked stairs?**
Yes. Choose **Linked model** at the start. The dimension is created in your model and refers to the linked stair.

**Will the text update if the stair changes?**
The Prefix text won't. It's written once, when the dimension is created. Delete the dimension and run the tool again.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **Modify** panel → **Stairs** dropdown. | ✅ If it's still missing |
| Tool refuses to start | Not in a plan view | Open a floor plan | ❌ |
| Can't click the stair | Wrong choice in "Where is the stair?" | Restart the tool and choose the other option | ❌ |
| **Start Dimensioning** greyed out | The selected run has a problem (see status line) | Choose another run | ❌ |
| Wrong run dimensioned | The run nearest to your click was used | Undo, then click closer to the middle of the run you want | ❌ |
| Value doesn't match the text | Nosing or extended riser | See the summary note | ❌ |
| Curved run refused | Not supported | Dimension by hand | ❌ |
| Run skipped with "end faces sit … off" | Unusual run ends | Dimension by hand | ✅ If it's a normal straight run |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window and of the summary or error message
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **view** you were in
4. Whether the stair was in your model or in a **link**
5. Which **run** you picked, and what you **expected** the dimension to read
