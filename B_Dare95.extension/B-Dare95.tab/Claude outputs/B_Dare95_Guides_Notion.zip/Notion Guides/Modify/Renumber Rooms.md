# Renumber Rooms

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Rooms** dropdown → **Renumber Rooms**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🏷️ **Version:** 3.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Renumber Rooms** gives every placed room a new number, in order of **distance from a corner of your grid**.

You pick one of the **four outer corners** of the grid (top-left, top-right, bottom-left, bottom-right). On each level, the room **closest** to that corner gets the first number, the next closest gets the next number, and so on.

> 💡 Think of dropping a stone at one corner of the building: the rooms are numbered in the order the ripple reaches them.

| Setting | What it gives you |
|---|---|
| **Per Level** | Numbering **restarts** on every level (L01: 1, 2, 3… · L02: 1, 2, 3…) |
| **Full Project** | Numbering **continues** from level to level (L01: 1–20 · L02: 21–40…) |
| **Prefix / Suffix** | Text before/after the number, e.g. `L01-` + `05` → `L01-05` |
| **Start Number** | The first number to use (default **1**) |

📸 *[Screenshot: the Renumber Rooms [Grid-Based] window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on a selection or a single level | It renumbers **all placed rooms on all levels**. |
| Number unplaced rooms | Rooms with no area (unplaced / not enclosed) are left out. |
| Follow a path or a snake pattern | Order is by **straight-line distance** from the corner, measured to each room's location point. |
| Add a different prefix per level automatically | One prefix is used for every level. In **Per Level** mode, numbers repeat on each level unless you include the level some other way. |
| Use linked grids or linked rooms | Only grids and rooms in the model you're working in. |
| Keep leading zeros on number-type parameters | Zero-padding only applies to **TEXT** parameters (see Section 6). |

---

## 3. Before you start

- [ ] The model has **at least 2 grid lines that cross** (not parallel).
- [ ] Your rooms are **placed** (they have an area).
- [ ] You know which **parameter** to write to (usually **Number**).
- [ ] You've decided: **Per Level** or **Full Project**?

---

## 4. How to use it

1. Click **Rooms** dropdown → **Renumber Rooms**.
2. The **Renumber Rooms [Grid-Based]** window opens.
3. In the left panel **ROOM PARAMETER**, click the parameter to write to (e.g. `Number · TEXT`).
4. Under **REFERENCE CORNER**, click one of the four arrow tiles. The chosen tile turns yellow.
5. Under **SETTINGS**, fill in **Prefix**, **Suffix** *(both optional)* and **Start Number**.
6. Choose **Sequence Mode**: **Per Level** or **Full Project**.
7. Click **RUN**.
8. A summary appears, with a line for every level. ✅

### Window controls

| Control | What it does |
|---|---|
| **ROOM PARAMETER** list | Every editable text or whole-number parameter on your rooms. Each shows **TEXT** (any characters) or **INT** (digits only). |
| Hint line (under the list) | Confirms your choice, e.g. "✔ Number · TEXT — accepts any string". |
| **Corner tiles** (↖ ↗ ↙ ↘) | The grid corner to number from. Each tile shows that corner's X / Y position. |
| Status line (under the tiles) | How many levels and rooms will be numbered, e.g. "3 levels · 84 rooms". |
| **Prefix (optional)** | Text before the number. |
| **Suffix (optional)** | Text after the number. |
| **Start Number** | The first number. Must be a whole number. |
| **Per Level / Full Project** | Restart on each level, or continue across levels. |
| **RUN** | Checks your inputs and renumbers. |
| **CANCEL** | Closes the window. Nothing changes. |

> ℹ️ The X / Y on the corner tiles are shown in **feet**, from the model's internal origin, whatever your project units are. They're only there to help you tell the corners apart.

---

## 5. How the corners are found

- The tool finds every point where two grid lines cross.
- The four tiles are the crossing points **closest to the four outer corners** of all those points.
- **Top** and **Left** are as seen in a plan view that **isn't rotated** (top = highest Y, left = lowest X).

> ⚠️ If your plan view is rotated (e.g. to True North), "top-left" on the tile may not be top-left on your screen. Use the X / Y values to check.

---

## 6. TEXT vs INT parameters

| | TEXT parameter | INT parameter |
|---|---|---|
| Prefix / Suffix | Any characters (`L01-`, `-A`) | **Digits only** |
| Result example | `L01-07` | `17` (Prefix `1` + number `7`) |
| Leading zeros | ✅ Added automatically | ❌ Not possible |

**Leading zeros (TEXT only):** the number is padded so all numbers have the same length.
- **Per Level:** based on how many rooms are on **that level**. A level with 9 rooms → `1`…`9`. A level with 25 rooms → `01`…`25`.
- **Full Project:** based on the **total** rooms. 150 rooms → `001`…`150`.

> ⚠️ With an **INT** parameter, if Prefix or Suffix contains letters, spaces or symbols, a red message appears in the left panel and nothing runs (see Section 8).

---

## 7. Undoing

All levels are renumbered in **one step**. To undo, press **Ctrl + Z** once, or pick **Renumber Rooms** in Revit's Undo list.

---

## 8. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🟢 **"Renumbering complete!"** | Done. Shows the parameter, corner, sequence mode, a line per level (rooms and number range), and "_N_ rooms numbered · _N_ skipped". | Check a few rooms. |
| 🔵 **"Cancelled."** | You clicked **CANCEL** or closed the window. | Nothing changed. |
| 🔴 **"Insufficient Grid Lines detected. At least 2 non-parallel Grid Lines are required…"** | Fewer than 2 grids, or all grids are parallel. | Add crossing grids and try again. |
| 🔴 **"No placed Rooms found in the project. Please place Rooms before running this script."** | No room has an area. | Place rooms first. |
| 🔴 **"Could not resolve a Level for any placed Room."** | Rooms have no level. | Contact the author. |
| 🟡 **"Please select a Room Parameter."** | No parameter clicked. | Click one in the left list. |
| 🟡 **"Please select a Reference Corner (click one of the four arrow tiles)."** | No corner chosen. | Click a tile. |
| 🟡 **"Start Number must be a whole number (e.g. 1)."** | Start Number is empty or has letters/decimals. | Type a whole number. |
| 🟡 Red panel: **"⚠ INTEGER parameter selected. Prefix + Number + Suffix must together form a whole number…"** | INT parameter with non-digit prefix/suffix. | Use digits only, or pick a TEXT parameter. |

> ℹ️ **"skipped"** in the summary = rooms where the parameter is missing, read-only, or couldn't be written. Skipped rooms don't use up a number.

---

## 9. FAQ

**Will rooms on different levels get the same number in Per Level mode?**
Yes. Each level restarts at the Start Number. Add something that tells levels apart, or use **Full Project**.

**What does "nearest" mean exactly?**
Straight-line distance from the chosen grid corner to the room's location point (the point where the room was placed), in plan.

**In what order are levels numbered in Full Project mode?**
From the **lowest** level to the **highest**.

**Can I renumber only one level?**
No. All placed rooms on all levels are renumbered.

**Why is a Yes/No parameter in the list as INT?**
The list shows every editable whole-number parameter. Don't pick Yes/No parameters for numbering.

**I picked "TOP-LEFT" but numbering starts somewhere else.**
Your view may be rotated, or your grids may not form a simple rectangle. Compare the X / Y on the tiles with your grids.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab. | ✅ If still missing |
| "Insufficient Grid Lines" | Grids missing or all parallel | Add at least one grid in each direction | ❌ |
| Some rooms not numbered | Unplaced, or parameter read-only | Check the room has an area. Check groups / ownership. | ❌ |
| Order looks odd | Distance is measured to the room's location point, not its centre | Move the room point, or accept the order | ❌ |
| Numbers repeat on each level | **Per Level** mode | Use **Full Project**, or a level-specific prefix | ❌ |
| Leading zeros not as expected | Padding depends on room count, not on the end number | See Section 6 | ❌ |
| Corner seems wrong on curved grids | Curved grids are treated as straight lines between their ends | Check the X / Y on the tiles | ✅ If it matters |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your choices, and of the summary or error
2. Your **Revit version** (e.g. 2025)
3. The **model name**
4. The **parameter**, **corner**, **prefix/suffix**, **start number** and **sequence mode** you used
5. **What you expected**, and what actually happened
