# Enlarged Plan Generator

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Views** dropdown → **Enlarged Plan Generator**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Enlarged Plan Generator** creates a set of views for each room you tick. For **every room** you get **three new views**:

| New view | What it is | Default name |
|---|---|---|
| **Enlarged plan** | A floor plan on the room's level, cropped tightly around the room | `EP - Office_101` |
| **Section X** | A section through the **centre** of the room, looking **east** (along the project's X direction) | `EP - Office_101 - Section X` |
| **Section Y** | A section through the **centre** of the room, looking **north** (along the project's Y direction) | `EP - Office_101 - Section Y` |

Each view has **50 cm of space** around the room on every side.

> 💡 Think of it as a photographer for rooms: point it at a list of rooms and it takes a close-up from above and two cut-through shots for each one.

📸 *[Screenshot: the Enlarged Plan Generator window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| List unplaced or unenclosed rooms | Only rooms with an area greater than zero are listed. |
| Let you choose the view types | The plan uses the project's **default floor plan type**. The sections use the **first section type** found in the project. |
| Let you change the 50 cm margin | The crop margin is fixed. |
| Rotate views to match the room | Plans stay north-up. Sections always run along the project's X and Y directions, even if the room is at an angle. |
| Place views on sheets | Views are only created. Place them on sheets yourself. |
| Filter the template lists by view type | Every view template in the project is listed. Pick a **plan** template for the plan and a **section** template for the sections. |

---

## 3. Before you start

- [ ] Rooms are **placed and enclosed** (they have an area).
- [ ] Rooms have a **Name** and a **Number**. These are used in the view names.
- [ ] You know which **view templates** you want for the plan and for the sections (optional).
- [ ] Decide on a **prefix** and/or **suffix** for the view names.

---

## 4. How to use it

1. Click **Enlarged Plan Generator** in the **Views** dropdown.
2. The **Enlarged Plan Generator** window opens.
3. On the left, under **ROOMS**, tick the rooms you want. Use **Search rooms...** to find them quickly.
4. On the right, under **SETTINGS**:
   - Choose an **Enlarged Plan — View Template** (or leave `<None>`).
   - Choose a **Section — View Template** (or leave `<None>`).
   - Change the **Prefix** and **Suffix** if needed. The grey example text below updates as you type.
5. Click **Generate Views**.
6. A pyRevit output window shows the progress, room by room. ✅

### Window controls

| Control | What it does |
|---|---|
| **Search rooms...** | Filters the room list by number or name. |
| **Select All** | Ticking it ticks every room **currently shown**. Unticking it unticks **every** room. |
| **Room list** | Shown as `Number — Name`, sorted by name, then number. |
| **Enlarged Plan — View Template** | Template for the new plans. `<None>` = no template. |
| **Section — View Template** | Template for the new sections. `<None>` = no template. |
| **Prefix** | Text at the start of every view name. Default: `EP - ` |
| **Suffix** | Text at the end of every view name. Default: empty |
| **Example text** | Shows how the names will look. |
| **Generate Views** | Creates the views. |
| **Window X** | Closes the window without creating anything. |

---

## 5. How views are named

| View | Name pattern |
|---|---|
| Enlarged plan | `{Prefix}{Room Name}_{Room Number}{Suffix}` |
| Section X | `{Prefix}{Room Name}_{Room Number} - Section X{Suffix}` |
| Section Y | `{Prefix}{Room Name}_{Room Number} - Section Y{Suffix}` |

- If the room has **no number**, the `_{Room Number}` part is left out.
- If the room has **no name**, `Room` is used.
- If a name is **already taken**, the tool adds `*` to the end (e.g. `EP - Office_101*`) until the name is free.

---

## 6. Undoing

All views from one run are **one Undo step** called **Enlarged Plan Generator v4**.

| You want to… | Do this |
|---|---|
| Close without creating | Close the window with **X**. The output window says *"Cancelled — no views were created."* |
| Undo the whole run | Press **Ctrl + Z** once, or pick **Enlarged Plan Generator v4** in the Undo list |
| Remove only some views | Delete them from the Project Browser |
| An error stopped the run | Nothing to undo. All views from that run were rolled back. |

---

## 7. Messages you may see

### In the window

🟡 **No Rooms Selected — "Please check at least one room."**
*Why:* You clicked **Generate Views** with no room ticked.
*What to do:* Tick at least one room.

### In the output window

🔵 **"Processing _N_ room(s)..."**, then **"Processing: <room>"** for each room.

🟢 **"[OK] Enlarged Plan : <name>"**, **"[OK] Section X : <name>"**, **"[OK] Section Y : <name>"**
*Why:* That view was created.

🟢 **"Done. _N_ room(s) processed successfully."**
*Why:* The run finished.

🟡 **"[WARN] Could not apply plan template: …"** / **"[WARN] Could not apply section template: …"**
*Why:* The template you picked can't be used on that kind of view (e.g. a section template on a plan). The view was still created, without a template.
*What to do:* Apply a suitable template by hand, or Undo and run again with the right templates.

🟡 **"[WARN] Could not create Section X for <room>."** (or Section Y)
*Why:* The tool couldn't measure the room in the new plan, or the project has no section view type.
*What to do:* Check that the room is visible in plans and that a section type exists. Contact the author if it repeats.

🔵 **"Cancelled — no views were created."**
*Why:* You closed the window without clicking **Generate Views**.

🔴 **An error listing in the output window, followed by a pyRevit error**
*Why:* Something unexpected stopped the run. All views from this run were rolled back.
*What to do:* Screenshot the output window and contact the author.

---

## 8. FAQ

**Which direction do the sections look?**
**Section X** looks along the project's **X** direction (east). **Section Y** looks along the project's **Y** direction (north). Both cut through the centre of the room.

**Can I make only the plan, without sections?**
No. Each room always gets a plan and two sections. Delete the ones you don't need.

**Why can I see 3D or schedule templates in the template lists?**
The lists show every view template in the project. Pick one that matches the view kind.

**Why does a view name end with `*`?**
A view with that name already existed, so `*` was added to keep names unique.

**Why isn't my room in the list?**
It's not placed, or not enclosed (area = 0). Fix the room boundaries first.

**Which level is the plan on?**
The room's own level.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Look under **Modify** panel → **Views** dropdown. | ✅ If it's still missing |
| Room missing from the list | Unplaced or unenclosed room | Check the room in the Room schedule | ❌ |
| View names end with `*` | Name already used | Rename or delete the older views | ❌ |
| A view has the wrong template, or none | Template doesn't suit that view kind | Read the `[WARN]` lines. Apply the template by hand. | ❌ |
| View name isn't what I expected (e.g. a default name) | The room name may contain characters Revit doesn't allow in view names | Check the room name. Rename the view by hand. | ✅ If unclear |
| Sections missing | Section couldn't be created | Read the `[WARN]` lines | ✅ If it repeats |
| Section looks the wrong way | Sections follow the project X/Y, not the room | Flip or rotate the section by hand | ❌ |
| Error in the output window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your settings
2. A **screenshot** of the **output window**
3. Your **Revit version** (e.g. 2025)
4. The **model name**, and the **room numbers / names** you used
5. **What you expected**, and what actually happened
