# Stair Riser Chain

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Stairs** dropdown → **Stair Riser Chain**
> 🧩 **Works with:** Revit 2024 and newer · section and elevation views · stairs in your model or in a loaded Revit link
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Stair Riser Chain** places **one vertical chain dimension** up the whole height of a stair in a section or elevation. There's **one segment per run**, and each segment gets its riser breakdown written in front of it:

> **11 EQ. RISERS @ 170MM = 1870 MM**

- `11 EQ. RISERS @ 170MM = ` is written into each segment's **Prefix**.
- `1870` is the **real measured value** from Revit.
- `MM` is written into each segment's **Suffix**.

The chain goes from the **bottom of the stair**, through the **top of each landing**, up to the **surface the top run finishes on** (a landing, a floor or a level).

You choose your settings once, then click stair after stair. Press **Esc** to finish.

> 💡 It's the section version of "count the risers and write it on the dimension", done for the whole stair in one click.

📸 *[Screenshot: a stair in section with the finished chain dimension]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work outside sections and elevations | Plans, 3D and drafting views are refused. For the run length in plan, use **Stair Run Dimension**. |
| Work in tilted views | The view must be upright. |
| Override the dimension values | Revit's measured values are shown as is. Only the Prefix and Suffix are written. |
| Remember your settings | The window starts with the defaults each time you run the tool. |
| Update the text later | If the stair changes, the Prefix text stays as it was. Delete the dimension and run the tool again. |
| Let you choose which runs | Every usable run of the stair you click gets a segment. |

---

## 3. Before you start

- [ ] A **section or elevation** view is open and active, and it isn't tilted.
- [ ] The stair is **visible** in the view.
- [ ] You know whether the stair is in **your model** or in a **linked model**.
- [ ] The linear **dimension type** you want exists in the project.

---

## 4. How to use it

1. Open the section or elevation and click **Stair Riser Chain**.
2. A box asks **"Where is the stair?"** Click **Host model** or **Linked model**.
3. **Click the stair** in the view.
4. The **Stair Riser Chain Dimension** window opens. The subtitle shows which model the stair is in.
5. Pick a **Dimension type** on the left.
6. Check the **Runs** list. It shows every run of the stair and the riser count of each. It's for information only, so you can't click it.
7. Adjust the **Offset**, **Prefix template** and **Suffix** if needed. Watch the **Preview**.
8. Click **Start Chaining**. The chain dimension is placed. ✅
9. **Click the next stair.** It's dimensioned straight away with the same settings.
10. Press **Esc** when you're done. A summary box shows how many segments were dimensioned, and what each dimension line was attached to.

> ⚠️ **Click the whole stair**, not a single run. If you pick just one run (e.g. with **Tab**), only that run gets a segment.

📸 *[Screenshot: the Stair Riser Chain Dimension window]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** (above the type list) | Filters the dimension types as you type. |
| **Dimension type** list | Only **linear** dimension types are listed. The first one is pre-selected. |
| **Runs on the stair you pick** | Each run, e.g. *Run 1 \| 11 risers @ 170 mm = 1870 mm*. A run with a problem shows the reason instead. |
| **Offset from stair (mm)** | Distance from the stair's outermost edge to the dimension line. Default **500**. **Positive** = right side of the stair as seen in the view. **Negative** = left side. |
| **Prefix template** | Text in front of each segment's value. `{N}` = number of risers, `{H}` = riser height. Default `{N} EQ. RISERS @ {H}MM = ` |
| **Suffix** | Text after each value. Default `MM`. Leave it empty for no suffix. |
| **Preview** | How the first usable run's segment should read. |
| **Status line** (bottom left) | Tips, or why **Start Chaining** is greyed out. |
| **Cancel** / **X** | Closes the window and ends the tool. |
| **Start Chaining** | Places the first chain and continues picking. |

> 💡 The window has no normal title bar. Drag it by its **header** to move it.

---

## 5. Reading the summary

At the end you get a box that starts with **"Segments dimensioned: [N]"**. For each stair it then lists:

- A heading such as **"--- Host model: [model name] ---"**
- Any problems (see [Section 7](#7-messages-you-may-see))
- One line per dimension point, from the bottom up, e.g.:

| Line in the summary | Meaning |
|---|---|
| **Plane 0: base of the stair** | Bottom of the chain |
| **Plane 1: landing top (base of run 2)** | Top of a landing, where the next run starts |
| **landing top surface** · **stair surface** · **landing at the finish level** · **floor at the finish level** | Where the top run finishes |
| **level '[name]'** | The top run finishes on a level line |
| 🟡 **top tread of the run (finish surface not found)** | No finish surface was found. The top segment is **one riser short**. Check it. |

---

## 6. Undoing

| You want to… | Do this |
|---|---|
| Stop before anything is placed | Click **Cancel** in the box or the window, or press **Esc** while picking. |
| Undo the last chain | **Ctrl + Z** once. Each stair is one Undo step called **Stair Riser Chain Dimension**. |
| Remove a chain later | Select it and delete it. |

---

## 7. Messages you may see

### When starting

**🔴 "Open a section or elevation view and run the tool again."**
*Why:* No usable view is active.
*What to do:* Open a section or elevation.

**🔴 "This tool only runs in a section or elevation view. Current view is a [view type]."**
*What to do:* Switch to a section or elevation.

**🔴 "This view is tilted, so a vertical dimension cannot be placed reliably. Use an upright section or elevation."**
*What to do:* Use a normal, upright section.

**🟡 "No type reported a Linear style, so every dimension type in the project is listed instead. Pick a linear one."**
*What to do:* Pick a **linear** type from the full list.

**🔴 "No DimensionType elements were found in this document at all."**
*What to do:* Load or create a linear dimension type.

### While picking

**🔴 "That link is not loaded." · "That pick did not come from a Revit link." · "Nothing usable was selected." · "Selected element is a [type], not a stair." · "That stair has no runs."**
*What to do:* Click **OK** and pick a stair. Picking continues.

**🔴 "The pick returned the link instance rather than an element inside it. Nested links are not supported."**
*What to do:* Open the linked model directly.

**🔴 "Selection failed: …"**
*What to do:* The tool stops. Screenshot it and contact the author.

### In the window

| Message | What to do |
|---|---|
| "No usable runs on this stair." | **Start Chaining** is greyed out. Click **Cancel** and run the tool on another stair. |
| Run shown as "no horizontal faces with references on this run" · "riser height unavailable and not derivable" · "calculated riser count is less than 1" | That run is left out of the chain. Contact the author if it's a normal run. |
| "Pick a dimension type." | Select a type. |
| "Offset must be a number (mm)." | Type a plain number, e.g. `500`. Use a dot for decimals. |

### In the summary

| Note | Meaning | What to do |
|---|---|---|
| 🟡 "Run N: reads X mm, expected N risers x H mm = E mm (K riser(s) short)." | The segment **was placed**, but its value doesn't match risers × height. | Check that segment. Often the top finish surface wasn't found. |
| 🟡 "WARNING - X segments were created for Y runs, so the segment text may not line up with the runs." | The text may sit on the wrong segment. | Check each segment's text and fix it by hand. |
| 🟡 "Run N: run M starts X mm above this run's finish, not on it." | The runs don't stack neatly (e.g. thick landing). The tool searched for the finish surface instead. | Check the chain. |
| 🔴 "Run N: no plane found above it - chain stops here." | The chain ends below that run. | Dimension the rest by hand. |
| 🔴 "No dimension planes could be established on this stair." · "No bounding box on the stair - cannot place the dimension." · "The chain has no height." | Nothing placed for that stair. | Contact the author. |
| 🔴 "A plane could not be referenced through the link (…)" · "Dimension creation failed - …" | Nothing placed for that stair. | Screenshot and contact the author. |

---

## 8. FAQ

**Why is my top segment one riser short?**
The tool couldn't find the floor, landing or level the top run finishes on, so it stopped at the top tread. Look for **"top tread of the run (finish surface not found)"** in the summary.

**The chain is on the wrong side of the stair.**
Use a **negative** offset (e.g. `-500`) to put it on the left side as seen in the view.

**Can I change the wording?**
Yes. Edit the **Prefix template**. Keep `{N}` and `{H}` where you want the numbers.

**Does it work on linked stairs?**
Yes. Choose **Linked model** at the start. The dimension is created in your model.

**Why is the Runs list greyed out / not clickable?**
It's for information only. Every usable run is included automatically.

**Can I dimension several stairs?**
Yes. After the first one, click each other stair in turn. Each gets its own chain.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **Modify** panel → **Stairs** dropdown. | ✅ If it's still missing |
| Tool refuses to start | Not a section/elevation, or tilted view | Use an upright section | ❌ |
| Can't click the stair | Wrong choice in "Where is the stair?" | Restart and choose the other option | ❌ |
| Only one segment on a multi-run stair | You picked a single run | Undo, then click the whole stair | ❌ |
| Top segment one riser short | Finish surface not found | Check the summary | ✅ If the floor/landing is clearly there |
| Text on the wrong segments | Segment count mismatch warning | Fix the text by hand | ✅ |
| **Start Chaining** greyed out | No usable runs | Cancel, try another stair | ✅ If it's a normal stair |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window and of the summary or error message
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **section/elevation** you were in
4. Whether the stair was in your model or in a **link**
5. What you **expected** each segment to read, and what it actually reads
