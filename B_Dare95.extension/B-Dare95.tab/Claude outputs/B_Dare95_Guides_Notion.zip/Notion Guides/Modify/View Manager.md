# View Manager

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Views** dropdown → **View Manager**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**View Manager** shows **every view in your project in one table**, like a spreadsheet. You can:

- **Find** views fast by type, by name, by sheet, or by whether they're on a sheet.
- **Edit** names, view templates, titles on sheet, detail numbers, and sheet numbers/names **right in the table**.
- **Apply** all your edits in one go.
- **Jump** to a view, or to the sheet it's placed on.

Nothing changes in the model until you click **Apply**.

The window **stays open while you keep working in Revit**. You can move it to a second screen and use it alongside your model.

> 💡 Think of it as the Project Browser turned into a spreadsheet: you see everything side by side, type your changes, then save them all at once.

📸 *[Screenshot: the View Manager window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| List sheets or view templates as rows | Sheets appear only in the **SHEET** columns. Templates appear only in the **View Template** dropdown. |
| Update live while you work | If you change views in Revit while the window is open, click **Reload** to see the changes. |
| Save edits automatically | Edits wait until you click **Apply**. **Closing the window throws away unapplied edits without asking.** |
| Create, duplicate or delete views | It only reads and edits existing views. |
| Edit sheet number/name for views on several sheets | E.g. a legend or schedule placed on many sheets. Those rows are skipped. |
| Let you choose a template made for another view type | Each row's dropdown only shows templates for **that** view type. |

---

## 3. Before you start

- [ ] The model you want to work on is the **active** model in Revit.
- [ ] In a workshared model, make sure you can edit the views and sheets you plan to change (nobody else has them borrowed).

---

## 4. How to use it

1. Click **View Manager** in the **Views** dropdown.
2. The **View Manager** window opens and lists all views.
3. Narrow the list with the **filters** at the top (see below).
4. **Double-click** a cell to edit it, type the new value, and press **Enter**. For **View Template**, just pick from the dropdown.
5. The line under the title counts your **pending edit(s)**.
6. Click **Apply**. The edits are written to the model, and the table reloads.
7. A message at the bottom of the window tells you the result. ✅

> 💡 Clicking the button again while the window is already open just brings the window to the front. You never get two copies.

### Filters

| Control | What it does |
|---|---|
| **View type** | **All view types**, or one type (see the table below). Only types that exist in the model are listed. |
| **Sheet: All / On sheet / Not on sheet** | Show every view, only views placed on a sheet, or only views not on any sheet. |
| **Search view name...** | Shows views whose name contains your text. |
| **Search sheet number - name...** | Shows views placed on sheets whose `number - name` contains your text. |

All filters work together. Click a **column header** to sort by that column.

**View type names** in the list use Revit's internal names. The less obvious ones:

| Shown as | Means |
|---|---|
| `FloorPlan` | Floor plan |
| `CeilingPlan` | Reflected ceiling plan |
| `EngineeringPlan` | Structural plan |
| `AreaPlan` | Area plan |
| `ThreeD` | 3D view |
| `DraftingView` | Drafting view |
| `Detail` | Detail view |
| `Schedule` / `PanelSchedule` | Schedules |

### Columns

| Column | Editable? | Notes |
|---|---|---|
| **Id** | ❌ | Revit's element ID of the view |
| **View Name** | ✅ | Can't be empty, and must be unique in the model |
| **View Type** | ❌ | |
| **Level** | ❌ | Blank for views without a level |
| **View Template** | ✅ (dropdown) | `<None>`, or templates of the same view type |
| **Title on Sheet** | ✅ | |
| **Detail No.** | ✅ | Only for views placed on a sheet |
| **SHEET → Number - Name** | ❌ | The sheet(s) the view is on. Several sheets are separated by commas. |
| **SHEET → Number** | ✅ | ⚠️ Changes the **sheet's** number |
| **SHEET → Name** | ✅ | ⚠️ Changes the **sheet's** name |

> ⚠️ **Editing Number or Name in the SHEET columns renames the sheet itself.** Every view on that sheet will show the new number/name after **Apply**.

### Buttons

| Button | What it does |
|---|---|
| **Open View** | Opens the selected row's view in Revit. |
| **Open Sheet** | Opens the sheet the selected view is on. If it's on several sheets, a list (**This view is on several sheets**) lets you choose one, then click **Open sheet**. |
| **Reload** | Re-reads the model. If you have pending edits, it asks first. |
| **Apply** | Writes all pending edits to the model. |
| **Close** | Closes the window. ⚠️ Pending edits are lost without warning. |

---

## 5. How edits work

- Each changed cell counts as **one pending edit**. Change a cell back to its old value and it no longer counts.
- **Apply** writes all edits together. Edits that Revit refuses are **skipped**, and the rest still go through.
- If two rows on the **same sheet** ask for **different** sheet numbers (or names), the first one wins and the other is skipped.
- After **Apply**, the table reloads from the model, so you see the real result.

---

## 6. Undoing

All edits from one **Apply** are **one Undo step** called **View Manager - apply edits**.

| You want to… | Do this |
|---|---|
| Throw away edits before applying | Click **Reload** and answer **Yes**, or close the window |
| Undo an Apply | Press **Ctrl + Z** in Revit (or pick **View Manager - apply edits** in the Undo list), then click **Reload** in the window |
| Undo just one cell | Type the old value back and **Apply** again |

Opening views, opening sheets, filtering, sorting and reloading don't change the model, so there's nothing to undo.

---

## 7. Messages you may see

### At the bottom of the window

🟢 **"_N_ edit(s) applied."**
*Why:* All edits were saved.

🟡 **"_N_ edit(s) applied, _M_ skipped - details in the output window."**
*Why:* Some edits were refused. A pyRevit output window lists each one as `view name -> column: reason`.
*What to do:* Read the reasons (see the table below), fix the values, and **Apply** again.

🔵 **"Nothing to apply."**
*Why:* There are no pending edits.

🔵 **"Reloaded from the model."**
*Why:* You clicked **Reload**.

🔵 **"Select a row first."**
*Why:* You clicked **Open View** or **Open Sheet** without a row selected.

🔵 **"That view is not placed on a sheet."**
*Why:* **Open Sheet** was clicked on a view that isn't on any sheet.

🟡 **"The active document changed - press Reload before applying."**
*Why:* You switched to another model while the window was open.
*What to do:* Go back to the original model, or click **Reload** to load the new one. (Reloading discards your pending edits.)

🟡 **"That sheet no longer exists - press Reload."**
*Why:* The sheet was deleted since the table was loaded.
*What to do:* Click **Reload**.

🔴 **"Could not open that view: …"** / **"Could not open that sheet: …"**
*Why:* Revit refused to open it.
*What to do:* Open it from the Project Browser. Contact the author if it repeats.

🔴 **"Transaction failed, nothing was changed: …"**
*Why:* Something unexpected stopped the Apply. No edits were saved.
*What to do:* Screenshot it and contact the author.

### Skip reasons in the output window

| Reason | What to do |
|---|---|
| `view name cannot be empty` | Type a name |
| `'<name>' is not a view template for this view type` | Pick a template from the dropdown |
| `view is not placed on a sheet` | Sheet Number/Name can only be edited for placed views |
| `view is placed on several sheets - edit them one sheet at a time` | Edit the sheet via another view that's only on that sheet, or in the Project Browser |
| `sheet number / name cannot be empty` | Type a value |
| `detail number needs the view to be placed on a sheet` | Place the view on a sheet first |
| `parameter is read-only for this view` / `parameter not available on this view` | That view doesn't allow this value to be changed |
| `conflicts with another row on the same sheet ('…' was written)` | Two rows on the same sheet asked for different values. Make them match. |
| `view no longer exists` | It was deleted. Click **Reload**. |
| Any other Revit message (e.g. name already in use) | Choose a different value |

### Pop-ups

🟡 **"You have unsaved edits. Reload and discard them?"** (Yes / No)
*Why:* You clicked **Reload** with pending edits.
*What to do:* **Yes** throws the edits away. **No** keeps them.

🔴 **"View Manager action failed:"** followed by details
*Why:* Something unexpected happened.
*What to do:* Screenshot it and contact the author.

---

## 8. FAQ

**Can I keep the window open while I work?**
Yes. That's what it's for. Click **Reload** after changing views in Revit.

**I changed a sheet number in one row, and other rows changed too after Apply. Why?**
Those views are on the same sheet. The SHEET columns edit the sheet itself.

**Why is my template missing from the dropdown?**
The dropdown only shows templates made for that row's view type.

**Can I edit many rows at once?**
You edit cell by cell, but you can make as many edits as you like before one **Apply**.

**Why do schedules and legends appear?**
They're views too. Their sheet columns show every sheet they're on.

**Does closing the window save my changes?**
No. Only **Apply** saves. Closing discards pending edits.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Look under **Modify** panel → **Views** dropdown. | ✅ If it's still missing |
| Clicking the button does nothing visible | The window is already open, maybe behind Revit or on another screen | Use **Alt + Tab** or check your other monitor | ❌ |
| A view I just made isn't listed | The table isn't live | Click **Reload** | ❌ |
| Filters show nothing | Several filters active at once | Set **All view types**, **All**, and clear both search boxes | ❌ |
| The Sheet toggles all look off | An active toggle was clicked again | Click **All** | ❌ |
| An edit was skipped | Revit refused it | Read the output window | ❌ |
| My edits vanished | The window was closed, or **Reload** was confirmed | Re-enter them and **Apply** | ❌ |
| "The active document changed" | You switched models | Go back, or **Reload** | ❌ |
| "Transaction failed" or "action failed" | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window, including the message at the bottom
2. A **screenshot** of the **output window** if edits were skipped
3. The **view names** and **columns** you edited, with the values you typed
4. Your **Revit version** (e.g. 2025)
5. The **model name**, and whether it's **workshared**
