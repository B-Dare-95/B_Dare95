# Shaft Function Tag

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Modify** panel → **Shafts** dropdown → **Shaft Function Tag**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Shaft Function Tag** writes each shaft's **Shaft Function** value (e.g. *Plumbing*, *Electrical*) as a **text note** inside the shaft, in the plan views you choose.

- It works on shafts in **your model** and in **loaded linked models**.
- A shaft gets a note in a view when the view's **cut plane passes through** the shaft (the shaft starts below the cut plane and ends above it).
- The note is placed near the **bottom-left corner** of the shaft, slightly inside it, and is **left-aligned**.

> 💡 It saves you from typing "PLUMBING" in fifty shafts on twenty floors.

> ℹ️ Despite the name, it places **text notes**, not Revit tags.

📸 *[Screenshot: a plan with shafts showing their function text in the bottom-left corner]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Place real Revit tags | The notes are plain text. They **don't update** if the Shaft Function changes later. |
| Check for existing notes | Running it twice on a view places the notes **again**, on top of the old ones. |
| Tag shafts that start above the cut plane | For "open above" shafts, use **Shafts Open Above**. |
| Respect the crop region or hidden links | Every shaft that crosses the cut plane gets a note, even if it's outside the crop box or its link is hidden in the view. |
| Tag shafts with an empty Shaft Function | They're skipped and counted in the report. |
| Work in ceiling plans, sections or 3D | Only **Floor Plans** and **Structural Plans** are listed. |
| Change your shafts | Shafts are only read. |

---

## 3. Before you start

- [ ] A model is **open**, with at least one **Floor Plan** or **Structural Plan**.
- [ ] The shafts have the **Shaft Function** parameter (see **Create Shaft Param**) and it's **filled in**.
- [ ] Linked models you want included are **loaded**.
- [ ] You know which **text note type** to use.

---

## 4. How to use it

1. Click **Shaft Function Tag** in the **Shafts** dropdown.
2. The **Shaft Function Tag** window opens.
3. Keep or untick **Include shafts from linked models**. The label shows how many links and linked shafts were found.
4. *(Optional)* Type in the **search box** to filter the view list.
5. Tick the **Plan Views** to tag.
6. Choose a **Text Note Type**.
7. Click **Apply**.
8. A **"Done!"** message shows how many views were processed and how many notes were placed. ✅
9. The **pyRevit output window** shows the result per view.

📸 *[Screenshot: the Shaft Function Tag window]*

### Window controls

| Control | What it does |
|---|---|
| **Include shafts from linked models** | Adds shafts from loaded links. Greyed out with "(none found)" when there are no linked shafts. |
| **Search box** | Filters the view list by view name. |
| **Select All** | Ticks every view **currently shown**. |
| **Clear All** | Unticks **every** view, including hidden ones. |
| **Plan Views** list | Floor and structural plans, sorted by name. |
| **Text Note Type** | The text type used for the notes. |
| **Apply** | Places the notes. |
| **Cancel** / window **X** | Closes without placing anything. |

---

## 5. Which shafts get a note

In each ticked view, a shaft gets a note when:

| Rule | Details |
|---|---|
| It crosses the cut plane | Its bottom (base level + Base Offset) is **below** the view's cut plane, and its top is **above** it. If the top is *Unconnected*, only the bottom is checked. |
| It has a value | **Shaft Function** isn't empty. |
| It has a size | Revit can give its extents (otherwise it's counted as "no bounding box"). |

> ⚠️ The note is placed at a **fixed distance** (about 76 mm in model units) inside the bottom-left corner of the shaft's **overall rectangle**. For rotated or L-shaped shafts, the note can land just outside the shaft's actual outline. Move it by hand if needed.

---

## 6. Undoing

Each view is its **own** Undo entry, named **Shaft Function Tag — \<view name\>**.

| You tagged… | To undo everything |
|---|---|
| 1 view | **Ctrl + Z** once |
| 8 views | **Ctrl + Z** eight times, or pick the 8th **Shaft Function Tag — …** in Revit's Undo list |

You can also delete the notes by hand. They're ordinary text notes and aren't pinned.

---

## 7. Messages you may see

🔴 **"No floor plan views found in the document."**
*What to do:* Create a Floor Plan or Structural Plan first.

🔴 **"No text note types found in the document."**
*What to do:* Very unusual. Contact the author.

🟡 **"No shaft openings found in the active document or in any loaded linked model."**
*What to do:* Check the model has shafts, and that links are loaded.

🔴 **Parameter Not Found** — "The parameter "Shaft Function" was not found on any Shaft Opening (host or linked) in this document."
*What to do:* Run **Create Shaft Param**, fill in the values, then try again.

🟡 **"Please tick at least one plan view."**
*What to do:* Tick a view, then click **Apply**.

🟢 **Shaft Function Tag** — "Done! Views processed : X  Text notes placed: Y"
It may also list **Linked models included** and **Failed views**.

**In the pyRevit output window**, per view:
- ✅ `Level 02 — 6 tagged, 2 skipped (empty parameter)` — the skipped shafts have no Shaft Function value.
- ✅ `… skipped (no bounding box)` — Revit couldn't give those shafts' size.
- ⚠ `Text note failed — shaft 123456 (…) in Level 02: …` — that one note couldn't be placed.
- ❌ `Level 02 — Error: …` — nothing was kept for that view. Screenshot it and contact the author.

---

## 8. FAQ

**Will the notes update if I change the Shaft Function?**
No. They're plain text. Delete them and run the tool again.

**I ran it twice and now there are double notes.**
The tool doesn't check for old notes. Undo the second run, or delete the duplicates.

**Why did a shaft in my plan get no note?**
Either its Shaft Function is empty, or it doesn't cross the cut plane (for example it starts above it). Check the output window for "skipped".

**Why did a shaft outside my crop region get a note?**
The tool doesn't check the crop region. Delete the extra notes, or hide them with the crop.

**My linked shafts weren't tagged.**
Check **Include shafts from linked models** was ticked, the link is loaded, and the linked shafts have a Shaft Function value.

**How is this different from Shafts Open Above?**
**Shaft Function Tag** labels shafts the plan **cuts through**. **Shafts Open Above** draws outline, X and label for shafts that **start above** the cut plane.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab not loaded | Restart Revit. Look in **Modify** panel → **Shafts** dropdown. | ✅ If it's still missing |
| Many "skipped (empty parameter)" | Shaft Function not filled in | Fill it in (e.g. with **Shaft Opening Manager**) | ❌ |
| Note outside the shaft | Shaft is rotated or irregular | Move the note by hand | ❌ |
| Notes in the wrong views | Shaft crosses the cut plane of those views | Check the view range and shaft heights | ❌ |
| Notes for hidden linked shafts | Link visibility isn't checked | Delete the notes, or untick linked models | ❌ |
| Double notes | Tool run twice | Undo or delete duplicates | ❌ |
| ❌ Error line in the output | Unexpected problem in that view | Screenshot the output window | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your choices
2. A **screenshot** of the "Done!" message and the pyRevit output window
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **view names**, and whether the shafts are in your model or a link
5. **What you expected**, and what actually happened
