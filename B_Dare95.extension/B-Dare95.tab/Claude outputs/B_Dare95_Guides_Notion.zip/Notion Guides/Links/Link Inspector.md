# Link Inspector

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Links** panel → **Link Inspector**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Link Inspector** gives you a **health check** of your model and **every Revit link** in it, in one window. It can also export a shareable **HTML report**.

For each document it checks:

| Check | Column | What it finds |
|---|---|---|
| **DWG / CAD** | **DWG Links**, **DWG Imports** | CAD files linked or imported inside that document, and whether they sit in one view or the whole model |
| **Warnings** | **Warnings** | How many Revit warnings the document has, grouped by warning text |
| **Levels + Grids** | **Bad Lvl / Grid** | Levels and grids **not** on an accepted workset |
| **Workset1** | **On Workset1** | Elements left on the default **Workset1**, grouped by category |
| **Unused Items** | **Unused Fam / Type** | Families with no placed elements, and unused types inside used families |

Accepted workset names for Levels and Grids: **Shared Levels and Grids** and **Shared Views, Levels, Grids** (upper/lower case doesn't matter).

> 💡 Think of it as a quick "doctor's check-up" for every model you link, before you trust it.

📸 *[Screenshot: the Link Inspector window with the document list and the detail panel]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change anything | It's **read-only**. Nothing is fixed, purged, moved or deleted. |
| Inspect unloaded links | Links that aren't loaded show their status, but no results. |
| Show the same link twice | If a link is placed several times, it's listed **once**. |
| Give a purge list | "Unused" is a **triage** hint. Some items can't be purged (see [Section 6](#6-reading-the-results)). |
| Refresh by itself | Results are a snapshot from when you opened it. Close and reopen after changes. |
| Save the report next to your model | The HTML report goes to your Windows **temp** folder (see [Section 7](#7-the-html-report)). |

---

## 3. Before you start

- [ ] Your model is **open**.
- [ ] The links you want to check are **loaded** (Manage Links).
- [ ] If someone cleaned a link recently, **reload** it first. Results come from the link as it was loaded.
- [ ] Big models: allow some time, especially for **Unused Items**.

---

## 4. How to use it

1. Click **Link Inspector**. It scans your model and all loaded links. This can take a moment.
2. The **Link Inspector** window opens. The top line sums up all documents (DWG links, warnings, levels/grids on a wrong workset, items on Workset1).
3. Click a **document** in the left list. Your own model is the first row, with status **Host model**.
4. Click a **tab** on the right to see the details: **DWG / CAD**, **Warnings**, **Levels + Grids**, **Workset1**, **Unused Items**.
5. *(Optional)* Click **Scan All Unused** to fill the **Unused Fam / Type** column for every document.
6. *(Optional)* Click **Export HTML Report**. The report opens in your browser.
7. Click **Close** when you're done.

> 💡 If your model has **no links**, you get a short message with your own model's numbers instead of the window.

### Window controls

| Control | What it does |
|---|---|
| **Search** box | Shows only documents whose name contains what you type. |
| **Document list** (left) | One row per document: **Document**, **Status**, and the counts per check. |
| **Tabs** (right) | Switch the detail panel between the five checks. |
| **Detail panel** (right) | The findings for the selected document and tab. |
| **Scan All Unused** | Runs the unused-items check on every document. The button then reads **Unused Scanned**. |
| **Export HTML Report** | Saves and opens the HTML report. The button then reads **Report Opened**. |
| **Close** | Closes the window. |

---

## 5. Unused Items: scanned on demand

The unused check is the slowest, so it doesn't run at the start.

- Until it runs, the **Unused Fam / Type** column shows **?**.
- It runs for one document when you open the **Unused Items** tab with that document selected. The cursor shows a wait icon while it works.
- **Scan All Unused** runs it for every document at once.
- The result is shown as a tree, one branch per category, with **Unused families** and **Unused types under used families**.

---

## 6. Reading the results

| You see | Meaning |
|---|---|
| A number, e.g. **12** | Count of findings. **0** = clean. |
| **2 / 1** in **Bad Lvl / Grid** | 2 levels and 1 grid on a wrong workset. |
| **3 / 8** in **Unused Fam / Type** | 3 unused families, 8 unused types under used families. |
| **n/a** | The check doesn't apply (e.g. the model isn't workshared). |
| **?** | Unused items not scanned yet. |
| **—** | The document wasn't inspected (e.g. link not loaded). |

### Status column

Your model shows **Host model**. Links show Revit's link status, e.g. **Loaded**, **NotFound**, **Unloaded**, **LocallyUnloaded**, **InClosedWorkset**. Only loaded links are inspected.

### DWG / CAD tab

Each line shows the file name, the kind (**DWG Link**, **DWG Import**, or another CAD format) and the scope:
- **Model (all views)** = placed in the model,
- **View: _** = placed in one view only,
- **[Type only, no instance]** = still listed in Manage Links but not placed anywhere.

### Workset1 tab

- **"No workset named 'Workset1' in this model."** = nothing to report.
- Counts only cover elements with a category. Sketch lines and similar internals are left out.

### Unused Items — read with care

Unused items are found by counting placed elements per type. Types used only **inside** other types are reported as unused even though Revit can't purge them, for example:
- curtain panels and mullions inside a curtain wall type,
- profiles,
- nested sub-families.

> ⚠️ Treat the list as **triage, not a purge list**.

---

## 7. The HTML report

Click **Export HTML Report**. The report is saved to your Windows **temp** folder as `LinkInspector_<model name>_<date>_<time>.html` and opens in your browser.

The report has:
- summary cards (documents, DWG links, DWG imports, warnings, levels/grids off workset, items on Workset1, unused families, unused types),
- a **Filter documents...** box, **Expand all**, **Collapse all** and **Print** buttons,
- an overview table: click a **column header** to sort, click a **document name** to jump to its details,
- one collapsible section per document with all five checks.

> 💡 Run **Scan All Unused** **before** exporting. Otherwise documents show **not scanned** for unused items.

> 💡 The temp folder gets cleaned from time to time. Save a copy of the report somewhere safe (browser → **Save as**) if you want to keep it.

---

## 8. Undoing

Nothing to undo. Link Inspector never changes your model, so nothing appears in the Undo list.

---

## 9. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🔵 **"No Revit links were found in this model."** + your model's numbers | The model has no Revit links. | Read the numbers. Nothing else to do. |
| 🟡 **"The report was saved but could not be opened automatically:"** + a path | Windows couldn't open the HTML file by itself. | Open the path shown in your browser. |
| 🔴 **"Could not write the HTML report:"** + details | The file couldn't be saved. | Screenshot it and contact the author. |
| 🔴 A pyRevit error window | Something unexpected happened. | Screenshot it and contact the author. |

Inside the window you may also see notes such as **"Model is not workshared - workset check does not apply."** or **"All Levels and Grids are on an accepted workset."** These are results, not errors.

---

## 10. FAQ

**Does it fix anything?**
No. It only reports. You fix things in the link's own file.

**Why is my link's row full of dashes?**
The link isn't loaded. Load it in Manage Links and run the tool again.

**My link is placed three times. Why is it listed once?**
The tool checks each **file** once.

**Why are the warning counts out of date?**
Counts come from the link as it was loaded. Reload the link after someone cleans its warnings.

**Our project uses a different workset name for levels and grids.**
The accepted names are fixed in the tool. Contact the author to change them.

**Why does a family show as unused when I can't purge it?**
It's only used inside another type (e.g. a curtain panel). See [Section 6](#6-reading-the-results).

**Where's my report saved?**
In your Windows temp folder. If it didn't open, the message shows the full path.

**Why does Unused Items take so long?**
It checks every type and every placed element in that document. Big models take longer.

---

## 11. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| Tool takes long to open | Many or large links | Wait | ✅ If Revit freezes |
| Link shows only dashes | Link not loaded | Manage Links → Reload | ❌ |
| Link missing from the list | Same file already listed | Check for a row with the same name | ❌ |
| **Unused Fam / Type** shows **?** | Not scanned yet | Open the **Unused Items** tab, or **Scan All Unused** | ❌ |
| Report says **not scanned** | Exported before scanning | **Scan All Unused**, then export again | ❌ |
| Levels/grids flagged but your workset name is valid | Different naming standard | Note the workset name | ✅ |
| Report didn't open | Browser/file association | Open the path from the message | ❌ |
| "Could not write the HTML report" | File couldn't be saved | Screenshot it | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 12. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the Link Inspector window and of any message
2. The **HTML report**, if you exported one
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **link(s)** involved
5. **What you expected** to see, and what the tool showed
