# Link Worksets

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Links** panel → **Link Worksets**
> 🧩 **Works with:** Revit 2024 and newer · **workshared** projects only
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Link Worksets** lists every **Revit link** and **CAD link/import** in your project, with its loading status and current workset. You pick a new workset for each one from a dropdown and assign them all in one go.

It moves:
- the link **type** (this is what decides whether the link loads when a workset is closed), and
- *(optional, on by default)* every placed **instance** of that link.

> 💡 Instead of opening each link's properties one by one, you set all link worksets from one table.

📸 *[Screenshot: the Link Workset Assigner window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work in non-workshared projects | You get a message and the tool stops. |
| Create worksets | Only existing **user** worksets are offered. Create new ones in **Collaborate → Worksets** first. |
| Load or unload links | Status is shown for information only. |
| List nested links | Only links placed directly in your project are listed. |
| Move links owned by others | Rows owned by another user are locked. |
| Sync for you | Changes are local until you **Synchronize with Central**. |

---

## 3. Before you start

- [ ] The project is **workshared**.
- [ ] The target **worksets exist**.
- [ ] Nobody else has the links **borrowed**. Ask them to sync and relinquish.
- [ ] Decide whether you want to move the **instances** too, or only the **types**.

---

## 4. How to use it

1. Click **Link Worksets**. The **Link Workset Assigner** window opens.
2. Each row shows a link: **LINK NAME**, **TYPE**, **STATUS**, **CURRENT WORKSET**.
3. In the **ASSIGN TO** dropdown of each row, pick the new workset. Leave **-- Keep current --** for rows you don't want to change.
4. *(Optional)* Use **Search** and **Set all visible to … → Apply** to set many rows at once (see [Window controls](#window-controls)).
5. Check **Also assign the link instances** (ticked by default).
6. Click **Assign Worksets**.
7. A **Done** message shows how many elements were moved. ✅
8. **Synchronize with Central** to share the change.

### Window controls

| Control | What it does |
|---|---|
| **Search** | Shows only rows whose name, type, status or current workset contains what you type. |
| **Set all visible to** + **Apply** | Sets the **ASSIGN TO** dropdown of every **visible**, unlocked row to the chosen workset. It doesn't assign anything yet. |
| **ASSIGN TO** dropdown (per row) | The new workset for that link. **-- Keep current --** = don't touch. Greyed out if the row is locked. |
| **Also assign the link instances** | Ticked = the placed instances move too. Unticked = only the link type moves. |
| **"Showing _ of _ links"** | How many rows match your search. |
| **Assign Worksets** | Applies all rows that aren't set to **-- Keep current --**. |
| **Cancel** / window **X** | Closes without changing anything. |

---

## 5. Reading the table

### TYPE column

| Value | Meaning |
|---|---|
| **RVT** | A linked Revit model |
| **DWG** | A **linked** CAD file |
| **IMPORT** | An **imported** CAD file (not linked) |

### STATUS column

| Status | Colour | Meaning |
|---|---|---|
| **Loaded** | 🟢 Green | The link is loaded. |
| **Unloaded (this user)** | 🟡 Yellow | Unloaded for you only. |
| **In Closed Workset** | 🟡 Yellow | Its workset is closed, so it isn't loaded. |
| **Unloaded (all users)** | 🔴 Red | Unloaded for everyone. |
| **Not Found** | 🔴 Red | The file can't be found at its path. |
| **Invalid** | 🔴 Red | Revit reports the link as invalid. |
| **Imported (not linked)** | Grey | An imported CAD file. |

### CURRENT WORKSET column

Shows the type's workset. If a row is **locked**, the reason is added in brackets:
- **(owned by _name_)** — another user has it borrowed,
- **(workset is read-only)** — the workset can't be changed for this item,
- **(no workset parameter)** — this item has no workset to change.

---

## 6. Undoing

All changes from one **Assign Worksets** click are one step in Revit's Undo list:

> ↩️ **Assign Links to Worksets**

Press **Ctrl + Z** once to undo it.

> ℹ️ The tool borrows the links (checks them out) **before** making the change. Undo puts the worksets back, but the elements may stay borrowed by you until you **Synchronize with Central** (with *relinquish* on).

---

## 7. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🟢 **"Done"** — **"Elements moved: _"**, **"Already correct or read-only: _"** | The assignment ran. Types and instances are counted separately. | Sync with central. |
| 🟡 **"Done"** with **"Failed (_):"** and a list | Some items couldn't be moved (often owned by another user). Up to 15 are listed. | Ask the owner to relinquish, then run again for those rows. |
| 🟡 **"No worksets were assigned. Pick at least one link."** | Every row is on **-- Keep current --**. | Pick a workset in at least one row. |
| 🟡 **"This project is not workshared, so it has no worksets."** | The project isn't workshared. | Nothing to do. |
| 🟡 **"No user worksets were found in this project."** | No user worksets exist. | Create worksets first. |
| 🟡 **"No RVT or DWG links were found in this project."** | No links or CAD imports. | Nothing to do. |
| 🔴 A pyRevit error window | Something unexpected happened. Nothing was changed. | Screenshot it and contact the author. |

---

## 8. FAQ

**Why move the link type and not just the instance?**
The **type's** workset decides whether the link loads when that workset is closed. That's usually what you want to control.

**Should I keep "Also assign the link instances" ticked?**
Usually yes, so type and instances sit on the same workset. Untick it if you only want to change what controls loading.

**Why is a row's dropdown greyed out?**
The row is locked. The reason is shown in **CURRENT WORKSET** and when you hover over the dropdown.

**What does "Already correct or read-only" mean?**
Those items were already on the chosen workset, or couldn't be changed. They were skipped.

**Can I reset rows to "Keep current" with "Set all visible to"?**
No. That dropdown only lists worksets. Reset rows one by one, or click **Cancel** and start again.

**My DGN / other CAD link shows "DWG".**
The tool labels every linked CAD file as **DWG**. It still works the same.

**Do other users see the change right away?**
No. Only after you **Synchronize with Central**.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| Dropdown greyed out | Row locked (owned by someone, read-only) | Read the reason in **CURRENT WORKSET** | ❌ |
| Items in the **Failed** list | Instances or types borrowed by another user | Collaborate → Worksharing Display → Owners | ❌ |
| Workset I need isn't listed | Workset doesn't exist | Create it in **Collaborate → Worksets** | ❌ |
| A link isn't listed | It's a nested link | Change it in its parent link's file | ❌ |
| Link still doesn't load after closing a workset | Type moved but link status unchanged | Check Manage Links | ✅ If it persists |
| Others don't see the change | Not synced yet | Synchronize with Central | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your choices, and of the **Done** message
2. Your **Revit version** (e.g. 2025)
3. The **model name** and the **link(s)** involved
4. Whether **Also assign the link instances** was ticked
5. **What you expected**, and what actually happened
