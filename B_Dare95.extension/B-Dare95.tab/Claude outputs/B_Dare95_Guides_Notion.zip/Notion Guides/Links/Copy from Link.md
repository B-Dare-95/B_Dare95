# Copy from Link

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Links** panel → **Copy from Link** (dropdown) → **Bulk Copy from Link** / **Copy Selected from Link**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🏷️ **Versions:** Bulk Copy from Link 1.0 · Copy Selected from Link 2.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

The **Copy from Link** dropdown copies elements **from a linked model into your model**. The copies are **pinned** so they don't get moved by accident.

It has **two tools**:

| Tool | What you pick | What gets copied |
|---|---|---|
| **Bulk Copy from Link** | **One** linked element | **Every** element in that link with the **same category and the same name** (normally the same type name) |
| **Copy Selected from Link** | **One or more** linked elements (click and/or box) | **Only** the elements you picked |

> 💡 Bulk Copy = "give me all of these". Copy Selected = "give me exactly these".

📸 *[Screenshot: the Copy from Link dropdown open]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Follow the link's position | Copies are placed using the **linked model's own coordinates**. If the link was **moved, rotated, or placed by shared coordinates**, the copies **won't line up** with the link (see [Section 6](#6-important-where-the-copies-land)). |
| Keep the copies connected to the link | Copies are normal elements in your model. Later changes in the link don't update them. |
| Copy only what's in the view | **Bulk Copy** copies every match in the **whole linked model**. |
| Leave copies unpinned | Every copy is **pinned**. Unpin it to move or edit its position. |
| Check for duplicates | Running the tool twice makes two sets of copies. |

---

## 3. Before you start

- [ ] The link is **loaded** and **visible** in the active view.
- [ ] You know where the link sits: **origin to origin** is the safe case (see [Section 6](#6-important-where-the-copies-land)).
- [ ] For **Bulk Copy**: you checked how many elements share that name in the link. It can be a lot.

---

## 4. How to use — Bulk Copy from Link

1. Click the **Copy from Link** dropdown and choose **Bulk Copy from Link**.
2. The status bar says **"Select Linked Element"**.
3. Click **one** element in the link.
4. The tool copies **every element in that link** with the **same category and name** into your model, and pins them. ✅

> ⚠️ There's **no confirmation and no "done" message**. Check the result in the view, or with a schedule.

> ⚠️ "Same name" usually means the same **type name**. Elements from **different families** that happen to share a type name (e.g. `Standard`) in the same category are copied too.

---

## 5. How to use — Copy Selected from Link

1. Click the **Copy from Link** dropdown and choose **Copy Selected from Link**.
2. The status bar says **"Select Linked Elements (box-drag or ctrl-click), then click Finish"**.
3. **Click** and/or **drag a box** over the linked elements you want. You can pick from more than one link.
4. Click **Finish** on the Options Bar (top left, under the ribbon).
5. The elements are copied and pinned. A message says **"Copied _ element(s) from link."** ✅

> 💡 If you pick the same element twice, it's only copied once.

---

## 6. Important: where the copies land

Both tools place the copies at the **same coordinates the elements have inside the linked file**. They don't apply the link's placement in your model.

| How the link is placed | Result |
|---|---|
| **Origin to origin**, not moved or rotated | ✅ Copies sit exactly on top of the linked elements. |
| Placed **by shared coordinates**, or **moved / rotated** after placing | ⚠️ Copies are **offset and/or rotated** compared to the link. |

**Check after copying:** temporarily hide the link and see whether the copies are where the linked elements were. If not, undo and contact the author.

---

## 7. Undoing

Each run is **one** step in Revit's Undo list. Both tools use the same name:

> ↩️ **Bulk Copy from Link**

Press **Ctrl + Z** once to remove all copies from that run.

---

## 8. Messages you may see

| Message | Tool | Why | What to do |
|---|---|---|---|
| 🟢 **"Copied _ element(s) from link."** | Copy Selected | Copy worked. The number can be higher than what you picked if Revit copied related elements too. | Check the result. |
| 🟡 **"Please, Select a Linked Element"** | Bulk Copy | You pressed **Esc** or cancelled the pick. Nothing was copied. | Run again and click a linked element. |
| 🟡 **"Please, select at least one Linked Element"** | Copy Selected | You pressed **Esc** or cancelled. Nothing was copied. | Run again and click **Finish** when done. |
| 🟡 **"No Linked Elements were selected"** | Copy Selected | You clicked **Finish** without picking anything. | Pick at least one element. |
| 🟡 **"Could not resolve any Linked Elements from the selection"** | Copy Selected | The picks couldn't be read from the link. | Check the link is loaded. Try again. |
| 🔴 **"Copy failed:"** + details | Copy Selected | Revit refused the copy. **Nothing** was copied. | Screenshot it and contact the author. |
| 🔴 A pyRevit error window | Bulk Copy | Something unexpected happened. | Screenshot it and contact the author. |

All messages have the title **B-Dare95**.

---

## 9. FAQ

**Which one should I use?**
Use **Copy Selected** for specific elements. Use **Bulk Copy** when you want *every* element of one type from the link.

**Why are the copies pinned?**
So they don't get moved by accident. Select a copy and unpin it (**Modify → Unpin**) if you need to move it.

**The copies aren't on top of the link. Why?**
The link isn't placed origin to origin. The tools don't apply the link's position (see [Section 6](#6-important-where-the-copies-land)).

**Does Bulk Copy copy only what's visible?**
No. It copies every matching element in the whole linked model.

**Can I box-select in Bulk Copy?**
No. Bulk Copy takes one click. Use **Copy Selected** for box selection.

**Will the copies update if the link changes?**
No. They're independent elements in your model.

**Why does the Undo list say "Bulk Copy from Link" after Copy Selected?**
Both tools use the same Undo name. It's still one step per run.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the tools | B-Dare95 tab missing or dropdown closed | Click the small arrow on **Copy from Link** | ✅ If it's still missing |
| Copies offset or rotated | Link not placed origin to origin | Undo. Check the link's placement. | ✅ |
| Far more elements copied than expected (Bulk) | Many elements share that name in the link, across families | Undo. Use **Copy Selected** instead. | ❌ |
| Nothing copied, no message (Bulk) | Check the view: copies may be off-screen if the link is offset | Zoom to fit, or undo | ✅ If you can't find them |
| "Copy failed" | Revit refused the copy | Screenshot it | ✅ |
| Can't move a copy | It's pinned | Unpin it | ❌ |
| Duplicate copies | Tool run twice | Undo the second run | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which tool** you used (Bulk Copy or Copy Selected)
2. A **screenshot** of the result and of any message
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **link name**, and how the link is positioned (origin to origin, shared coordinates…)
5. **What you expected** to be copied, and what actually was
