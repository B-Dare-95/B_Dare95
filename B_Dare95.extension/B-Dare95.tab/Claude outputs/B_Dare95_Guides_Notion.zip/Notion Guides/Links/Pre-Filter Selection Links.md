# Pre-Filter Selection (Links)

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Links** panel → **Pre-Filter Selection (Links)**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🏷️ **Version:** 1.0.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Pre-Filter Selection (Links)** lets you select elements **inside linked models**, but only from the categories you choose.

You pick the categories **before** you start clicking. While you click, Revit only highlights linked elements of those categories. Everything else is ignored.

It works across **all loaded links visible in the view** at once. You don't have to choose a link first.

| Mode | How to open it | What it does |
|---|---|---|
| **Choose Categories** | **Click** the button | Only linked elements of the **ticked** categories can be picked. |
| **Exclude Categories** | **Shift + click** the button | Linked elements of **every category except** the ticked ones can be picked. |

> 💡 It's the linked-model version of **Pre-Filter Selection**. Like telling Revit "only catch fish of this kind", but in someone else's pond.

📸 *[Screenshot: the Choose Categories window with element counts]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change any model | It only **selects**. Nothing is moved, edited or deleted. |
| Support box (window) selection | Linked elements must be **clicked one by one**. Revit doesn't allow box-selecting inside links here. |
| Select elements in your own model | Only elements **inside links** can be picked. |
| Add to your current selection | The result **replaces** what was selected before. |
| Show annotation categories | Only **model** categories are listed. |
| Use hidden or unloaded links | Only **loaded** links **visible in the active view** are used. |
| Remember your choices | Each run starts with nothing ticked. |

---

## 3. Before you start

- [ ] A view with the **links visible** is **active** (plan, section, 3D…).
- [ ] The links are **loaded**.
- [ ] The elements you want are **visible** in the view.

---

## 4. How to use it — Choose Categories

1. Click **Pre-Filter Selection (Links)**.
2. The **Choose Categories** window opens. Under the title it says how many loaded links are in this view.
3. *(Optional)* Type in the **search box** to shorten the list.
4. **Tick** the categories you want. Each one shows how many elements of it exist in the links, e.g. `Pipes (1,240)`.
5. Click **Make A Selection**. It stays greyed out until at least one category is ticked.
6. The window closes. Revit's status bar says **"Pick linked elements of the chosen categories, then press Finish"**.
7. **Click** the linked elements you want. Only elements of your categories highlight.
8. Click **Finish** on the Options Bar (top left, under the ribbon).
9. The picked linked elements are now **selected**. ✅

### Window controls

| Control | What it does |
|---|---|
| **Search box** (top) | Filters the list as you type. Any part of the name, upper/lower case doesn't matter. Hover over it to see "Filter categories...". |
| **Select All** | Ticks every category **currently shown**. Combine with search. |
| **Clear** | Unticks **everything**, including categories hidden by your search. |
| **"_ selected" counter** | How many categories are ticked. |
| **Category list** | Every model category that has elements in the loaded links, with its element count. |
| **Make A Selection** | Closes the window and starts picking. |
| Window **X** | Closes without doing anything. |

---

## 5. Exclude mode (Shift + click)

Use this when it's easier to say what you **don't** want.

1. Hold **Shift** and click **Pre-Filter Selection (Links)**.
2. The **Exclude Categories** window opens.
3. Tick the categories you want to **leave out**.
4. Click **Select Everything Else**.
5. The status bar says **"Pick linked elements OUTSIDE the excluded categories, then press Finish"**.
6. Click the linked elements, then click **Finish**. ✅

---

## 6. About the list and counts

- The list is built from what **actually exists** in the loaded links. Empty categories aren't shown.
- The number next to each category counts elements in the **whole linked model**, not only what's visible in your view.
- If the same link file is placed more than once, its elements are counted **once**.
- Categories with the same name in different links are merged into one line.

---

## 7. Cancelling and undoing

| You want to… | Do this |
|---|---|
| Close the window without selecting | Click the window's **X**. Nothing happens. |
| Stop while picking | Press **Esc**. The tool ends and nothing is selected. |
| Clear the selection afterwards | Press **Esc** in the view, or click an empty spot. |
| Undo | Not needed. The tool never changes the model, so there's nothing in the Undo list. |

---

## 8. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🟡 **"No loaded Revit links are visible in the active view."** | No link is loaded, or none is visible in this view. | Load the link, or switch to a view where it's visible. |
| 🟡 **"The loaded links contain no model elements to pick."** | The visible links have no model elements. | Check you're looking at the right link. |
| 🔴 **"None of the picked references could be resolved back to linked elements."** | The picks couldn't be turned into a selection. | Try again. If it repeats, contact the author. |
| 🔴 A pyRevit error window | Something unexpected happened. | Screenshot it and contact the author. |

When everything works, there's **no message**. The linked elements are simply selected.

---

## 9. FAQ

**Can I drag a box to select?**
No. Revit doesn't support box selection of linked elements here. Click them one by one, then **Finish**.

**Does this change anything in my model?**
No. It only selects.

**Do I need to choose which link to pick from?**
No. You can pick from any loaded link visible in the view, in the same session.

**Why isn't my link's category listed?**
The link isn't visible in the active view, isn't loaded, or has no elements of that category.

**Why does the count look bigger than what I see?**
Counts cover the whole linked model, not just your view.

**What can I do with the selected linked elements?**
Whatever Revit allows for a selection of linked elements (e.g. reading their properties). The tool itself only selects them.

**I pressed Esc while picking. Where's my selection?**
Esc cancels the whole picking session. Pick again and use **Finish** instead.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| **Make A Selection** greyed out | No category ticked | Tick at least one category | ❌ |
| "No loaded Revit links are visible…" | Link unloaded or hidden in this view | Manage Links, Visibility/Graphics | ❌ |
| Elements don't highlight when hovering | Wrong category, or the element is in your own model | Check the category. Use the normal Pre-Filter Selection for your own model. | ❌ |
| Box drag doesn't work | Not supported for links | Click elements one by one | ❌ |
| Nothing selected at the end | You pressed **Esc** instead of **Finish** | Run again, then click **Finish** | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which mode** you used (Choose or Exclude / Shift + click)
2. A **screenshot** of the window with your choices, and of any error
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **view**, and the **link(s)** involved
5. **What you expected** to be selected, and what actually was
