# Clash Manager

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Clashes** panel → **Clash Manager**
> 🧩 **Works with:** Revit 2024 and newer · Navisworks **HTML** clash reports
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Clash Manager** reads a **Navisworks clash report (HTML)** and lets you walk through the clashes **inside Revit**.

For each clash you can:

| Action | Button | What happens |
|---|---|---|
| **See the details** | *(click a clash in the list)* | The two clashing elements are looked up in your model and its loaded links. The report's clash image is shown if available. |
| **Focus on the two elements** | **Focus / Isolate** | Both elements are **temporarily isolated** in the active view. |
| **Frame the clash point** | **Create Clash Box** | The active **3D view** gets a **section box** (a cube) around the clash point, and the view zooms to it. |

The window is called **Clash Navigator**. It stays open next to Revit while you work.

> 💡 Think of it as the Navisworks clash list, brought into Revit, so you can jump to each clash and fix it on the spot.

📸 *[Screenshot: the Clash Navigator window with a report loaded and a clash selected]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Run clash tests | You need a report already exported from Navisworks. |
| Read XML, Excel or PDF reports | Only **HTML** reports. |
| Change the clash status | Nothing is written back to Navisworks or to the report. |
| Show status, distance, grid location or date | The list shows test name, clash name and the two element IDs only. |
| Move or fix elements | It only isolates elements and sets a section box. You fix the model yourself. |
| Isolate a single element inside a link | If an element lives in a linked model, the **whole link** is isolated. |
| Remember the last report | Each time the window opens, you load the report again. |

---

## 3. Before you start

- [ ] The model (and the **links** the clashes come from) is **open and loaded** in Revit.
- [ ] You have a Navisworks clash report exported as **HTML**.
- [ ] The report includes the **Element ID** of each item. Without it, the tool can't find the elements.
- [ ] The report's clash-point coordinates are in **meters** (the tool reads them as meters).
- [ ] If the report has images, keep the **image folder next to the HTML file**, as Navisworks exported it.
- [ ] For **Create Clash Box**: a **3D view** is active and **not locked**.

---

## 4. How to use it

1. Click **Clash Manager**. The **Clash Navigator** window opens.
2. Click **Load HTML Report...** and choose the report file.
3. Wait while it reads. The status line at the bottom shows **"Parsing … — _ clashes so far..."**. Big reports can take a while.
4. When done, the status line shows **"Loaded _ clashes from _ test(s); _ have clash points."** The list fills up.
5. *(Optional)* Type in the box above the list to filter clashes.
6. Click a clash. On the right you see:
   - the clash **image** (if the report has one),
   - **Item 1** and **Item 2**: category and name of each element, and which link it's in,
   - the **Clash point** coordinates.
7. Click **Focus / Isolate** to isolate both elements in the active view.
8. Or switch to a **3D view**, set the **Clash Box Size (m)**, and click **Create Clash Box**.
9. Fix the clash in Revit. The window stays open. Pick the next clash when ready.

> 💡 Each list line reads: **[Test name] Clash name (Item 1 ID vs Item 2 ID)**.

### Window controls

| Control | What it does |
|---|---|
| **Load HTML Report...** | Opens a file picker for the Navisworks HTML report. The file name then appears next to the button. |
| **Filter box** (above the list) | Shows only clashes whose line contains what you type (test name, clash name or element ID). Upper/lower case doesn't matter. |
| **Clash list** | All individual clashes from all tests in the report. |
| **Image** (top right) | The clash image from the report, if found. |
| **Item 1 / Item 2** | Category and name of each element. **[in link: …]** means it's inside a linked model. |
| **Clash point** | The X, Y, Z from the report, or **"none in report"**. |
| **Focus / Isolate** | Temporarily isolates both elements. Greyed out until **both** elements are found. Hover over it to see why it's greyed out. |
| **Clash Box Size (m)** | Size of the section-box cube in **meters**. Default **3.0**. |
| **Create Clash Box** | Sets a section box around the clash point in the active 3D view and zooms to it. |
| **Status line** (bottom) | Progress and results. |

---

## 5. How elements are found

- The tool takes the **Element ID** of each item from the report.
- It looks in **your model first**, then in every **loaded link**.
- If the same ID number exists in your model **and** a link, your model wins.
- If an item isn't found, it shows **"(not found in host or any loaded link)"**, and **Focus / Isolate** stays greyed out.

> ⚠️ If the clashing element is in a link that isn't loaded, it can't be found. Load the link first, then click the clash again.

---

## 6. About the clash box and coordinates

- Navisworks usually writes clash points in **shared (survey) coordinates**.
- The first time you click **Create Clash Box** after opening the window, the tool works out how the report's coordinates relate to your model. It does this by checking which conversion puts the point **on top of the two clashing elements**.
- For this to work, **at least one element of that first clash must be found** in your model or links.
- The result is reused for the rest of the window session. The status line then shows e.g. **"Section box set (coordinate mode: …)."**

> 💡 Tip: for your first clash box, pick a clash where both items show a name (not "not found").

---

## 7. Undoing and resetting

| You want to… | Do this |
|---|---|
| Show everything again after **Focus / Isolate** | Use Revit's **Temporary Hide/Isolate** (sunglasses icon in the view control bar) → **Reset Temporary Hide/Isolate**. |
| Remove the clash box | Untick **Section Box** in the 3D view's Properties, or undo it. |
| Undo with Ctrl + Z | Each click is one Undo step: **Clash Navigator - Focus** or **Clash Navigator - Clash Box**. |
| Close the tool | Click the window's **X**. Your report isn't saved. Load it again next time. |

> ℹ️ The tool never changes your **elements**. Focus changes what's visible in the view temporarily. Clash Box changes the **section box of the active 3D view**.

---

## 8. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🔵 **"Reading …"** / **"Parsing … — _ clashes so far..."** | The report is being read. | Wait. |
| 🟢 **"Loaded _ clashes from _ test(s); _ have clash points."** | Report loaded. | Pick a clash. |
| 🟢 **"Isolated the clashing elements."** | Focus worked. | — |
| 🟢 **"Section box set."** | Clash box worked. | — |
| 🟡 **"No clashes were found in this report."** | The file isn't a Navisworks clash report, or it has no clash rows. | Check you picked the right HTML file. |
| 🟡 **"Select a clash first."** | No clash selected. | Click a clash in the list. |
| 🟡 **"Clash box size must be a number."** / **"…must be greater than zero."** | The size box has text or 0. | Type a number like `3` or `5`. |
| 🟡 **"Switch to a 3D view first -- Clash Box sets that view's section box."** | Active view isn't 3D. | Open a 3D view and try again. |
| 🟡 **"The active 3D view is locked; unlock it to set a section box."** | The 3D view is locked. | Unlock it, or use another 3D view. |
| 🟡 **"The active view doesn't support temporary isolate. Switch to a plan, section or 3D view."** | E.g. a sheet or schedule is active. | Switch views. |
| 🟡 **"This clash has no clash-point coordinates in the report."** | The report has no clash point for this clash. | Use **Focus / Isolate** instead. |
| 🟡 **"Neither Item 1 nor Item 2 could be resolved in the host model or any loaded link."** | Both IDs not found. | Load the right links. Check the report is from this model. |
| 🟡 **"No active Revit document. Open a project and try again."** | No project is open. | Open the project. |
| 🔴 **"Can't work out which coordinate system this report uses…"** | Neither element of this clash was found, so the tool can't check the coordinates. | Pick a clash where the items are found, and try **Create Clash Box** again. |
| 🔴 **"None of the coordinate conversions put this clash point anywhere near the elements…"** | The report's units or coordinates don't match, or the elements were moved since the clash test. | Contact the author. |
| 🔴 **"The clash point converts to a location about _ m from this model's internal origin…"** | The coordinates or units don't match this model. | Contact the author. |
| 🔴 **"Clash Navigator ran into an error: …"** | Something unexpected happened. | Screenshot it and contact the author. |

> ℹ️ Some red messages mention settings "at the top of the script". **Don't change anything yourself** — send the message to the author.

---

## 9. FAQ

**Can I keep working in Revit while the window is open?**
Yes. The window floats over Revit. If you're in the middle of a command, the tool waits until you finish it, then runs the action.

**I clicked the button again and nothing new opened.**
Normal. If the window is already open, it's brought to the front instead of opening a second one.

**Why is Focus / Isolate greyed out?**
At least one of the two elements wasn't found. Hover over the button to see which. Load the missing link.

**Why did the whole linked model get isolated?**
Revit can't isolate one element inside a link. The tool isolates the link that contains it.

**Why is there no image?**
The report has no image for that clash, or the image folder isn't next to the HTML file any more.

**Which report units are supported?**
Clash points are read as **meters**. Export your report in meters.

**Can I see the clash status (New / Active / Approved)?**
Not in this tool. Use the report or Navisworks for that.

**Does the clash box size use meters even if my project is in mm?**
Yes. **Clash Box Size (m)** is always in meters.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| Loading takes very long | Very large report (many columns) | Wait. Watch the status line. Export fewer properties next time. | ✅ If Revit freezes |
| "No clashes were found" | Wrong file, or not a Navisworks clash report | Open the HTML in a browser to check | ✅ If it's a real clash report |
| Items show "not found" | Link not loaded, report from another model version, or no Element ID in the report | Load links. Check the report has Element IDs. | ✅ If links are loaded and IDs exist |
| Wrong element shown | Same ID number exists in your model and a link | Check the item category/name against the report | ✅ |
| Clash box in the wrong place or not created | Units or coordinates don't match | Check the report is in meters | ✅ |
| Create Clash Box does nothing | Active view isn't 3D, or it's locked | Switch to an unlocked 3D view | ❌ |
| View still isolated | Temporary isolate is still on | **Reset Temporary Hide/Isolate** | ❌ |
| Red error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the Clash Navigator window and of any message
2. The **report file** (HTML plus its image folder), or tell us where it's saved
3. The **clash name** and **test name** you were on
4. Your **Revit version** (e.g. 2025) and the **model name**
5. Which **links** were loaded, and **what you expected** to happen
