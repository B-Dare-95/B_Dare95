# Magic 3D Box

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Inspection** panel → **Magic 3D Box**
> 🧩 **Works with:** Revit 2024 and newer · start from a **plan**, **section** or **elevation** view
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Magic 3D Box** turns a rectangle you drag in a plan, section or elevation into a **3D view cropped to exactly that area**.

1. You drag a rectangle around the zone you want to look at.
2. The tool sets the **section box** of a 3D view to match it.
3. The 3D view opens, zoomed to the box. ✅

The tool **reuses the same 3D view** every time (by default called **Magic 3D Box**), so your project doesn't fill up with throwaway 3D views.

> 💡 Think of it as cutting a slice out of the model with a cookie cutter and holding it up in 3D.

📸 *[Screenshot: a rectangle dragged in a plan, and the resulting 3D view]*

### How tall / deep is the box?

| You start in… | Width and length | Height / depth |
|---|---|---|
| **Plan view** | Your rectangle | From the **bottom of the view range** (about 150 mm lower) up to the **cut plane** of the plan |
| **Section / elevation** | Your rectangle (width and height) | Depth = the view's **far clip offset**. If that's very small, about **6 m** is used. |

> ⚠️ **In plans, the box stops at the cut plane**, not at the top of the view range. Things above the cut plane (e.g. ceiling-level services) are outside the box. Start from a section if you need them.

Each side of the box is at least about **150 mm**. If the plan's view range can't be read, the box goes from about 150 mm below the level to about 3 m above it.

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Make a new 3D view every time | It reuses the 3D view with the saved name. The previous box is **replaced**. |
| Work from 3D views, sheets, schedules or drafting views | Start from a plan, section or elevation. |
| Follow your view's crop or visibility | Only the **phase** is copied from your view. Graphics come from the chosen **view template** (or the 3D view's own settings). |
| Keep the crop box on | The 3D view's crop box is switched **off** (unless a template locks it). |
| Share settings with colleagues | Settings are saved **on your computer**, per project. |

---

## 3. Before you start

- [ ] A **plan**, **section** or **elevation** view is active.
- [ ] *(Optional)* You have a **3D view template** you'd like to use for the result.
- [ ] If the box should include things above the plan's cut plane, start from a section instead.

---

## 4. How to use it

1. Open a plan, section or elevation view.
2. Click **Magic 3D Box**.
3. **First time in this project only:** the **Magic 3D Box - Settings** window opens. Choose a view template and a view name, then click **Run** (see [Section 5](#5-settings-window)).
4. The status bar says **"Drag a rectangle around the zone (hold the left mouse button)"**.
5. **Hold the left mouse button and drag** a rectangle around the zone.
6. The 3D view opens with the section box set. The section box is selected and the view zooms to it. ✅

> 💡 Press **Esc** while dragging to cancel. Nothing happens.

> 💡 Next time, the tool skips the settings window and goes straight to step 4.

---

## 5. Settings window

The **Magic 3D Box - Settings** window opens:

- the **first time** you use the tool in a project,
- when the saved **view template no longer exists**,
- when you **Shift + click** the button (to change settings).

| Control | What it does |
|---|---|
| **View template** search box | Filters the template list as you type |
| **Template list** | All **3D view templates** in the project. **<None>** (always at the top) means no template. |
| **3D view name** | Name of the 3D view to reuse. Default: **Magic 3D Box**. If left blank, the default is used. |
| **Run** | Saves the settings and continues to the rectangle |
| **Cancel** | Stops the tool. Nothing is saved or changed. |

📸 *[Screenshot: the Magic 3D Box - Settings window]*

### Good to know

- The template is **applied every run**. Choosing **<None>** **removes** any template from the 3D view each run.
- If you change the **view name**, a **new** 3D view with that name is made next time. The old one stays in the project.
- If the name is already used by a different kind of view, the tool adds a number to the end of the name.
- Settings are saved per project, on your computer only.

---

## 6. What happens to the model

All changes happen in **one step** named **Magic 3D Box** in the Undo list:

| Change | When |
|---|---|
| A new 3D view is created and named | Only if no 3D view with the saved name exists yet |
| The chosen view template is applied (or removed for **<None>**) | Every run |
| Crop box switched off | Every run, unless the template controls it |
| Phase set to match the view you started from | Every run, unless the template controls it |
| Section box set and switched on | Every run |

---

## 7. Undoing

| You want to… | Do this |
|---|---|
| Undo the last run | Press **Ctrl + Z** once. The Undo list entry is **Magic 3D Box**. |
| Change the template or view name | **Shift + click** the button |
| Get rid of the 3D view | Delete it in the **Project Browser** like any view |

---

## 8. Messages you may see

All messages have the title **Magic 3D Box**.

🟡 **"Run this tool from a plan, section or elevation view."**
- **Why:** The active view is a 3D view, sheet, schedule, drafting view, etc.
- **What to do:** Open a plan, section or elevation and try again.

🟡 **"Hold the left mouse button down while dragging the rectangle. Try again?"**
- **Why:** The rectangle was tiny, usually a click instead of a drag.
- **What to do:** **Yes** to drag again, **No** to stop.

🟡 **"The section box was set but is switched off in '*template*'. That view template controls Section Box. Uncheck it in the template, or pick a different template with Shift-click."**
- **Why:** The chosen template forces the section box off.
- **What to do:** Edit the template so it doesn't control **Section Box**, or **Shift + click** and choose another template.

🔴 **"This project has no 3D view family type."**
- **Why:** The project has no 3D view type to make the view from.
- **What to do:** Contact the author or your BIM manager.

🔴 **"Could not apply the section box."** (with technical details)
- **Why:** Something failed while setting up the 3D view. Nothing was changed.
- **What to do:** Screenshot it and contact the author.

🔴 **"Magic 3D Box failed."** (with technical details)
- **Why:** Something unexpected happened.
- **What to do:** Screenshot it and contact the author.

---

## 9. FAQ

**Does it make a new 3D view every time?**
No. It reuses the 3D view with the saved name, and only creates it if it doesn't exist.

**Can I keep several boxes?**
**Duplicate** the **Magic 3D Box** view to keep a copy of the current box, or **rename** it. After a rename, the next run makes a fresh view with the saved name.

**Why are things above the ceiling missing when I start from a plan?**
In plans the box goes up to the **cut plane** only. Start from a section to include them.

**Does it work in rotated plans or sections?**
Yes. The box follows the direction of the view you dragged in.

**Does it work in reflected ceiling plans?**
It accepts any plan-type view. The box is built from that view's range in the same way.

**My colleague gets the settings window, but I don't.**
Settings are stored per person, per computer and per project.

**How do I change the template later?**
**Shift + click** the button.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| "Run this tool from a plan, section or elevation view" | Wrong view type active | Open a plan, section or elevation | ❌ |
| Box is too low in plan | The box stops at the cut plane | Start from a section, or raise the plan's cut plane | ❌ |
| Section box is off in the 3D view | Template controls Section Box | Edit the template, or **Shift + click** and pick another | ❌ |
| 3D view looks different each run | Template is re-applied every run | Change the template, or choose **<None>** | ❌ |
| My own changes to the 3D view were lost | Template re-applied, or **<None>** removed my template | Pick the template you want in settings | ❌ |
| A second "Magic 3D Box …" view appeared | You renamed the old one, or changed the view name | Delete views you don't need | ❌ |
| Settings window opens again | The saved template was deleted | Pick a template again and click **Run** | ✅ If it keeps happening |
| Red error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. The **view** you started from (plan, section or elevation) and its name
2. A **screenshot** of the rectangle you dragged and of the resulting 3D view, plus any error
3. The **template** and **view name** in the settings window
4. Your **Revit version** (e.g. 2025) and the **model name**
5. **What you expected** to see, and what actually happened
