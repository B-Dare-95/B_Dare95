# Highlight MEP

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Inspection** panel → **Highlight MEP** (small stacked button)
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🏷️ **Version:** 1.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Highlight MEP** makes the **MEP** in the active view stand out by turning the **building around it almost invisible**.

It's an **on/off button**. Its icon changes to show the state:

| Click | What happens in the **active view** |
|---|---|
| **ON** | Visual style → **Shaded**. Walls, floors, doors, structure etc. become **95% transparent**. **Lines** are hidden. Ducts, pipes, cable trays, equipment and fixtures stay as they are. |
| **OFF** | Visual style → **Shaded with Edges**. **All** category overrides in the view are cleared. |

> 💡 Think of it as an **X-ray** of the building: the shell fades away and the services are left in plain sight.

📸 *[Screenshot: a 3D view before and after Highlight MEP is turned on]*

### What gets faded

Every category whose name contains one of these words:

> Walls · Columns · Floors · Ceilings · Doors · Windows · Roofs · Stairs · Railing · Ramps · Curtain · Structural · Casework · Furniture · Specialty Equipment · Generic Models · Parts · Parking · Planting · Entourage · Roads · Site · Topography

So, for example, **Structural Framing**, **Structural Foundations**, **Curtain Panels** and **Furniture Systems** fade too.

Everything else (Ducts, Pipes, Cable Trays, Conduits, fittings, accessories, Mechanical/Electrical Equipment, Plumbing and Lighting Fixtures, Sprinklers, Air Terminals…) keeps its normal look.

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change model elements | It only changes **view settings** (visual style and Visibility/Graphics overrides) of the active view. |
| Work on all views at once | Only the **active view** is changed. |
| Remember each view's state | The on/off state is **one switch for you**, not per view. See [Section 5](#5-the-onoff-state). |
| Restore your original view settings | **OFF** sets **Shaded with Edges** and clears **all** category overrides, including ones you set yourself. |
| Turn Lines back on | **OFF** does **not** show the **Lines** category again. Turn it back on in **Visibility/Graphics** if you need it. |
| Hide elements | Faded elements are still there and still selectable. They are just 95% transparent. |

---

## 3. Before you start

- [ ] The view you want to change is **active** (a 3D view works best).
- [ ] The view **isn't controlled by a view template** that locks Visibility/Graphics or the visual style.
- [ ] ⚠️ The view **has no category overrides you want to keep**. Turning the highlight **OFF** clears all of them. Use a **duplicate view** if you're not sure.

---

## 4. How to use it

1. Open the view you want, e.g. a 3D view.
2. Click **Highlight MEP**. Check the icon:
   - **ON icon** → the building fades and the MEP stands out. ✅
   - **OFF icon** → the view was reset instead (see the tip below). Click again to turn it on.
3. Review the MEP.
4. Click **Highlight MEP** again to turn it **OFF**. The view goes to **Shaded with Edges** and the overrides are cleared.

> 💡 **The very first time you use the button, the first click is an OFF click.** Nothing seems to highlight; the view is only reset. Click once more and it turns ON. From then on it alternates ON / OFF.

---

## 5. The on/off state

- The button remembers **one** on/off state **for you**, across all views and models, and even after restarting Revit.
- Each click **flips** that state and applies it to **whatever view is active right now**.

> ⚠️ **Example:** You turn it ON in *3D – Mechanical*, then switch to *3D – Plumbing* and click again. The state flips to **OFF**, so *3D – Plumbing* gets **reset** (its overrides are cleared), and *3D – Mechanical* **stays faded**.
> To turn off the first view, go back to it and click twice (ON, then OFF).

---

## 6. Undoing

Each click creates entries in Revit's **Undo** list (**Ctrl + Z**):

| Click | Undo entries (newest first) |
|---|---|
| **ON** | **MEP Highlight** |
| **OFF** | **Reset MEP Highlight**, then **MEP Highlight** |

- To undo an **OFF** click completely, press **Ctrl + Z** **twice**.
- Undo is the only way to get back overrides that **OFF** cleared.

> ⚠️ Undo doesn't move the button's on/off state back. After undoing, the next click may do the opposite of what you expect. Check the icon after each click.

---

## 7. Messages you may see

The tool shows **no messages** when it works. Here's what to expect:

| Moment | What you see |
|---|---|
| After an **ON** click | The building fades, the button shows the **ON** icon |
| After an **OFF** click | Shaded with Edges, normal colours, the button shows the **OFF** icon |
| 🔴 A pyRevit error window | Something blocked the change, most often a **view template** or a view type that can't be shaded (sheet, schedule, legend…). Screenshot it and see [Troubleshooting](#9-troubleshooting). |

---

## 8. FAQ

**Does this change my model?**
No elements are changed. Only the active view's display settings.

**Why didn't anything highlight on my first click?**
The first click ever is an OFF click. Click again.

**Why did my custom pipe colours disappear?**
Turning OFF clears **all** category overrides in the view, including MEP ones you set yourself. Press **Ctrl + Z** twice to get them back, or set them again.

**My model lines / detail lines disappeared.**
The tool hides the **Lines** category and doesn't show it again when turned OFF. Turn **Lines** back on in **Visibility/Graphics**.

**Can I use it in a plan or section?**
It changes the visual style and the overrides of any view that allows it. It's most useful in **3D views**.

**Some architectural elements still look solid.**
Only categories whose names contain the words in [Section 1](#what-gets-faded) are faded. Other categories (e.g. Rooms, Mass, Mechanical Equipment) keep their look.

**Does it work in my linked architectural model?**
Linked models aren't specifically handled. Check the result in your view.

**Does it change my view template?**
No. If the view uses a template that controls these settings, the tool can't change the view.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Look on the **Inspection** panel (stacked buttons). | ✅ If it's still missing |
| First click only resets the view | First click is always OFF | Click again | ❌ |
| Button does the opposite of what I expected | State is shared across views, or you used Undo | Check the icon, click again | ❌ |
| My V/G overrides are gone | OFF clears all category overrides | **Ctrl + Z** twice, or reapply them | ❌ |
| Lines are missing | Lines hidden by the ON click | Visibility/Graphics → **Lines** → tick it | ❌ |
| Nothing fades, or the walls stay solid | Revit is in a language other than English, so category names don't match | Check your Revit language | ✅ |
| Red pyRevit error window | View template locks V/G or visual style, or the view can't be shaded | Remove the template from the view, or use a duplicate view | ✅ If it still fails |
| Anything else unexpected | — | Undo, then try again in a 3D view | ✅ If it repeats |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the view and of the **Highlight MEP** icon (ON or OFF)
2. A **screenshot** of any error
3. Your **Revit version** (e.g. 2025) and **Revit language**
4. The **view name** and **view type** (3D, plan…), and whether it uses a **view template**
5. **What you expected**, and what happened instead
