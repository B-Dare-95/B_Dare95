# MEP Filters

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Inspection** panel → **MEP Filters**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**MEP Filters** colours your MEP services in the **current view** so you can check them by eye. It creates Revit **view filters** (or reuses ones that already exist) and adds them to the active view, each with its own colour.

You set everything up in one window, split into four sections:

| Section | What it colours | How it decides what matches |
|---|---|---|
| **HVAC** | Duct systems, ducts, flex ducts, duct fittings, duct accessories, air terminals | **System Classification** contains the value you pick |
| **Plumbing** | Piping systems, pipes, flex pipes, pipe fittings, pipe accessories | **System Classification** contains the value you pick |
| **Fire Protection** | Same pipe categories as Plumbing | **System Classification** contains the value you pick |
| **Electrical** | Cable trays, cable tray fittings, conduits, conduit fittings | **Type Name** contains the text you type |

Each section starts with ready-made rows:

| Section | Default filters (name → value) |
|---|---|
| HVAC | COORD_SUPPLY DUCTS → Supply Air · COORD_RETURN DUCTS → Return Air · COORD_EXHAUST DUCTS → Exhaust Air |
| Plumbing | COORD_COLD WATER PIPES → Domestic Cold Water · COORD_HOT WATER PIPES → Domestic Hot Water · COORD_SUPPLY CHILLED WATER → Hydronic Supply · COORD_RETURN CHILLED WATER → Hydronic Return · COORD_DRAINAGE → Sanitary |
| Fire Protection | COORD_FIRE PIPES → Fire Protection Wet · COORD_NOVEC PIPES → Fire Protection Other |
| Electrical | COORD_ELECTRIC TRAYS → `_E_` · COORD_ICT TRAYS → `_T_` |

> 💡 Think of it as a set of coloured highlighter pens, one per system. You pick the pens once, and the tool paints the view.

📸 *[Screenshot: the MEP Filters Configuration window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on several views at once | Filters are added to the **active view only**. Run it again in each view you need. |
| Update a filter that already exists | If a filter with the same name exists, the tool **reuses it as it is**. A new value in the dropdown does **not** change that filter's rule (see [Section 6](#6-how-existing-filters-are-handled)). |
| Change colours of a filter already in the view | If the filter is already applied to the view, it's **skipped**. Its colour stays the same. |
| Remember your choices | Each run starts again from the default rows and colours. |
| Read classifications from your own model | The dropdown list comes from **loaded Revit links** only. |
| Delete or remove filters | It only creates and adds them. Remove filters the normal Revit way (Visibility/Graphics → Filters). |

---

## 3. Before you start

- [ ] The view you want to colour is **open and active**.
- [ ] The MEP models are **loaded** as Revit links, so the System Classification list is filled from them.
- [ ] You know which filter names already exist in the project, if you want new colours or rules (use new names for those).

---

## 4. How to use it

1. Open the view you want to colour.
2. Click **MEP Filters**.
3. The **MEP Filters Configuration** window opens, titled **MEP FILTER CONFIGURATION**.
4. In each section, check every row:
   - **Filter Name**: the name the filter gets in Revit.
   - **System Classification** (HVAC, Plumbing, Fire Protection): pick a value from the dropdown.
   - **Match Text** (Electrical): type the text the cable tray / conduit **Type Name** must contain.
   - **Color**: click the colour box to choose a colour.
5. Remove rows you don't need with **×**. Add rows with **+** at the bottom of a section.
6. Click **Apply Filters**.
7. The window closes, the filters are added to the view, and the pyRevit output window lists what happened to each one. ✅

> ⚠️ **Check every dropdown before you click Apply.** If a default value (e.g. *Supply Air*) isn't found in your links, the dropdown silently shows the **first value in the list** instead. The filter name and the value may then not match.

📸 *[Screenshot: one section with the +, × and colour buttons marked]*

### Window controls

| Control | What it does |
|---|---|
| **Filter Name** box | The filter's name in Revit. It can't be empty. |
| **System Classification** dropdown | Values found in the Duct Systems and Piping Systems of all loaded links. The same list is used in HVAC, Plumbing and Fire Protection. |
| **Match Text** box (Electrical) | Text that the **Type Name** must contain, e.g. `_E_`. It can't be empty. |
| **Color** box | Opens the Windows colour picker. The box shows the chosen colour. |
| **×** | Deletes that row. |
| **+** | Adds a new row named **COORD_NEW FILTER** with a grey colour. |
| **Apply Filters** | Checks the rows, then creates / applies all filters. |
| **Cancel** or window **X** | Closes the window. Nothing is changed. |

The window can be resized and scrolls when the list is long.

---

## 5. What the colours look like

Each filter gives matching elements in the view:

- A **solid fill** in the chosen colour on their surfaces.
- **Projection lines** in the chosen colour, at line weight **1**.

Cut patterns and cut lines are not changed.

---

## 6. How existing filters are handled

The tool looks for a filter with **exactly the same name** in the project:

| Situation | What happens | Output message |
|---|---|---|
| No filter with that name | A new filter is created with your categories, value and colour, and added to the view | **Created new filter:** *name* |
| Filter exists, but not in this view | The existing filter is added to the view with **your chosen colour**. Its rule and categories stay as they were. | **Applied existing filter:** *name* |
| Filter exists and is already in this view | Nothing is changed for that filter | **Skipped (already applied):** *name* |

> 💡 Want a different rule or colour for a filter that already exists? Give the row a **new name**, or change the old filter in Revit's **Filters** dialog.

> ⚠️ Give each row a **unique name**. If two rows share a name, only the first one is created. The second is reported as skipped.

---

## 7. Undoing

All filters from one run are created in one step.

| You want to… | Do this |
|---|---|
| Undo the whole run | Press **Ctrl + Z** once. The Undo list entry is **MEP Filters**. |
| Remove one filter from the view | **Visibility/Graphics** → **Filters** tab → select the filter → **Remove** |
| Delete a filter from the project | **Manage** → **Filters**, then delete it there |

---

## 8. Messages you may see

🔵 **⚠ No loaded Revit links found – showing default classification values.** (yellow strip under the HVAC header)
- **Why:** No loaded links were found, or the links have no duct/piping systems with a classification.
- **What to do:** The dropdown only offers the nine default values. Load the MEP links and run the tool again if you need other values.

🟡 **Filter name in '*Section*' row *N* cannot be empty.** (title: *Validation*)
- **Why:** A Filter Name box is blank.
- **What to do:** Type a name, or delete the row with **×**.

🟡 **Match text for 'Electrical' row *N* cannot be empty.** (title: *Validation*)
- **Why:** An Electrical row has no match text.
- **What to do:** Type the text the Type Name must contain, or delete the row.

🟡 **Please select a System Classification for '*Section*' row *N*.** (title: *Validation*)
- **Why:** A row has no classification chosen.
- **What to do:** Pick a value from the dropdown.

🟢 **Created new filter / Applied existing filter / Skipped (already applied)** (pyRevit output window)
- **Why:** One line per filter, after the run. See [Section 6](#6-how-existing-filters-are-handled).
- **What to do:** Nothing. Check the list if a colour didn't appear.

🔴 **A pyRevit error window**
- **Why:** Something unexpected happened while creating or applying the filters.
- **What to do:** Screenshot it and contact the author.

---

## 9. FAQ

**Does this change my model?**
Yes. It creates view filters in the project and adds them to the active view. Your elements themselves are not changed.

**Why is the value I need missing from the dropdown?**
The list is built from the **loaded links** only. Unloaded links and your own model are not read. Load the link and run again.

**What does "contains" mean here?**
The element matches when its System Classification (or Type Name, for Electrical) **includes** your text somewhere. For example, `_E_` matches a tray type called `CT_E_300`.

**Can I use different colours than the defaults?**
Yes. Click the colour box on any row before you click **Apply Filters**.

**I changed a colour, but the view didn't change.**
The filter was probably already in the view, so it was skipped. Check the output window for **Skipped (already applied)**. Change the colour in Visibility/Graphics, or remove the filter from the view and run the tool again.

**Will my rows be there next time?**
No. Each run starts with the default rows.

**Do the colours also show on linked elements?**
The tool only adds normal view filters. Whether linked elements pick them up depends on the link's display settings in that view.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| Yellow "No loaded Revit links found" strip | Links not loaded, or no MEP systems in them | **Manage Links**: are the MEP links loaded? | ❌ |
| Filter name and value don't match | Default value not in the links, so the first list value was used | Check each dropdown before **Apply Filters** | ❌ |
| Nothing is coloured | No matching elements, wrong value, or link display settings | Check the output window. Check the element's System Classification / Type Name. | ❌ |
| New colour or value ignored | A filter with that name already existed | Look for **Skipped** or **Applied existing filter** in the output. Use a new name. | ❌ |
| Only one of two rows created | Both rows had the same name | Give each row a unique name | ❌ |
| Red pyRevit error window | Unexpected problem (e.g. a view type or view template that doesn't accept filters) | Try a normal plan or 3D view without a template | ✅ |
| Anything else unexpected | — | Close the window and try again | ✅ If it repeats |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the MEP Filters window with your rows
2. A screenshot of the **pyRevit output window** after the run, and of any error
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **view** you were in (and its view template, if any)
5. **What you expected** to be coloured, and what actually was
