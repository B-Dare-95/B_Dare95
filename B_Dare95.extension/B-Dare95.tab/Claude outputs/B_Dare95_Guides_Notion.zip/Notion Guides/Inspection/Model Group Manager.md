# Model Group Manager

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Inspection** panel → **Model Group Manager**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Model Group Manager** lists **every model group type** in your model in one window, with who created it, how many copies are placed and what's inside. It also has two **clean-up** buttons:

| Action | What it does |
|---|---|
| **Ungroup single-instance groups** | Ungroups every model group that is placed **only once**. Optionally deletes the leftover group type. |
| **Delete empty groups** | Deletes every model group type that has **no elements** inside, or is **not placed** anywhere. |

> 💡 Think of it as a stock-take of your groups: see what's there, then clear out the ones that aren't really needed.

📸 *[Screenshot: the Model Group Manager window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Handle detail groups | Only **model groups** are listed. |
| Look inside linked models | Only groups in the model you're working in. |
| Let you pick which groups to clean up | Each button acts on **all** groups that qualify (the count is on the button). You can only confirm or cancel the whole batch. |
| Ungroup nested groups | A single-instance group that sits **inside another group** is left alone. |
| Show contents of unplaced groups | Revit only shows what's inside a group through a placed copy. |
| Edit group contents | It doesn't add, move or change elements inside groups. |

---

## 3. Before you start

- [ ] The model is **open and active**.
- [ ] In a workshared model, **sync** first, so the "Created By" / "Last Changed By" names are up to date and you can edit the groups.
- [ ] Before a clean-up, check the confirmation list carefully. Each button acts on all groups that qualify.

---

## 4. How to use it

### Browse your groups

1. Click **Model Group Manager**.
2. The **Model Group Manager** window opens. The line under the title shows the model name, the number of group types, the number of placed instances, and **workshared: yes/no**.
3. *(Optional)* Type in the **search box** to find groups by name, creator, last changed by or status.
4. Click a group in the list. The **CONTENTS** panel on the right shows what's inside it.

### Ungroup single-instance groups

1. Choose **Purge leftover type after ungroup** (on = yellow, which is the default).
2. Click **Ungroup single-instance groups (N)**.
3. A confirmation lists up to 15 group names. Click **Yes** to go ahead (**No** is the default).
4. A summary appears: **Ungroup complete**. The list refreshes. ✅

### Delete empty groups

1. Click **Delete empty groups (N)**.
2. A confirmation lists the groups with their status. Click **Yes** to go ahead.
3. A summary appears: **Delete complete**. The list refreshes. ✅

> ⚠️ **"Delete empty groups" also deletes unplaced group types.** These are group types with no copy placed in the model. Their contents can't be checked, so make sure you don't need them before you click **Yes**.

📸 *[Screenshot: the confirmation dialog]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** | Filters the list by group name, Created By, Last Changed By or Status |
| **Group list** | One row per model group type, sorted by name |
| **CONTENTS** panel | Elements inside the selected group, with level(s) |
| **Ungroup single-instance groups (N)** | Ungroups all qualifying groups. Greyed out when N = 0. |
| **Delete empty groups (N)** | Deletes all qualifying group types. Greyed out when N = 0. |
| **Purge leftover type after ungroup** | On (yellow): after ungrouping, the now-unused group type is deleted too. Off: the type stays in the project. |
| **Copy report** | Copies a text report of **all** groups to the clipboard |
| **Refresh** | Reads the model again |
| **Close** | Closes the window |

---

## 5. Reading the list

### Group list columns

| Column | Meaning |
|---|---|
| **Group Name** | Name of the group type |
| **Created By** | Who created it (workshared models only; otherwise **N/A - not workshared**) |
| **Last Changed By** | Who last changed it (workshared models only; otherwise **N/A**) |
| **Inst.** | How many copies are placed |
| **Elements** | Number of elements inside (from the first placed copy). **-** if unplaced. |
| **Types** | Number of different category + family/type combinations inside. **-** if unplaced. |
| **Status** | See below |

### Status values

| Status | Meaning | Which button acts on it |
|---|---|---|
| **OK** | Placed two or more times | None |
| **Single instance** | Placed once | **Ungroup single-instance groups** |
| **Single instance (nested)** | Placed once, inside another group | None |
| **Unplaced** | Exists in the project but isn't placed | **Delete empty groups** |
| **Empty (0 elements)** | Placed, but has no elements inside | **Delete empty groups** |

### CONTENTS panel

| Column | Meaning |
|---|---|
| **Qty** | How many of this item are in the group |
| **Category** | Element category (e.g. Walls, Doors) |
| **Family: Type** | Family and type name |

The header above shows the group name, element and type counts, and **Levels** of the placed copies.

---

## 6. What happens to the model

| Action | Model change | Undo entry |
|---|---|---|
| Browsing, search, Copy report, Refresh | None | — |
| **Ungroup single-instance groups** | The group is ungrouped; its elements stay where they are. A **pinned** group is unpinned first. With **Purge** on, the group type is deleted. | **Ungroup single-instance model groups** |
| **Delete empty groups** | The group type is deleted (with any placed empty copies) | **Delete empty model groups** |

---

## 7. Undoing

Each clean-up button is **one** step in the Undo list.

1. **Close** the Model Group Manager window.
2. Press **Ctrl + Z** in Revit, or pick the entry from the Undo list:
   - **Ungroup single-instance model groups**
   - **Delete empty model groups**

---

## 8. Messages you may see

🟡 **Ungroup single-instance groups** — "Ungroup *N* model group(s) with exactly one instance?"
- **Why:** Confirmation before ungrouping. Up to 15 names are listed, then "... and *N* more".
- **What to do:** Check the list. **Yes** to go ahead, **No** to cancel.

🟡 **Delete empty groups** — "Delete *N* model group type(s) that contain no elements?"
- **Why:** Confirmation before deleting. Each name shows its status.
- **What to do:** Check for **[Unplaced]** groups you still need. **Yes** to go ahead, **No** to cancel.

🟢 **Ungroup complete** — "Ungrouped: *N*", plus "Unpinned first: *N*" and "Leftover group types deleted: *N*" when they apply
- **Why:** Summary after ungrouping.
- **What to do:** Nothing. Check the **Skipped** part if there is one.

🟢 **Delete complete** — "Deleted group types: *N*"
- **Why:** Summary after deleting.
- **What to do:** Nothing. Check the **Skipped** part if there is one.

🟡 **Skipped (*N*):** (inside a summary) — "*group name*: *reason*"
- **Why:** Some groups couldn't be processed, e.g. "instance no longer valid", or a Revit reason. Up to 15 are listed.
- **What to do:** Click **Refresh** and try again. In a workshared model, check that nobody else is editing those groups.

🟢 **Model Group Manager** — "Full report copied to the clipboard (*N* group types)."
- **Why:** You clicked **Copy report**.
- **What to do:** Paste it into an email, Teams or a text file.

🔴 **Ungroup failed / Delete failed** — "Transaction rolled back: …"
- **Why:** The whole action failed. **Nothing** was changed.
- **What to do:** Screenshot it and contact the author.

🔴 **Model Group Manager - unexpected error** or **"The UI failed to load. Missing controls: …"**
- **Why:** Something unexpected happened.
- **What to do:** Screenshot it and contact the author.

---

## 9. FAQ

**Does opening the window change my model?**
No. Only the two clean-up buttons change the model, and only after you click **Yes**.

**Can I ungroup just one of the single-instance groups?**
Not with this tool. The buttons act on all qualifying groups. Ungroup one group the normal Revit way (select it → **Ungroup**).

**Why is a single-instance group not ungrouped?**
It's nested inside another group (**Single instance (nested)**). Ungroup the outer group first, then click **Refresh**.

**What does "Purge leftover type after ungroup" do?**
After ungrouping, the group type is no longer used. With the chip on, it's deleted so it doesn't sit in the project. Turn it off to keep the type for later use.

**Why does Created By say "N/A - not workshared"?**
That information only exists in workshared models.

**Why is a group "Unplaced" when I know it has walls in it?**
Unplaced means no copy is placed in the model. Revit can't show its contents without a placed copy, so it's treated as empty and offered for deletion.

**What's in the copied report?**
For every group: name, status, Created By, Last Changed By, instances, levels and full contents, plus totals at the end.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| A clean-up button is greyed out | No groups qualify (count is 0) | Check the **Status** column | ❌ |
| List looks out of date | Model changed since the window opened | Click **Refresh** | ❌ |
| Groups in the **Skipped** list | Group changed, or owned by someone else in a workshared model | **Refresh**, sync, ask the owner to release it | ✅ If it repeats |
| Deleted a group type I needed | It was **Unplaced** and was included in **Delete empty groups** | Close the window, **Ctrl + Z** | ❌ |
| Created By shows **<unavailable>** | Revit couldn't read the worksharing info | Sync and try again | ❌ |
| "Ungroup failed" / "Delete failed" | Unexpected problem. Nothing was changed. | Screenshot it | ✅ |
| Red error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which action** you used (browse, Ungroup, Delete, Copy report)
2. A **screenshot** of the window and of any message or error
3. Your **Revit version** (e.g. 2025)
4. The **model name**, and whether it's **workshared**
5. **What you expected** to happen, and what actually happened
