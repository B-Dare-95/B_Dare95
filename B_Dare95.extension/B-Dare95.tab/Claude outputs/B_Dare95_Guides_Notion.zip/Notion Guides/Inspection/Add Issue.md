# Add Issue

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Inspection** panel → **Add Issue**
> 🧩 **Works with:** Revit 2024 and newer · needs the free screenshot app **Snipaste** to capture screenshots
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Add Issue** opens the **Issue Logger**: a small window for recording problems you find while reviewing a model.

For each issue you:

1. **Take one or more screenshots** of the problem.
2. **Type a comment** (and any other fields you like, e.g. *Discipline*, *Level*, *Assigned to*).
3. Click **Save Issue**.

Every issue is saved as **one row in an Excel file (.xlsx)**, with the date and time, your text, and the screenshots placed in the row. You can keep **several Excel files open as tabs**, for example one per project or per review.

> 💡 Think of it as a **digital snag list**: snap the problem, write a note, and it lands in a spreadsheet you can send to the team.

📸 *[Screenshot: the Issue Logger window with a few saved issues on the right]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change your Revit model | It only writes to the Excel file. Nothing in the model is touched, and there is nothing to undo in Revit. |
| Take screenshots by itself | It uses the **Snipaste** app. Without Snipaste you can't capture screenshots, and **an issue can't be saved without at least one screenshot**. |
| Record element IDs, views or levels automatically | Only what you type and capture is saved. Add a field (e.g. *View* or *Element ID*) and type it in if you need it. |
| Save an issue without a screenshot | Every issue needs **at least one screenshot** and **at least one filled-in field**. |
| Ask before deleting | The 🗑 button on a saved issue and the **×** next to a field act **immediately**. See [Section 8](#8-deleting-and-undoing). |
| Save to a file that's open in Excel | Close the file in Excel first, otherwise the save fails. |
| Share the list of open tabs with other PCs | The tabs you have open are remembered **on your own computer** only. The Excel files themselves can live anywhere (e.g. a shared folder). |

---

## 3. Before you start

- [ ] **Snipaste** is installed. If it isn't, the window shows an orange banner with a **Get from Microsoft Store** button.
- [ ] You know **where** you want to keep the Excel file (e.g. your project folder).
- [ ] The Excel file you want to use is **not open in Excel**.

---

## 4. How to use it

### First time

1. Click **Add Issue**.
2. A save window titled **Create a new Issue Logger file** opens. It suggests the name `Issues.xlsx` in your **Documents** folder.
3. Choose a folder and a name, then click **Save**. The file is created, and a tab with its name appears at the top of the window.

> 💡 If you pick a file that **already exists**, the tool **opens** it instead of replacing it.

### Logging an issue

1. Click **Take Screenshot**. The Issue Logger hides itself and the Snipaste capture screen appears.
2. **Drag a box** around the problem, then confirm it in Snipaste so the image is **copied to the clipboard**. The window comes back and a thumbnail appears.
3. *(Optional)* Click **Take Screenshot** again to add more screenshots to the same issue.
4. Type your note in the **Comment** box (and any other fields).
5. Click **Save Issue**. The issue appears at the top of **Saved Issues** on the right, and the status bar shows **"Issue #N saved → …"**. ✅
6. The fields and thumbnails are cleared, ready for the next issue.

> ⚠️ **Your clipboard is cleared** each time you click **Take Screenshot**, so the tool doesn't pick up an old image by mistake. Paste anything you need **before** you take a screenshot.

> 💡 The window can stay open while you work in Revit. Clicking **Add Issue** again just brings the same window to the front.

📸 *[Screenshot: the left side of the window with two staged screenshots and a filled Comment field]*

### Window controls

| Control | What it does |
|---|---|
| **File tabs** (top) | One tab per Excel file. Click a tab to switch to that file. Hover to see the full file path. |
| **×** on a tab | Closes the tab. **The file stays on disk.** |
| **+** (end of the tab bar) | Creates a new Excel file, or opens an existing one. |
| **Snipaste: found / not found** | Shows whether Snipaste was found on this computer. |
| **Save As…** | Saves a copy of the current file under a new name or folder. The tab then points to the **new** file. The original is left on disk. |
| **Path bar** | Shows the full path of the current file and how many issues it has. |
| **Take Screenshot** | Starts a Snipaste capture. Greyed out when Snipaste isn't installed or no file is open. |
| **Thumbnails** (with a small **×**) | The screenshots waiting to be saved with this issue. **×** removes one. |
| **Field rows** | A **field name** on the left (click it to rename) and a **value box** on the right (Enter makes a new line). |
| **×** next to a field | Removes that field (column). ⚠️ See [Section 6](#6-fields-columns). |
| **+ Add Field** | Adds a new field called *Field 2*, *Field 3*… Its name is selected so you can type a new name straight away. |
| **Status bar** | Tells you what just happened (see [Section 9](#9-messages-you-may-see)). |
| **New Issue** | Clears the fields and staged screenshots and starts a fresh issue. |
| **Save Issue** / **Update Issue #N** | Saves the issue to the Excel file. The label changes to **Update** while you edit an existing issue. |
| **Saved Issues (N)** (right side) | Every issue in the current file, **newest first**. |
| 🗑 on an issue card | Deletes that issue from the file **immediately**. |
| **Screenshot on an issue card** | Click it to load that issue back into the left side for editing. |

---

## 5. Editing a saved issue

1. In **Saved Issues**, click one of the issue's **screenshots**.
2. Its screenshots and text are loaded on the left. The caption reads *"Editing Issue #N…"* and the save button becomes **Update Issue #N**.
3. Change the text, add screenshots with **Take Screenshot**, or remove some with **×**.
4. Click **Update Issue #N**. ✅

| You want to… | Do this |
|---|---|
| Keep the original changes | Click **Update Issue #N** |
| Drop your changes | Click **Cancel edit** (or **New Issue**) |

> 💡 An updated issue **keeps its original date and time**.

---

## 6. Fields (columns)

Each **field** becomes a **column** in the Excel file. A new file starts with one field: **Comment**.

- **Add** a field with **+ Add Field**, then type its name.
- **Rename** a field by clicking its name and typing. The new name is written to the file the next time you **save, update or delete** an issue (or use **Save As…**).
- **Remove** a field with the **×** next to it.

> ⚠️ **Removing a field deletes that column's text from every issue in the file**, straight away and without asking. At least one field must always remain.

> 💡 Fields belong to the file. Each tab can have its own set of fields.

---

## 7. What the Excel file looks like

| Column | Content |
|---|---|
| **Timestamp** | Date and time the issue was first saved, e.g. `2026-10-07 14:32:05` |
| **Your fields** | One column per field (Comment, plus any you added), in the same order as in the window |
| **Screenshots** | The issue's screenshots, placed in the row side by side |

The sheet is called **Issues**, and each issue row is made tall so the screenshots fit.

> ⚠️ **Treat the Excel file as the tool's output.** The tool rewrites the whole file every time you save, update or delete. Changes you make and save in Excel (extra columns, formatting, edited text) may not be read back by the tool and can be lost at the next save. If you want to work on the list in Excel, **make a copy** first (or use **Save As…** in the tool).

---

## 8. Deleting and undoing

| You want to… | Do this |
|---|---|
| Remove a staged screenshot (not yet saved) | Click the small **×** on its thumbnail |
| Delete a saved issue | Click 🗑 on its card. It is removed from the file **immediately**. Issues after it are renumbered. |
| Stop using a file | Click **×** on its tab. The file is **not** deleted. |
| Undo in Revit | Not needed. The tool never changes the model, so there's nothing in Revit's Undo list. |
| Undo a deleted issue or field | ❌ Not possible in the tool. Restore the Excel file from a backup or previous version (e.g. OneDrive/SharePoint version history), if you have one. |

---

## 9. Messages you may see

All messages appear in the **status bar** above the **New Issue / Save Issue** buttons.

🟢 **"Issue #N saved → …"** / **"Issue #N updated → …"**
*Why:* The issue was written to the Excel file.
*What to do:* Nothing.

🟢 **"Screenshot captured (N staged) — add more, or fill in the fields and save."**
*Why:* Your screenshot was received.
*What to do:* Take more, or fill in the fields and save.

🔵 **"Waiting for Snipaste… draw a selection, or press Esc to cancel."**
*Why:* The capture screen is open.
*What to do:* Drag a box and confirm it in Snipaste, or press **Esc**.

🟡 **"Snip cancelled — nothing was copied to the clipboard."**
*Why:* You pressed Esc, or closed Snipaste without copying the image.
*What to do:* Click **Take Screenshot** again. Make sure the image ends up **copied** in Snipaste.

🟡 **"Timed out after 45s waiting for a screenshot."**
*Why:* No new image reached the clipboard within 45 seconds.
*What to do:* Try again, and finish the capture within 45 seconds.

🟡 **"No screenshot captured — take at least one first."**
*Why:* Every issue needs at least one screenshot.
*What to do:* Click **Take Screenshot**.

🟡 **"Please fill in at least one field before saving."**
*Why:* All fields are empty.
*What to do:* Type something in at least one field.

🟡 **"Create or open a file first (click + in the tab bar)."** / **"No file yet — click + in the tab bar to create your first issue file."**
*Why:* No Excel file is open.
*What to do:* Click **+** and create or pick a file.

🔴 **"Save failed — is the file open in Excel? …"** / **"Delete failed — is the file open in Excel? …"**
*Why:* The file couldn't be written. Most often it's open in Excel, or you don't have permission for that folder.
*What to do:* Close it in Excel and try again. For a delete, the issue is put back in the list.

🟡 **"At least one field must remain."**
*Why:* You tried to remove the last field.
*What to do:* Rename it instead.

🔴 **"Field removed, but re-saving the file failed: …"**
*Why:* The field was removed in the window, but the file couldn't be written (e.g. it's open in Excel).
*What to do:* Close the file in Excel, then save an issue to write the change.

🟡 **"That file is already open in another tab — pick a different name."**
*Why:* **Save As…** pointed at a file that's open in another tab.
*What to do:* Choose another name or folder.

🟢 **"Saved to new location → … (the original file was left on disk)"** / **"Saved in place → …"**
*Why:* **Save As…** worked.
*What to do:* Nothing. The tab now uses the new file.

🔴 **"Could not create file: …"** / **"Save As failed: …"**
*Why:* The file couldn't be written in that folder.
*What to do:* Pick a folder you can write to.

🟡 **"Snipaste: not found"** + orange banner **"Snipaste is not installed on this machine."**
*Why:* Snipaste wasn't found on your computer.
*What to do:* Click **Get from Microsoft Store**, install it, then close and reopen the Issue Logger.

🔴 **"Could not start Snipaste — …"** / **"Screenshot failed — …"** / **"Could not open Microsoft Store: …"**
*Why:* Something outside the tool went wrong.
*What to do:* Try again. If it repeats, contact the author.

🔵 Other short confirmations: **"Created “…”."**, **"Opened existing “…”."**, **"Switched to “…”."**, **"Closed tab “…” (the file is still on disk)."**, **"Issue #N deleted."**, **"Screenshot removed — N staged."**, **"Editing Issue #N. Make your changes and press Update."**, **"Edit cancelled."**, **"Started a new issue — fields are cleared."**

---

## 10. FAQ

**Does this change my Revit model?**
No. It only writes to the Excel file.

**Can I screenshot something outside Revit, like a PDF or an email?**
Yes. Snipaste captures any part of your screen.

**Can I save an issue with text only, no screenshot?**
No. At least one screenshot is required.

**Can I keep the window open while I work?**
Yes. Revit keeps working normally while it's open. Clicking **Add Issue** again brings the same window to the front.

**What does Shift + click do?**
The same as a normal click. It opens the Issue Logger.

**Where is the list of my open tabs stored?**
On your own computer. When you reopen the Issue Logger, the same tabs come back. Another PC won't see them.

**A file I had open was moved or deleted. What happens?**
Its tab still appears, but empty. If the folder still exists, the file is created again there the next time you save an issue in that tab. Close the tab with **×** if you don't need it.

**Can two people log into the same Excel file at the same time?**
It's not recommended. Each save rewrites the whole file from what that person's window has loaded, so one person's issues can overwrite the other's. Use one file per person, or take turns.

**How are issues numbered?**
By their order in the file (#1 is the oldest). Numbers shift down when you delete an issue.

**Why is the issue newest-first in the window but oldest-first in Excel?**
The window shows the latest issue at the top for convenience. The Excel file keeps them in the order they were saved.

---

## 11. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check that the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| **Take Screenshot** is greyed out | Snipaste not installed, no file open, or a capture is already running | Install Snipaste. Click **+** to open a file. | ❌ |
| Snipaste is installed but shows **not found** | Installed in an unusual location | Reinstall from the Microsoft Store (button in the banner) | ✅ If it's still not found |
| Window disappears when I take a screenshot | Normal. It hides so it isn't in the picture. | It comes back after the capture, a cancel, or 45 seconds | ❌ |
| Screenshot never arrives | The image wasn't **copied** to the clipboard in Snipaste | Check your Snipaste settings so a capture copies the image | ❌ |
| **Save failed — is the file open in Excel?** | File open in Excel, or no write access | Close Excel. Check the folder permissions. | ❌ |
| Text I typed in Excel disappeared | The tool rewrote the file | Don't edit the tool's file in Excel. Work on a copy. | ❌ |
| A renamed field still has the old name in Excel | Renames are written at the next save | Save, update or delete an issue, or use **Save As…** | ❌ |
| Issues from a colleague vanished | Two people saved to the same file | Use separate files | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |
| Anything else unexpected | — | Close the window and click **Add Issue** again | ✅ If it repeats |

---

## 12. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the Issue Logger window, including the **status bar** message
2. Whether the **Snipaste** pill shows *found* or *not found*
3. Your **Revit version** (e.g. 2025)
4. **Where the Excel file is saved** (local drive, network folder, OneDrive/SharePoint)
5. **What you did** just before the problem, and what you expected to happen
