# MEP Tracer

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Inspection** panel → **MEP Tracer**
> 🧩 **Works with:** Revit 2024 and newer · a **3D view** · MEP elements in **linked** models
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🏷️ **Version:** v7
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**MEP Tracer** (shown in its messages as **MEP Branch Tracer**) follows a pipe, duct, cable tray or conduit run from **one element you click** to **everything connected to it**, then shows you that run on its own.

After you pick one element in a linked model, the tool:

1. **Follows the connections** from element to element.
2. **Jumps between models** where a run continues in your own model or in another loaded link (connector ends that meet within about **15 mm**).
3. Puts a **section box** around the whole run (with about **300 mm** of space around it) in the current 3D view.
4. **Selects** every traced element, in the links and in your model, so it's highlighted.
5. Prints a **short summary** in the pyRevit output window.

> 💡 Think of it like pulling one thread of a jumper: everything attached to it comes up with it.

📸 *[Screenshot: a 3D view with a traced run inside the section box, all elements selected]*

### What it can follow

| Services | Categories traced |
|---|---|
| Piping | Pipes, Pipe Fittings, Pipe Accessories, Flex Pipes |
| Ductwork | Ducts, Duct Fittings, Duct Accessories, Flex Ducts |
| Electrical containment | Cable Trays, Cable Tray Fittings, Conduits, Conduit Fittings |
| Equipment | Mechanical Equipment, Plumbing Fixtures |

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Start from your own model | The first pick must be an element **inside a linked model**. |
| Follow other categories | Air terminals, sprinklers, electrical fixtures and other categories not in the table above are not traced. The trace stops there. |
| Stop at a "branch" | It follows **every** connection, including through equipment. Picking a duct next to an AHU can bring in the whole connected network. |
| Work in plans or sections | It only works in a **3D view**. |
| Create anything | No new elements. It only changes the **section box** of the active 3D view and your **selection**. |
| Keep your old section box | The active 3D view's section box is **replaced** by the new one (you can undo it). |
| List element IDs | The summary shows counts per category only. |

---

## 3. Before you start

- [ ] A **3D view** is active. Use a working 3D view, because its section box will be changed.
- [ ] The MEP models are **loaded** as Revit links.
- [ ] The element you'll click is **visible** in the 3D view.

---

## 4. How to use it

1. Open a **3D view**.
2. Click **MEP Tracer**.
3. The status bar (bottom left) says **"Pick a MEP element from a linked file to trace its branch"**.
4. **Click one pipe, duct, cable tray, conduit, fitting or accessory** in a linked model. Only linked elements can be picked.
5. Wait while the run is traced. Large systems can take a moment.
6. The view's **section box** jumps to the run and is switched on.
7. All traced elements are **selected**.
8. The pyRevit output window shows the **MEP Branch Trace** summary. ✅

> 💡 Press **Esc** at step 4 to cancel. Nothing happens.

---

## 5. Reading the summary

The output window shows:

| Line | Meaning |
|---|---|
| **Host model: N** | Traced elements in **your own** model (found where a linked run continues into your model) |
| **Linked files: N (M elements)** | How many links the run passes through, and how many elements in them |
| **Open terminals: N** | Connector ends that are **not connected** and have nothing within ~15 mm. Useful for spotting open ends. |
| **Category / Count** table | How many elements of each category were traced |
| **N element(s) selected.** | How many elements are now selected |
| *N element(s) could not be turned into a selectable reference.* | Some traced elements couldn't be selected. They're still counted and inside the section box. |

📸 *[Screenshot: the MEP Branch Trace summary in the output window]*

---

## 6. Undoing

| You want to… | Do this |
|---|---|
| Get the old section box back | Press **Ctrl + Z**. The Undo list entry is **MEP Branch Tracer - Section Box**. |
| Switch the section box off | View **Properties** → untick **Section Box** |
| Clear the selection | Press **Esc**, or click an empty spot |

The selection itself doesn't change the model, so it isn't in the Undo list.

---

## 7. Messages you may see

All messages have the title **MEP Branch Tracer**.

🟡 **"Please activate a 3D view before running this script. The branch isolation uses the view's section box, which is only available in 3D views."**
- **Why:** You started the tool in a plan, section, sheet, etc.
- **What to do:** Open a 3D view and click the button again.

🟡 **"The selected element is not a traceable MEP element. Please select a pipe, duct, cable tray, conduit, fitting, or accessory."**
- **Why:** You picked something outside the categories in [Section 1](#what-it-can-follow) (e.g. a wall, an air terminal, a sprinkler).
- **What to do:** Run again and pick a pipe, duct, tray, conduit, fitting or accessory.

🟡 **"The selected linked file is not currently loaded."**
- **Why:** The link you clicked isn't loaded.
- **What to do:** Reload it in **Manage Links**, then try again.

🔴 **"Could not resolve the linked file instance."**
- **Why:** The tool couldn't identify which link you clicked.
- **What to do:** Try again. If it repeats, contact the author.

🔴 **Warning: Could not compute a bounding box for the traced elements.** (output window)
- **Why:** The traced elements have no size the tool can read. No section box is set.
- **What to do:** Contact the author with the model details.

🔴 **A pyRevit error window**
- **Why:** Something unexpected happened.
- **What to do:** Screenshot it and contact the author.

---

## 8. FAQ

**Does this change my model?**
Only the section box of the active 3D view. No elements are created, moved or deleted.

**Why did it trace much more than one branch?**
It follows every connection, including through equipment (e.g. an AHU or pump) into other connected systems. Pick an element further down the run, or accept the larger result.

**Why did the trace stop at an air terminal or sprinkler?**
Those categories aren't traced. See [What it can follow](#what-it-can-follow).

**Can I start from an element in my own model?**
No. The first pick must be in a linked model. Elements in your own model are picked up only when the linked run continues into them.

**How does it jump between models?**
When an end isn't connected, it looks for another element's connector within about 15 mm, in your model or in any other loaded link. If it finds one, the trace continues there.

**What is an "open terminal"?**
An end that isn't connected to anything and has nothing close to it. Often it's a real open end, or a gap bigger than ~15 mm.

**My selection disappeared.**
Clicking in the view or pressing Esc clears it. The section box stays.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| Can't click the element | It's in your own model, not a link | Pick an element inside a linked model | ❌ |
| "Not a traceable MEP element" | Category isn't traced | Pick a pipe, duct, tray, conduit, fitting or accessory | ❌ |
| Trace stops early | Gap between elements bigger than ~15 mm, an unloaded link, or a category that isn't traced | Check **Open terminals** in the summary. Check links are loaded. | ❌ |
| Trace is far too big | It passed through equipment into other systems | Start from a different element | ❌ |
| Section box in the wrong place, or wrong elements selected, when the same link is placed more than once | Several copies of the same link | Note which copy you clicked | ✅ |
| Old section box lost | The tool replaces it | **Ctrl + Z** | ❌ |
| Takes a long time | Very large connected network | Wait | ✅ If Revit freezes |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the 3D view and of the **MEP Branch Trace** summary
2. Which **element** you clicked, and in **which link**
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the names of the **links** involved
5. **What you expected** to be traced, and what actually was
