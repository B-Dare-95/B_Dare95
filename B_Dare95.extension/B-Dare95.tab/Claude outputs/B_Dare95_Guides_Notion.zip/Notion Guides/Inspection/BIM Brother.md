# BIM Brother

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Inspection** panel → **BIM Brother** dropdown → **Active Model** / **Linked Models**
> 🧩 **Works with:** Revit 2024 and newer · project files only (not families)
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**BIM Brother** keeps an eye on a model and tells you **what changed since the last time it looked**: which elements are **new**, **deleted**, **moved**, **resized**, or had their **data** (parameters or type) changed.

The dropdown has **two tools**:

| Tool | Watches | Window title |
|---|---|---|
| **Active Model** | The project you have open | **Change Tracker** |
| **Linked Models** | One Revit link at a time, chosen from the links loaded in your project | **BIM Brother · Links** |

Each change shows **who created** and **who last modified** the element (in workshared models), **when** it was detected, and exactly **what** changed (e.g. *Length 3000 mm → 3450 mm*). Click any change to **select and zoom to** the element in Revit.

> 💡 Think of it as a **"spot the difference"** between two photos of the model: the last scan and the scan now.

📸 *[Screenshot: the BIM Brother dropdown open, showing Active Model and Linked Models]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change your model | It only **reads** the model, then **selects** and **zooms**. Nothing is edited. There's nothing to undo. |
| Show changes made before the first scan | The first scan is only a starting point ("baseline"). Changes appear from the **second** scan onwards. |
| Track every category | Only the main model categories are tracked (see [Section 3](#3-what-is-tracked)). Annotation, views, sheets, rooms, furniture etc. are not. |
| Show every single edit | It compares **two scans**. If an element was moved and moved back between scans, nothing shows. Several edits between two scans appear as **one** change. |
| Report tiny changes | Moves and size changes under **1 mm** and rotations under **0.1°** are ignored. |
| Report read-only values | Only parameters you can edit are compared. Calculated values (e.g. Area, Volume) aren't listed as data changes. |
| Share results with your team | Results are saved **on your own computer**. Each person has their own history. |
| Undo or restore deleted elements | It only shows where a deleted element used to be. |
| Watch unloaded or nested links | **Linked Models** lists only **loaded**, **top-level** links. |

---

## 3. What is tracked

| Discipline | Categories |
|---|---|
| **Architecture** | Walls, Floors, Roofs, Ceilings, Doors, Windows, Stairs, Railings, Columns, Generic Models, Shaft Openings |
| **Structure** | Structural Columns, Structural Framing, Structural Foundations |
| **Mechanical** | Ducts, Flex Ducts, Duct Fittings, Duct Accessories, Air Terminals, Mechanical Equipment |
| **Plumbing / Fire** | Pipes, Flex Pipes, Pipe Fittings, Pipe Accessories, Plumbing Fixtures, Sprinklers |
| **Electrical** | Cable Trays, Cable Tray Fittings, Conduits, Conduit Fittings, Electrical Equipment, Electrical Fixtures, Lighting Fixtures |

Elements that exist in **one view only** (e.g. detail items) and parts **nested** inside another family are skipped.

### Types of change

| Tag | Meaning | Example of what you see |
|---|---|---|
| **NEW** (green) | The element didn't exist in the last scan | *New element* |
| **DELETED** (red) | The element was in the last scan and is gone now | *Element deleted*, with its last known family and type |
| **MOVED** (blue) | It moved or rotated by more than the tolerance | *Moved 250 mm* · *Shifted 250 mm (X +250, Y 0, Z 0)* · *Rotated* |
| **RESIZED** (teal) | Its length or overall size changed | *Resized (Length 3000 mm → 3450 mm)* · bounding box size before → after |
| **DATA** (purple) | Its type changed, or an editable parameter value changed | *Type: Basic Wall: 200mm → Basic Wall: 250mm* · *Mark changed* · *3 parameters changed* |

One element can have **several tags** at once, e.g. **MOVED** + **DATA**.

---

## 4. When are changes detected?

BIM Brother works by **scans**. Each scan is compared with the previous one.

| Scan | When |
|---|---|
| **First scan (baseline)** | **Active Model:** the first time you click the button for that project. **Linked Models:** when you pick a link to watch. |
| **Refresh now** | Whenever you click **Refresh now** in the window |
| **Automatic** | The window mentions scans after opening the model, **Sync with Central** and **Reload Latest** (Active Model), or after a link is **reloaded** (Linked Models). |

> ⚠️ **Click Refresh now before you review.** Opening the window shows the results of the **last** scan; it doesn't scan again by itself. If you don't see your latest work, click **Refresh now**. The status bar at the bottom tells you when the last scan ran and what started it.

How long things stay in the list:

- A **deleted** element stays in the list for **30 days**, then disappears by itself. Its row shows **"Expires in N days"**.
- Other changes **stay** until the element changes again. The newest change then replaces it, and the older one moves to **Earlier changes** (the last 10 are kept).

---

## 5. Before you start

- [ ] A **project** is open (not a family).
- [ ] **Linked Models only:** the link you want is **loaded**.
- [ ] For best results, a **3D view or plan** is active. Clicking a change zooms **the active view**.
- [ ] Big models: the first scan and each **Refresh now** can take a while. The mouse shows a busy cursor until it's done.

---

## 6. How to use — Active Model

1. Click **BIM Brother** → **Active Model**.
2. **First time for this project:** the tool takes a baseline scan (busy cursor), then the **Change Tracker** window opens with *"No changes recorded yet…"*. That's normal. Work on the model, then come back and click **Refresh now**.
3. **Next times:** the window opens with the changes found so far.
4. Click **Refresh now** to scan the model again.
5. Use the **filters** and **search** to narrow the list (see [Window controls](#window-controls)).
6. **Click a change** to see its details on the right. The element is **selected in Revit** and the view **zooms to it**. ✅
7. Close the window when you're done.

📸 *[Screenshot: the Change Tracker window with the tree on the left and details on the right]*

---

## 7. How to use — Linked Models

1. Click **BIM Brother** → **Linked Models**.
2. The **BIM Brother · Links** window opens. If you already watch a link, the one you looked at last is shown.
3. Click the **link picker** at the top (*"Choose a link to monitor"*). A list of loaded links opens, with a **Search links...** box.
   - Links you already watch carry a green **WATCHING** tag and show *"Monitored · … · last scan …"*.
   - Other links show *"Not monitored · … · select to start watching"*.
4. **Pick a link:**
   - **Not watched yet:** the tool takes a baseline scan of that link. The status bar says *"Now watching … Baseline captured · changes appear after the link is reloaded."*
   - **Already watched:** its changes are shown.
5. When the link has been updated (e.g. you **reloaded** it with a newer version), click **Refresh now**.
6. **Click a change** to see its details. The linked element is **selected** and the active view **zooms** to it. ✅

> 💡 The history belongs to the **linked model**, not to your project. If two of your projects link the same model, they share one history on your computer, so you don't see the same change twice.

> 💡 Moving the **link itself** in your project doesn't report every element as moved. Only changes **inside** the linked model count.

### Stop watching a link

1. Pick the link, then click **Stop monitoring** (top right).
2. Confirm the question:
   > *"Stop monitoring [link]? It will no longer refresh automatically from this project. Its register file is kept, so picking it again later continues from where it left off."*
3. Click **Yes**. The status bar says *"Stopped monitoring [link]."*

📸 *[Screenshot: the link picker open with one link tagged WATCHING]*

---

## 8. Window controls

Both windows work the same way. **Linked Models** adds the link picker and **Stop monitoring**.

| Control | What it does |
|---|---|
| **Link picker** *(Linked Models only)* | Choose which loaded link to watch or review |
| **Stop monitoring** *(Linked Models only)* | Stop watching the current link. Shown only for watched links. |
| **Refresh now** | Scan again and add any new changes |
| **Expand all** / **Collapse all** | Open or close every group in the list |
| **Search box** *("Filter by ID, type, user, change...")* | Shows only changes containing your text: element ID, category, family, type, user name, the change summary or any changed value. Upper/lower case doesn't matter. |
| **All / New / Deleted / Moved / Resized / Data** | Show only one type of change. The number on each shows how many there are. |
| **Sort by time** | Switches from the grouped list to a **flat list, newest first** |
| **Change list** (left) | Grouped by **Category › Family › Type**. Each group shows its number of changes. Groups open automatically when 150 changes or fewer are shown. |
| **Details panel** (right) | Everything about the selected change (see below) |
| **Zoom to element** / **Zoom to last location** | Selects and zooms again, e.g. after you've moved around the view |
| **Status bar** (bottom) | Last scan info, or the result of your last click |

### Reading a change row

- **Tags** (NEW, MOVED…), then the element, e.g. **Wall (123456)**, where the number is its **Element ID**, then a short summary.
- **Created By**, **Modified By**, **Detected** (date and time).
- Deleted elements also show **Expires in N days** (or **Expires today**).

### The details panel

| Part | What it shows |
|---|---|
| **Tags + name** | E.g. **Duct (456789)** and *Category › Family › Type* |
| **Summary** | E.g. *Moved 120 mm · Mark changed* |
| **Red note** *(deleted only)* | *"This element no longer exists…"* and how many days until it leaves the list |
| **What changed** | One box per change: **old → new** (e.g. *Offset: 2700 mm → 2900 mm*). For a new element: *Element created.* |
| **Created By / Modified By** | User names from worksharing. In a non-workshared model, changes are credited to you. |
| **Detected / Detected On** | When the change was found, and by which scan: *Manual refresh*, *Document opened*, *Sync with Central*, *Reload Latest*, *Register created*, *Monitoring started*, *Host opened* or *Link reloaded* |
| **Earlier changes** | Older changes of the same element: date · summary · user |

---

## 9. Shift + click

| Tool | Shift + click opens… |
|---|---|
| **Active Model** | Windows File Explorer, with this project's **history file** selected. If there isn't one yet, a baseline scan is taken first. |
| **Linked Models** | Windows File Explorer, with the history file of the link you looked at last selected (or the folder with all link history files) |

> 💡 You don't need these files day to day. They're useful when the author asks for them.

---

## 10. Undoing

| You want to… | Do this |
|---|---|
| Undo something the tool did to the model | Not needed. BIM Brother never changes the model, so there's nothing in Revit's Undo list. |
| Clear the selection it made | Press **Esc** in the view |
| Stop watching a link | **Stop monitoring** ([Section 7](#stop-watching-a-link)) |
| Start a project's history from scratch | Contact the author. |

---

## 11. Messages you may see

🟢 **"Last refresh: [scan] · [date] · N elements scanned in N s"**
*Why:* Normal status after a scan.
*What to do:* Nothing.

🟢 **"Selected [element] in Revit · view zoomed to element"** / **"Selected [element] in the link · active view zoomed to element"**
*Why:* You clicked a change.
*What to do:* Nothing.

🔵 **"No changes recorded yet. They appear after the next Sync with Central, Reload Latest, document open, or Refresh now."** *(Active Model)*
🔵 **"No changes recorded yet. They appear after the link is reloaded, when the host opens with a newer version of it, or on Refresh now."** *(Linked Models)*
*Why:* Only the baseline exists, or nothing has changed since.
*What to do:* Make or receive some changes, then click **Refresh now**.

🔵 **"No changes match this filter."**
*Why:* Your search text or filter button hides everything.
*What to do:* Clear the search box and click **All**.

🔵 **"Choose a link from the dropdown above to start monitoring it."** / **"Waiting for a link to watch."**
*Why:* No link is picked yet.
*What to do:* Use the link picker.

🟡 **"[element] is no longer in the model. Refresh to update the register."** / **"…is no longer in the loaded link. Refresh to update the register."**
*Why:* The element was deleted after the last scan.
*What to do:* Click **Refresh now**. It then appears as **DELETED**.

🟡 **"Selected [element], but no open view can show it."**
*Why:* It's selected, but none of your open views can display it (hidden, cropped, wrong level…).
*What to do:* Open a 3D view and click the change again.

🟡 **"Active view zoomed to [element] (linked elements could not be selected here)"** / **"[element] found, but the active view cannot show it."**
*Why:* Linked elements can't always be selected or shown in every view.
*What to do:* Switch to a 3D view and try again.

🔴 **"[element] no longer exists · active view zoomed to its last known location"**
*Why:* You clicked a **deleted** element. Red is just the colour for deleted items here.
*What to do:* Look at the zoomed area to see what's there now.

🔴 **"[element] no longer exists and has no stored location to zoom to."**
*Why:* No position was stored for it, or the active view can't zoom.
*What to do:* Switch to a plan or 3D view and try again.

🔴 **"Refresh failed: …"** / **"Could not start monitoring [link]: …"**
*Why:* The scan hit an unexpected problem.
*What to do:* Try once more. If it repeats, contact the author.

🔴 **Change Tracker** box: **"Could not build the register: …"** / **"The register for this document could not be read."**
*Why:* The history file couldn't be created or read.
*What to do:* Contact the author (**Shift + click** to show where the file is).

🔵 **"Change Tracker works on project documents only."** / **"BIM Brother works on project documents only."**
*Why:* A family is open.
*What to do:* Switch to a project.

🔵 **"This project has no loaded Revit links to monitor."**
*Why:* No link is loaded (or all are unloaded/nested).
*What to do:* Load the link in **Manage Links**, then try again.

---

## 12. FAQ

**Does BIM Brother change my model?**
No. It only reads, selects and zooms.

**Why is the list empty the first time?**
The first scan is the starting point. Changes appear from the next scan onwards.

**Does it update by itself?**
The window mentions automatic scans after open, sync and reload. To be sure you see the latest state, click **Refresh now** before reviewing. Check the status bar to see when the last scan ran.

**Will my colleague see the same list?**
No. Each person's history is saved on their own computer and starts from their own first scan.

**Who is "Modified By"?**
In workshared models it's the last person who changed the element, as recorded by Revit's worksharing. Your own unsynced edits show **you**. In non-workshared models, changes are credited to you. A **—** means the name wasn't available.

**An element on a closed workset — will it show as deleted?**
No. Elements on worksets you closed are not reported as deleted.

**I moved a wall and moved it back. Why isn't it listed?**
Only the difference between two scans counts. If it's back where it was, there's no difference.

**Why is a Floor marked MOVED when I only changed its height offset?**
Vertical moves are detected from the element's overall position, so an offset change can show as **MOVED** (and as **DATA**, since a parameter changed).

**How long do changes stay?**
Deleted elements: 30 days. Other changes stay until the element changes again; then the older change moves to **Earlier changes**.

**Can I watch several links?**
Yes. Pick each one once to start watching it. The window shows one link at a time; switch with the link picker.

**What happens to the history if I stop watching a link?**
It's kept. Pick the link again later and it continues from where it left off.

**What's the number in brackets, e.g. Wall (123456)?**
The element's **ID**. You can search for it in the search box, or use Revit's **Select by ID**.

---

## 13. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the buttons | B-Dare95 tab missing or not loaded | Restart Revit. Look under **Inspection → BIM Brother** dropdown. | ✅ If it's still missing |
| List doesn't show my latest changes | No scan since you made them | Click **Refresh now** | ❌ |
| List is empty after the first click | First scan = baseline only | Work, then **Refresh now** | ❌ |
| Window takes long to open the first time / Refresh is slow | Large model: every tracked element is scanned | Wait for the busy cursor to go. The status bar shows how long it took. | ✅ If Revit freezes |
| A category I care about isn't in the list | Not a tracked category ([Section 3](#3-what-is-tracked)) | — | ✅ To request it |
| Too many **MOVED** items after a big edit | Many elements genuinely shifted (e.g. a level moved) | Filter with **Moved** and check a few | ❌ |
| Clicking a change doesn't zoom | Active view can't show it | Switch to a 3D view | ❌ |
| My link isn't in the link picker | Link unloaded or nested in another link | **Manage Links** → reload it | ❌ |
| "Modified By" shows **—** | Model not workshared, or name not available | — | ❌ |
| **Could not build the register** / **Refresh failed** | Unexpected problem | Screenshot it | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 14. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which tool** you used (**Active Model** or **Linked Models**) and, for links, the **link name**
2. A **screenshot** of the window, including the **status bar** at the bottom
3. Your **Revit version** (e.g. 2025)
4. The **model name**, and whether it's **workshared** / on **ACC**
5. **What you expected** to see, and what you saw instead
6. If asked: the history file (**Shift + click** the button to find it)
