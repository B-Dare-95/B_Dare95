# Family Tree

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Inspection** panel → **Family Tree**
> 🧩 **Works with:** Revit 2024 and newer · loadable families in the open model
> 👤 **Tool author:** Mohamed Bedair — [email] · [Teams / chat]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Family Tree** shows you **what is nested inside a family**, level by level, without opening the Family Editor yourself.

You choose a category, then one or more families. For each family the tool builds a **visual report** that opens in your web browser. It shows:

- The family and every family **nested** inside it, and inside those, and so on.
- For each one: **number of types**, **instance parameters** and **type parameters**.
- A full **parameter list** per family, grouped like in Revit, with **custom** parameters marked.

> 💡 Think of it as an X-ray of a family: you see the families hidden inside it and what parameters each one carries.

📸 *[Screenshot: a Family Tree report in the browser]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Change your model or families | It only **reads** them. Nothing to undo. |
| Show system families | Walls, floors, pipes and other system families can't be opened, so they aren't listed. Only loadable (editable) families are. |
| Show some annotation heads | Section heads, level heads, grid heads, callout heads, elevation marks, spot elevation symbols and viewport labels are left out. |
| Show parameter **values** | The report lists parameter names, data type and Instance/Type, not their values. |
| Save the report in your project folder | Reports go to the Windows **temporary folder**. Save a copy elsewhere if you need to keep it. |

---

## 3. Before you start

- [ ] A **project** with the families you want to check is open and active.
- [ ] You have a **web browser** set as the default for `.html` files.
- [ ] For families with deep nesting, allow some time. Every nested family is opened in the background to be read.

---

## 4. How to use it

### Step 1 — Choose a category

1. Click **Family Tree**.
2. The window **Family Tree - Step 1: Select Category** opens. It shows how many categories have editable families.
3. *(Optional)* Type in the **search box** above the list to shorten it.
4. Click **one category**. The number in brackets is how many families it has.
5. Click **Next ->**.

### Step 2 — Choose families

6. The window **Family Tree - Step 2: Select Families [*category*]** opens.
7. *(Optional)* Type in the **search box** to shorten the list.
8. Click the families you want. Each click **ticks or unticks** a family, so you can choose several. The grey number shows how many types each family has.
9. Click **Investigate ->**.
10. One report per family opens in your **web browser**. ✅

> ⚠️ **Search first, then choose.** Typing in the search box rebuilds the list and **clears families you already picked**.

📸 *[Screenshot: Step 2 window with two families selected]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** | Filters the list as you type. Matches any part of the name; upper/lower case doesn't matter. |
| **Category list** (Step 1) | Pick one category. |
| **Family list** (Step 2) | Click to pick or unpick families. Several can be picked. |
| **Next ->** / **Investigate ->** | Go on. Nothing happens if nothing is picked. |
| **Cancel** or window **X** | Stops the tool. No report is made. |

---

## 5. Reading the report

The report is titled **Family Tree Report** with the family name underneath.

### Cards

Each family is a **card**. Cards are joined by lines that show what sits inside what.

| Item on a card | Meaning |
|---|---|
| **ROOT** badge | The family you picked |
| **L1**, **L2**, … badge | Nesting level. L1 = nested directly in the root, L2 = nested in an L1 family, etc. |
| **📄 N Types** | Root: types loaded in the project. Nested: types loaded inside its parent family. |
| **⚙ N Instance Params** | Number of instance parameters in that family |
| **⚙ N Type Params** | Number of type parameters in that family |
| **Parameters (N)** button | Click to show or hide the parameter table |
| **◆ N custom** | How many parameters are not built into Revit (family, shared or project parameters) |

### Parameter table

| Column | Meaning |
|---|---|
| **Name** | Parameter name. Custom ones have a pink **◆ Custom** tag and a pink row. |
| **Data Type** | **Text**, **Number**, **Integer** or **Element** |
| **Kind** | **Instance** or **Type** |

Rows are grouped under their Revit parameter group (e.g. Dimensions, Identity Data), with the count in brackets.

### Colours

The **Nesting Level Colors** legend at the bottom shows the colour of each level: Level 0 (root) to Level 5+.

### Red notes on a card

| Note | Meaning |
|---|---|
| **Excluded annotation category** | One of the annotation heads listed in [Section 2](#2-what-this-tool-does-not-do). Not opened. |
| **Circular reference skipped** | A family with this name was already shown earlier in the tree, so it isn't opened again. |
| **Unnamed system family skipped** | A family without a name. Not opened. |
| **Could not open: …** | Revit couldn't open this family to read it. |

A nested family that **can't be edited** shows its card normally, but with **0** parameters.

---

## 6. Undoing

Nothing to undo. The tool only reads families and writes a report file. Your model is not changed.

---

## 7. Messages you may see

The tool doesn't show pop-up messages. Here's what to expect:

| Moment | What you see |
|---|---|
| After **Investigate ->** | A short wait while families are read |
| When done | 🟢 One browser tab per family, and the pyRevit output window lists **"Family Tree HTML reports generated:"** with the file location of each report |
| 🔴 A pyRevit error window | Something unexpected happened. Screenshot it and contact the author. |

---

## 8. FAQ

**Does this change my model?**
No. Families are opened in the background only to read them. Nothing is saved back.

**Where is the report saved?**
In the Windows temporary folder, as `FamilyTree_<family name>.html`. The exact path is in the pyRevit output window. Running the tool again on the same family overwrites it.

**Why is my category not in the list?**
Only categories with at least one **editable** (loadable) family are listed.

**Why does a nested family say "Circular reference skipped"?**
The same family name already appears earlier in the tree. It's shown in full only once. This is not always a real circular reference.

**Why does a nested family show 0 parameters?**
It can't be edited, so its parameters can't be read.

**What counts as "Custom"?**
Any parameter that isn't built into Revit: family parameters you added, shared parameters, and similar.

**Do I need Ctrl + Click to pick several families?**
No. In Step 2 each normal click picks or unpicks a family.

**Can I share the report?**
Yes. It's a normal `.html` file. Copy it from the temporary folder and send it.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| **Next ->** / **Investigate ->** does nothing | Nothing picked | Click a category / family first | ❌ |
| Picked families disappeared | You typed in the search box after picking | Search first, then pick | ❌ |
| Family list is slow while typing | Large model with many family types | Type the full search term, then wait | ❌ |
| No browser opens | No default program for `.html` files | Open the path from the output window manually | ❌ |
| Long wait after **Investigate ->** | Many or deeply nested families | Pick fewer families per run | ✅ If Revit freezes |
| Revit feels slow after many runs | Many families opened in the background | Save and restart Revit | ✅ If it happens often |
| "Could not open: …" on a card | Revit couldn't open that family | Try opening it in the Family Editor yourself | ✅ If it opens fine there |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. The **category** and **family names** you picked
2. A **screenshot** of the report (or the report file itself), and of any error
3. Your **Revit version** (e.g. 2025)
4. The **model name**
5. **What you expected** to see, and what you actually got
