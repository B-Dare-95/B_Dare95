# Type Swapper

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Automations** panel → **Type Swapper**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Type Swapper** changes the type of many elements at once, across the **whole project**.

You pick a category (e.g. Doors), then build **swap pairs**: "every element of type **A** becomes type **B**". You can add several pairs and apply them all with one click.

| Step | What you choose |
|---|---|
| **Category** | One model category that has placed elements (e.g. Doors, Pipes, Walls) |
| **FROM type** | A type that is **currently placed** in the model |
| **TO type** | **Any loaded type** of the same category, placed or not |

> 💡 Think of it as Revit's *Select All Instances → In Entire Project* followed by changing the type in Properties, but for many types in one go.

📸 *[Screenshot: the Type Swapper window with a category selected and two swap rows]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on a selection or a view | It changes **every** placed element of the FROM type in the **whole project**. |
| Swap across categories | FROM and TO types always come from the **same** category. |
| Load new families | The TO list only shows types already loaded in the project. Load the family first. |
| Show annotation categories | Only **model** categories with placed elements are listed. |
| Refresh the lists after a swap | After **CONFIRM SWAP** the dropdowns still show the old lists. Click the category again (or reopen the tool) before a second round. |
| Ask for confirmation | **CONFIRM SWAP** applies the changes straight away. You can still undo (see [Section 7](#7-undoing)). |

---

## 3. Before you start

- [ ] A project is **open**.
- [ ] The **TO** family/type is already **loaded** in the project.
- [ ] You know which types you want to replace. Check with *Select All Instances → In Entire Project* if unsure.
- [ ] In a workshared model: the elements aren't **owned by someone else** (otherwise Revit can't change them).

---

## 4. How to use it

1. Click **Type Swapper**. The **Type Swapper — Bulk Family Type Replacement** window opens.
2. In the **CATEGORY** list on the left, click a category. Use the search box above the list to find it quickly.
3. A first swap row appears automatically. The status line at the bottom shows how many types are **in use** and how many are **available**.
4. In the row, pick a **FROM** type (left dropdown) and a **TO** type (right dropdown).
5. *(Optional)* Click **＋ Add Row** to add more pairs. Remove a row with **−**.
6. When the status line says **"_ swap pair(s) configured — ready to apply"**, click **CONFIRM SWAP**.
7. The status line reports the result (see [Section 8](#8-messages-you-may-see)). ✅
8. Close the window with its **X** when you're done.

📸 *[Screenshot: the status line after a successful swap]*

### Window controls

| Control | What it does |
|---|---|
| **Search box** (top left) | Filters the category list as you type. Any part of the name, upper/lower case doesn't matter. |
| **CATEGORY** list | Click a category to load its types. Picking another category **clears all rows**. |
| **FROM TYPE** (instances present) | Only types that have at least one placed element. Shown as *Family : Type*. |
| **TO TYPE** (any loaded type) | Every loaded type of that category. Shown as *Family : Type*. |
| **＋ Add Row** | Adds another FROM → TO row. Greyed out until a category with placed elements is picked. |
| **−** (end of a row) | Removes that row. |
| **Status line** (bottom left) | Shows counts, readiness and the result of the swap. |
| **CONFIRM SWAP** | Applies all valid rows. Greyed out until at least one row has both a FROM and a TO type. |

---

## 5. Good to know about rows

- A row with only FROM or only TO picked is **ignored**.
- A row where FROM and TO are the **same type** is ignored.
- If the **same FROM type** appears in several rows, the **last** row wins.
- The TO list can contain types from **other families** of the same category (e.g. swap one door family for another). Revit may refuse some of these changes. They're counted as "could not be changed".

---

## 6. After the swap

- The window stays open so you can read the result.
- The dropdowns are **not refreshed**. A FROM type you just swapped away is still listed. To start a new round, click the category again in the left list (this reloads the types), or close and reopen the tool.

---

## 7. Undoing

All changes from one **CONFIRM SWAP** are a single step in Revit's Undo list:

> ↩️ **Type Swapper — Bulk Swap**

Close the window first, then press **Ctrl + Z** (or use the Undo dropdown) once.

If you clicked **CONFIRM SWAP** twice, there are two Undo entries.

---

## 8. Messages you may see

All messages appear in the **status line** at the bottom of the window.

| Message | Why | What to do |
|---|---|---|
| 🔵 **"_ type(s) in use · _ type(s) available"** | You picked a category. | Build your rows. |
| 🔵 **"Select FROM and TO types for each row"** | Rows exist but none is complete yet. | Pick both types in at least one row. |
| 🔵 **"_ swap pair(s) configured — ready to apply"** | At least one row is complete. | Click **CONFIRM SWAP**. |
| 🟢 **"✓ _ element(s) swapped successfully."** | Every matching element was changed. | Nothing. Done. |
| 🟡 **"⚠ _ swapped, _ could not be changed."** | Revit refused some elements. | Check those elements by hand (see [Troubleshooting](#10-troubleshooting)). |
| 🟡 **"⚠ No valid swap pairs — check your selections."** | All rows are incomplete or have FROM = TO. | Fix the rows. |
| 🟡 **"⚠ No instances matched the selected FROM types."** | The FROM types have no placed elements any more (often after a previous swap). | Click the category again to reload the lists. |
| 🔴 **"❌ Transaction failed: …"** | Something unexpected stopped the whole swap. Nothing was changed. | Screenshot it and contact the author. |
| 🟡 **"← No placed instances found for this category. Select a different category."** (center of the window) | The category has elements, but none that use a type. | Pick another category. |
| 🟡 **"← No types loaded for this category."** (center of the window) | No types exist for the category. | Pick another category. |

---

## 9. FAQ

**Does it only change what's in my current view?**
No. It changes every element of the FROM type in the **whole project**.

**Can I swap Doors to Windows?**
No. FROM and TO are always in the same category.

**Why isn't my new family in the TO list?**
It isn't loaded in the project. Load it, then reopen the tool.

**Why is a type missing from the FROM list?**
FROM only lists types with at least one placed element. Unused types aren't listed.

**I swapped, and now the FROM dropdown still shows the old type.**
Normal. The lists don't refresh by themselves. Click the category again.

**Can I undo just one of the pairs?**
No. One click = one Undo step for all pairs together.

**Why are the dropdown texts hard to read?**
The dropdown text is dark on a dark background in some setups. Open the dropdown to read the list clearly. (Reported to the author.)

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| **＋ Add Row** greyed out | No category picked, or category has no usable types | Pick a category from the list | ❌ |
| **CONFIRM SWAP** greyed out | No row has both FROM and TO | Complete at least one row | ❌ |
| Category not in the list | No placed elements of that category, or it's an annotation category | Place at least one element first | ❌ |
| "_ could not be changed" | Revit refused those elements (e.g. owned by another user, or the TO type isn't compatible) | Try changing one of them by hand in Properties to see Revit's reason | ✅ If you can't tell why |
| Fewer elements changed than expected | Duplicate FROM rows (last wins), or FROM = TO in a row | Check your rows | ❌ |
| "No instances matched…" right after a swap | Lists weren't refreshed | Click the category again | ❌ |
| Red "Transaction failed" | Unexpected problem | Screenshot it | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your rows and the status line
2. The **category** and the **FROM / TO** types you used
3. Your **Revit version** (e.g. 2025)
4. The **model name**, and whether it's workshared
5. **What you expected** to change, and what actually changed
