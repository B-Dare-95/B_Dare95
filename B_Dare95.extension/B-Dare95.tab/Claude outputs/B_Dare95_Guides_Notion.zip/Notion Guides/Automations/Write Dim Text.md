# Dim Text

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Automations** panel → **Dim Text**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Dim Text** writes the same **Top**, **Bottom**, **Prefix** and/or **Suffix** text into many dimensions, one click per dimension.

You type the text once, then click dimensions one after another. Each one is updated **the moment you click it**. Press **Esc** when you're done.

> 💡 Like a rubber stamp: ink it once, then stamp as many dimensions as you like.

| Field in the tool | Revit dimension text it fills |
|---|---|
| **Top** | Text **above** the dimension value |
| **Bottom** | Text **below** the dimension value |
| **Prefix** | Text **before** the value |
| **Suffix** | Text **after** the value |

📸 *[Screenshot: the Dimension Text Writer window]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work on spot dimensions | Spot elevations / coordinates / slopes can't be picked. Linear, angular, radial, diameter and arc-length dimensions can. |
| Replace the dimension value | The measured value stays. The tool only adds text around it. |
| Work on a pre-selection or a box | Dimensions are picked **one click at a time**. |
| Append to existing text | A ticked field **replaces** what's there. An **empty** ticked field **clears** it. |
| Remember your text | Each run starts with empty fields. |

---

## 3. Before you start

- [ ] A view with the dimensions is **open and active**.
- [ ] You know which of the four texts you want to set, and which to leave alone.
- [ ] In a workshared model: the dimensions aren't **owned by someone else**.

---

## 4. How to use it

1. Click **Dim Text**. The **Dimension Text Writer** window opens, with the cursor in **Top**.
2. Type your text in the fields you need.
3. **Untick** the fields you want to leave unchanged.
4. Choose a mode under **Multi-segment dimensions**: **All segments** or **Picked segment only** (see [Section 5](#5-multi-segment-dimensions)).
5. Click **Start Picking** (or press **Enter**).
6. Click a dimension in the view. Its text changes right away. ✅
7. Keep clicking dimensions. The status bar (bottom left) shows **"Pick a dimension to write text (_ done) | ESC to finish"**.
8. Press **Esc** to finish.

### Window controls

| Control | What it does |
|---|---|
| **Tick box** next to a field | Ticked = this text is written. Unticked = this text is left untouched (the field greys out). |
| **Top / Bottom / Prefix / Suffix** fields | The text to write. An empty but ticked field **clears** that text. |
| **All segments** | On a dimension with several segments, every segment gets the text. *(Default)* |
| **Picked segment only** | Only the segment you click on gets the text. |
| **Start Picking** / **Enter** | Closes the window and starts picking. |
| **Cancel** / **Esc** / window **X** | Closes the window. Nothing happens. |

---

## 5. Multi-segment dimensions

A dimension string with several segments (e.g. a chain of grid dimensions) can be handled two ways:

| Mode | Result |
|---|---|
| **All segments** | Every segment in the string gets the same text. |
| **Picked segment only** | The tool uses the segment whose value text is **closest to where you clicked**. Click near the number of the segment you want. |

> 💡 For a dimension with only one segment, both modes do the same thing.

---

## 6. Undoing

Everything you do in **one picking session** (from **Start Picking** to **Esc**) is a single step in Revit's Undo list:

> ↩️ **Write Dimension Text**

Press **Ctrl + Z** once to undo all dimensions from that session.

> ⚠️ You can't undo just one dimension from inside the session. Finish with **Esc**, undo the whole session, and redo the ones you want.

---

## 7. Messages you may see

| Message | Why | What to do |
|---|---|---|
| 🟡 **"Check at least one property to write."** | You clicked **Start Picking** with every field unticked. | Tick at least one field. |
| 🟡 **"_ dimension(s) updated, _ failed:"** followed by a list of **Id _: …** lines | Revit refused to change some dimensions. Shown when you press **Esc**. The others were updated. | Note the IDs. Use **Manage → Select by ID** to find them and check them by hand. |
| 🔴 **"Rolled back - unexpected error:"** | Something unexpected happened. **All** changes from the session were cancelled. | Screenshot it and contact the author. |

If everything worked, there's **no message**. The tool just ends when you press **Esc**.

---

## 8. FAQ

**Can I pick spot elevations?**
No. Spot dimensions are filtered out. The cursor won't highlight them.

**What's the difference between an unticked field and an empty ticked field?**
Unticked = leave that text alone. Empty + ticked = **erase** that text.

**I picked the same dimension twice. Is that a problem?**
No. It just gets the same text again. It's counted twice in the "done" number.

**Can I pick dimensions in a different view during the session?**
Pick in the active view. Press **Esc** and start again in the other view.

**Does "Picked segment only" pick the wrong segment sometimes?**
It picks the segment whose number is closest to your click. Click right next to the number you want.

**The text didn't appear on my dimension.**
Check that the field was **ticked**. Also check the dimension's own text settings in Revit.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| Can't select a dimension | It's a spot dimension, or it's in a linked model | Only normal dimensions in this model can be picked | ❌ |
| Wrong segment changed | Clicked too far from the segment's number | Undo, then click closer to the number | ❌ |
| Text erased by mistake | A ticked field was empty | Undo. Untick fields you don't want to touch. | ❌ |
| "_ failed" list at the end | Revit refused some dimensions (e.g. owned by another user) | Select them by ID and try by hand | ✅ If the reason isn't clear |
| "Rolled back" message | Unexpected problem | Screenshot it | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with your text and mode
2. A **screenshot** of any message, including the IDs listed
3. Your **Revit version** (e.g. 2025)
4. The **model name** and the **view** you were in
5. **What you expected**, and what actually happened to the dimension
