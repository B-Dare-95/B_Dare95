# Unjoin Disjoint

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Warnings** panel → **Resolvers** dropdown → **Unjoin Disjoint**
> 🧩 **Works with:** Revit 2024 and newer (project files only)
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Unjoin Disjoint** clears Revit's warning:

> *"Highlighted elements are joined but do not intersect."*

This happens when two elements (e.g. a wall and a floor) were **joined** with *Join Geometry*, but one was later moved so they **no longer touch**. The join is useless, but it stays and causes the warning.

The tool reads **all** these warnings in the model and **unjoins** the reported elements. Nothing is deleted or moved.

> 💡 Think of it as cutting a string between two things that are no longer next to each other.

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Delete or move elements | It only **removes the join** between them. |
| Unjoin anything that isn't flagged | Only elements in the *joined but do not intersect* warning are touched. |
| Let you pick individual pairs | It processes **every** such warning in the model in one run. |
| Work in family files | Run it in a **project**. |

---

## 3. Before you start

- [ ] A **project** is open (not a family).
- [ ] In a workshared model: you've **synced / reloaded latest**, so the elements aren't held by other users.

---

## 4. How to use it

1. Click **Resolvers** → **Unjoin Disjoint**.
2. A window **"Unjoin Disjoint Elements"** says how many warnings and element pairs were found, and asks **"Unjoin them now?"**
3. Click **Yes** to go ahead, or **No** to stop. Nothing has changed yet.
4. The **pyRevit output window** opens and shows each pair as it's processed.
5. At the end, a **Summary** shows what was unjoined, skipped or failed. ✅

📸 *[Screenshot: the confirmation window]*

---

## 5. Reading the output window

| Line | Meaning |
|---|---|
| **✔ Unjoined [ID] ↔ [ID]** | The pair was unjoined. Click an ID to zoom to the element. |
| **– Skipped … already unjoined** | The pair wasn't joined (anymore). Nothing to do. |
| **– Skipped … no longer in the model** | One of the elements was deleted. |
| **✖ Failed … [reason]** | Revit refused to unjoin this pair. The run continues with the next pair. |
| **Summary** | Warnings matched, pairs processed, successfully unjoined, skipped, failed |
| **Failed pairs** | Each failed pair with its reason, plus a list of IDs to paste into **Manage → Inquiry → Select by ID** |
| **Skipped pairs** | Each skipped pair with its reason |
| **Warnings without a usable pair** | Warnings that reported fewer than two elements. They're left alone. |

> 💡 When one warning lists **more than two** elements, the tool checks **every pair** among them and unjoins the ones that are joined.

📸 *[Screenshot: the output window summary]*

---

## 6. Undoing

All unjoins are made as **one step**. Press **Ctrl + Z** once, or pick **Unjoin Disjoint Elements** from Revit's Undo list.

| You want to… | Do this |
|---|---|
| Stop before anything happens | Click **No** in the confirmation window |
| Undo everything | **Ctrl + Z** → **Unjoin Disjoint Elements** |

---

## 7. Messages you may see

🔵 **"No 'elements are joined but do not intersect' warnings found in this document."** (title *Nothing to unjoin*)
- **Why:** The model has no such warnings.
- **What to do:** Nothing.

🟡 **"Found [n] warning(s) resolving to [n] element pair(s). Unjoin them now?"**
- **Why:** The confirmation before changing anything.
- **What to do:** **Yes** to unjoin, **No** to stop.

🟡 **"This tool runs on project documents only."**
- **Why:** You ran it in a family file.
- **What to do:** Open a project.

🔴 **"The run was aborted and everything was rolled back:"** (with an error)
- **Why:** Something unexpected stopped the run. Nothing was changed.
- **What to do:** Screenshot it and contact the author.

---

## 8. FAQ

**Will my walls / floors look different afterwards?**
They don't touch anymore, so the join wasn't doing anything visible. The warning just goes away.

**Does it unjoin elements that really do overlap?**
It only works on elements listed in the *joined but do not intersect* warning. If a warning lists more than two elements, every joined pair among them is unjoined.

**Why did some pairs fail?**
Revit refused, for example because an element is borrowed by another user. Check the **Failed pairs** list.

**How do I find the failed elements?**
Copy the ID list under **Failed pairs**, then go to **Manage → Inquiry → Select by ID** and paste it.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check that the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| "No … warnings found" but Review Warnings shows some | The warning text is different | Compare the warning text exactly | ✅ If it's the same text |
| Pairs **failed** | Element borrowed by another user, or Revit refused | Read the reason. Sync and run again. | ✅ If it keeps failing |
| Warning still there after running | Pair failed or was skipped | Check the **Failed pairs** list | ❌ |
| "The run was aborted…" | Unexpected problem | Screenshot it | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the confirmation window
2. The **Summary** and **Failed pairs** sections from the output window
3. A screenshot of any **error**
4. Your **Revit version** (e.g. 2025)
5. The **model name**, and the **IDs** of elements that didn't behave as expected
