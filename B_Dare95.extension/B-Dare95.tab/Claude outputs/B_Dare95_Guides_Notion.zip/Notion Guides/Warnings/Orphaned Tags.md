# Orphaned Tags

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Warnings** panel → **Resolvers** dropdown → **Orphaned Tags**
> 🧩 **Works with:** Revit 2024 and newer (project files only)
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Orphaned Tags** finds tags that have **lost the element they're supposed to tag**, in **every view** of the model, and fixes them in one go.

For each broken tag it decides one of three things:

| Action | When | What happens |
|---|---|---|
| 🟢 **Re-attach** | The tagged element **still exists**, the tag just lost its link to it | The tag is connected to the element again |
| 🔴 **Delete** | The tagged element is **gone** | The tag is deleted |
| ⚪ **Skip** | The tool can't safely fix it (see [Section 6](#6-why-a-tag-is-skipped)) | The tag is left untouched and listed for you to check |

You see a **summary per tag category first**, and you choose which categories to fix. Nothing changes until you click **Fix Selected**.

> 💡 Think of it as a lost-and-found for tags: tags whose owner can still be found are returned to it, tags whose owner is gone are thrown away.

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Work in family files | Run it in a **project**. |
| Let you pick individual tags | You choose by **tag category** (e.g. *Door Tags*). All fixable tags in a ticked category are fixed. |
| Touch tags inside groups | They're **skipped**. Fix them by editing the group. |
| Touch tags owned by someone else | In workshared models, tags borrowed by another user are **skipped**. |
| Fix tags of unloaded links | If the tagged link isn't loaded, the tag is **skipped**. Load the link and run again. |
| Re-attach material tags | They're **skipped**. Re-attach them by hand. |
| Fix Room / Space / Area tags in non-plan views | They're **skipped** (e.g. room tags in sections). |
| Keep the old tag "as is" when re-attaching | Most re-attached tags are **replaced by a fresh tag** of the same type (see [Section 7](#7-what-re-attach-really-does)). |

---

## 3. Before you start

- [ ] A **project** is open (not a family).
- [ ] **Links** you tag into are **loaded**. Otherwise those tags are skipped.
- [ ] In a workshared model: you've **synced / reloaded latest**, so tags aren't held by other users.
- [ ] You've **saved** the model. The tool can delete many tags at once.

---

## 4. How to use it

1. Click **Resolvers** → **Orphaned Tags**.
2. A progress bar **"Scanning tags (… of …)"** appears while every tag in the model is checked. You can cancel it.
3. The **Orphaned Tag Fixer** window opens with the results.
4. Check the three counters at the top: **Re-attach**, **Delete**, **Skipped**.
5. In the table, **tick (Fix)** the categories you want fixed. Categories with something to fix are ticked already.
6. Choose how **re-attached tags** should be placed: **Move to element** or **Keep position + leader** (see [Section 5](#5-move-to-element-vs-keep-position--leader)).
7. *(Optional)* Click **Copy Report** to copy the full list to the clipboard.
8. Click **Fix Selected**.
9. A progress bar **"Fixing tags (… of …)"** runs.
10. A result window shows how many tags were re-attached, deleted or failed. ✅
11. If anything was skipped or failed, the **pyRevit output window** lists those tags. Click a tag **Id** there to zoom to it.

📸 *[Screenshot: the Orphaned Tag Fixer window]*

### Window controls

| Control | What it does |
|---|---|
| **Counters** (top) | Total tags to **Re-attach (element found)**, **Delete (element gone)** and **Skipped (left untouched)**, across all categories. |
| **Filter tag categories…** | Shortens the table as you type. |
| **Fix** tick box | Include this category in the fix. |
| **Tag Category** | e.g. *Door Tags*, *Room Tags*, *Multi-Category Tags*. |
| **Re-attach / Delete / Skipped** | How many tags of that category get each action. |
| **Views** | In how many views that category's broken tags were found. |
| **"Skipped: …" line** | Why tags were skipped, with counts (e.g. *3 Inside a group*). |
| **Move to element / Keep position + leader** | How re-attached regular tags are placed. |
| **Copy Report** | Copies a list of **every** broken tag (Tag Id, Category, View, Action, Reason) to the clipboard. Paste it into Excel. The button then reads **Copied ✓**. |
| **Cancel** | Closes the window. Nothing changes. |
| **Fix Selected** | Fixes the ticked categories. |

---

## 5. Move to element vs Keep position + leader

This choice applies to **regular tags** (door tags, pipe tags, multi-category tags…) that get re-attached.

| Option | Where the tag ends up |
|---|---|
| **Move to element** *(default)* | The tag moves **onto the element** (its insertion point, or the middle of its line, or the middle of its box). No leader. |
| **Keep position + leader** | The tag **stays where it was**, and a **leader** is drawn to the element. |

> ⚠️ **Room, Space and Area tags** ignore this choice. They're always **moved back inside** their room / space / area.

---

## 6. Why a tag is skipped

| Reason shown | What it means | What you can do |
|---|---|---|
| **Inside a group** | The tag belongs to a group | Edit the group and fix the tag by hand |
| **Owned by another user** | Another user has borrowed it | Ask them to sync and release, then run again |
| **Tagged link is not loaded** | The tagged element is in an unloaded link | Load the link, then run again |
| **Material tag - re-attach manually** | Material tags can't be re-attached by the tool | Re-tag the material by hand |
| **Not a plan view - fix manually** | A room / space / area tag in a section, elevation, etc. | Fix it by hand |

Tags can also **fail** during the fix (shown in the result and the output window):

| Reason shown | What it means |
|---|---|
| **Element is not visible in the tag's view** | The element exists, but can't be seen in that view, so the tag can't attach. The old tag is kept. |
| **Room / Space / Area is not shown in the tag's view** | Same idea for room / space / area tags. |
| **… has no location** / **Revit could not create the tag** | Revit refused. The old tag is kept. |

---

## 7. What "re-attach" really does

| Tag type | What the tool does |
|---|---|
| **Regular tags** | Creates a **new tag** of the **same type**, in the **same view**, with the same orientation, attached to the element. Then deletes the old one. |
| **Room / Space / Area tag that lost its room** | Creates a **new tag** of the same type at the room's / space's / area's point. Then deletes the old one. |
| **Room tag that sits outside its room** (no leader) | **Moves** the existing tag into the room. |

> ⚠️ Because most re-attached tags are **new tags**, anything you changed on the old tag itself (for example leader shape, or values typed into the tag's own properties) is **not carried over**. The tag also gets a new Element ID.

> 💡 Room tags placed **outside** their room **with a leader** are treated as intentional and left alone.

### When is a tag "deleted"?

- The tagged element **no longer exists** in the model (or in the link).
- A room / space / area tag whose room / space / area **no longer exists** or is **not placed**.

---

## 8. Undoing

All changes are made as **one step**. To undo everything, press **Ctrl + Z** once, or pick **Fix Orphaned Tags** from Revit's Undo list.

| You want to… | Do this |
|---|---|
| Close without changing anything | Click **Cancel** or the window's **X** |
| Stop the scan | Cancel the **Scanning tags** progress bar. Nothing has changed yet. |
| Undo the fix | **Ctrl + Z** → **Fix Orphaned Tags** |

---

## 9. Messages you may see

🔵 **"No orphaned tags found in this document."**
- **Why:** Every tag in the model is healthy.
- **What to do:** Nothing.

🟡 **"Run this in a project document, not a family."**
- **Why:** You ran it in a family file.
- **What to do:** Open a project and run it there.

🟡 **"Nothing to fix in the selected categories."**
- **Why:** You ticked only categories whose tags are all **skipped**, or ticked nothing.
- **What to do:** Tick a category with a **Re-attach** or **Delete** count above 0.

🟢 **Result window: "[n] re-attached · [n] deleted · [n] failed"**
- **Why:** The fix finished. A line per category gives the details.
- **What to do:** If it says *"Skipped and failed tags are listed in the pyRevit output window (click an Id to zoom to it)."*, check those tags in the output window.

🔴 **"The fix failed and was rolled back. Nothing was changed."** (with an error line)
- **Why:** Something unexpected stopped the run. All changes were cancelled.
- **What to do:** Screenshot the message and contact the author.

🔴 **"Revit did not commit the changes (status: …). Nothing was changed."**
- **Why:** Revit refused to accept the changes at the end.
- **What to do:** Screenshot the message and contact the author.

---

## 10. FAQ

**Does it only look at the current view?**
No. It checks **every tag in every view** of the model.

**Can I review the list before anything is deleted?**
Yes. The summary window shows everything first. Use **Copy Report** to get the full tag-by-tag list in Excel.

**Can I fix only some tags of a category?**
No. It's per category. Untick the category and fix those tags by hand if you need more control.

**Why did my tag move?**
You chose **Move to element**, or it's a room / space / area tag (those are always moved into their room).

**Why does a re-attached tag have a different Element ID?**
The tool replaces it with a fresh tag of the same type. See [Section 7](#7-what-re-attach-really-does).

**What happens to tags in categories I didn't tick?**
Nothing. They stay as they are.

**My room tag sits outside the room on purpose.**
Give it a **leader**. Room tags with a leader are left alone.

---

## 11. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check that the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| Scan takes long | Many tags in a big model | Wait, or cancel the progress bar | ✅ If Revit freezes |
| Many tags **skipped** | Groups, unloaded links, borrowed tags | Read the **"Skipped: …"** line | ❌ |
| Tag **failed**: element not visible in the view | Element hidden or outside the view | Unhide the element or adjust the view, then run again | ❌ |
| Tag ended up in the wrong spot | **Move to element** places it on the element's insertion point | Undo and run again with **Keep position + leader** | ❌ |
| A tag I wanted was deleted | Its element was deleted, or the room wasn't placed | Undo (**Ctrl + Z**) and check the element | ❌ |
| Re-attached tag lost its custom leader | It was replaced by a new tag | Adjust the leader by hand | ❌ |
| "The fix failed and was rolled back" | Unexpected problem | Screenshot it | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 12. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the Orphaned Tag Fixer window (counters and table)
2. The **Copy Report** text, pasted into an email or Excel file
3. A screenshot of any **error** or result message
4. Your **Revit version** (e.g. 2025)
5. The **model name**, and the **Id** of a tag that didn't behave as expected
