# Slightly Off Axis

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Warnings** panel → **Slightly Off Axis** dropdown → **Off Axis Grids** / **Off Axis Lines** / **Off Axis Sketch** / **Off Axis Walls**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What these tools do

Revit warns when something is **almost, but not exactly**, horizontal or vertical:

> *"… is slightly off axis and may cause inaccuracies."*

These tools find the elements Revit flagged with that warning and **straighten them** onto the nearest horizontal or vertical direction. There's one tool per kind of element:

| Tool | Fixes | How it straightens |
|---|---|---|
| **Off Axis Grids** | Grids | **Rotates** the grid around its start point |
| **Off Axis Lines** | Model lines and detail lines | **Rotates** the line around its start point |
| **Off Axis Walls** | Walls | **Rotates** the wall around the start of its location line |
| **Off Axis Sketch** | Lines **inside sketches** (floors, roofs, openings, filled regions…) | Edits the sketch and **moves the far end** of the line onto the axis. Connected sketch lines follow, so the outline stays closed. |

All four work on the **whole model**, show you how many elements were found, and **ask before changing anything**.

> 💡 Think of it as nudging a picture frame that's hanging a hair crooked until it's level.

---

## 2. What these tools do NOT do

| ❌ They do NOT… | What this means for you |
|---|---|
| Look for crooked elements on their own | They only act on elements **Revit already flags** with the *slightly off axis* warning. |
| Fix curved elements | Arcs and curves are ignored. Only straight elements are fixed. |
| Fix pinned grids, lines or walls | Pinned elements are **skipped** and listed. Unpin them first if you want them fixed. |
| Straighten everything that's flagged (Grids / Lines / Walls) | These three only rotate elements that are off by a **tiny** amount (less than about 0.006°). Anything further off is left as is. |
| Straighten real diagonals (Sketch) | **Off Axis Sketch** leaves lines alone if they're more than about **5°** off. |
| Use a rotated project north | Grids / Lines / Walls align to the model's own horizontal and vertical directions. **Off Axis Sketch** aligns to the sketch's own plane. |
| Hide Revit's warnings | If the change causes a new warning, Revit shows it as usual. |

---

## 3. Before you start

- [ ] A **project** is open.
- [ ] You're **not** in sketch mode or edit mode.
- [ ] Elements you want fixed are **not pinned**.
- [ ] In a workshared model: you've **synced / reloaded latest**, so the elements aren't held by other users.
- [ ] You've **saved** the model.

---

## 4. How to use Off Axis Grids / Lines / Walls

The three tools work the same way. Grids are used as the example.

1. Click **Slightly Off Axis** → **Off Axis Grids** (or **Lines** / **Walls**).
2. A window **"Align Off-Axis Grids"** says how many grids were found with the warning, and asks **"Proceed with fixing them?"**
3. Click **Yes** to fix, or **No** to stop. Nothing has changed yet.
4. Each grid is rotated around its start point onto the nearest horizontal or vertical direction.
5. The **pyRevit output window** lists every fixed or skipped element, and ends with a line like **"5 of 6 flagged grids were aligned."** ✅

📸 *[Screenshot: the "Align Off-Axis Grids" confirmation window]*

### Reading the output window

| Line | Meaning |
|---|---|
| **Fixed grid ID: [ID]** | Rotated onto the axis |
| **Skipped grid ID: [ID] - reason: element is pinned** | Not changed because it's pinned |
| **Skipped grid ID: [ID] - reason: [error]** | Revit refused the change |
| **[n] of [n] flagged grids were aligned.** | Final count |
| **[n] grids skipped (pinned).** / **[n] grids skipped (other errors) - see log above.** | Totals of skipped elements |

> ⚠️ An element can be **flagged** but **not aligned** and **not listed as skipped**. That happens when it's curved, or when it's off by more than the tiny amount these tools correct. Fix those by hand.

> 💡 **Off Axis Lines** may also count lines that live **inside sketches**. For sketch lines, use **Off Axis Sketch** instead.

---

## 5. How to use Off Axis Sketch

1. Click **Slightly Off Axis** → **Off Axis Sketch**.
2. A window **"Fix Off-Axis Sketch Lines"** says how many sketch lines were found, in how many elements, from how many warnings, and asks **"Proceed with the fix?"**
3. Click **Yes** to fix, or **No** to stop. Nothing has changed yet.
4. For each element, the tool opens its sketch, straightens the flagged lines, and finishes the sketch. The **start** of each line stays put, and the **far end** moves onto the axis.
5. A **"Done."** window shows the totals. The pyRevit output window lists each line. ✅

📸 *[Screenshot: the "Done." result window]*

### Reading the result

| Line in the "Done." window | Meaning |
|---|---|
| **Warnings matched** | *Line in Sketch* warnings found |
| **Off-axis sketch lines found** | Lines those warnings point to |
| **Lines aligned** | Lines straightened |
| **Lines skipped (no change)** | Curved, already straight, or more than about 5° off |
| **Lines with errors** | Lines that couldn't be changed |
| **Sketches processed** | Elements (floors, roofs…) whose sketch was visited |
| **Sketches with errors** | Sketches that couldn't be edited or finished. Their changes were cancelled. |

---

## 6. Which tool do I need?

Open **Manage → Review Warnings** and read the warning text:

| Warning mentions… | Use |
|---|---|
| A **grid** | **Off Axis Grids** |
| A **wall** | **Off Axis Walls** |
| A **line** (model or detail line) | **Off Axis Lines** |
| **"Line in Sketch"** | **Off Axis Sketch** |

---

## 7. Undoing

| Tool | Undo |
|---|---|
| **Off Axis Grids** | One step: **Ctrl + Z** → **Align Off-Axis Grids** |
| **Off Axis Lines** | One step: **Ctrl + Z** → **Align Off-Axis Lines** |
| **Off Axis Walls** | One step: **Ctrl + Z** → **Align Off-Axis Walls** |
| **Off Axis Sketch** | **One step per element** (floor, roof…) whose sketch was changed. Press **Ctrl + Z** several times, or use the **Undo** dropdown. |

To stop before anything happens, click **No** in the confirmation window.

---

## 8. Messages you may see

🔵 **"No grids with a 'slightly off axis' warning were found."** (also *lines* / *walls*)
- **Why:** No element of that kind carries the warning.
- **What to do:** Nothing, or try one of the other three tools.

🔵 **"No 'Line in Sketch is slightly off axis' warnings were found in the project."**
- **Why:** No sketch line carries the warning.
- **What to do:** Nothing, or try one of the other three tools.

🟡 **"[n] grid(s) found with a 'slightly off axis' warning. Proceed with fixing them?"** (also *line(s)* / *wall(s)*)
- **Why:** The confirmation before changing anything.
- **What to do:** **Yes** to fix, **No** to stop. Clicking **No** prints *"Operation cancelled by user."* in the output window.

🟡 **"Found [n] off-axis sketch line(s) in [n] element(s), from [n] warning(s). Proceed with the fix?"**
- **Why:** The confirmation for **Off Axis Sketch**.
- **What to do:** **Yes** to fix, **No** to stop.

🟢 **"Done." window** (Off Axis Sketch) or **"[n] of [n] flagged … were aligned."** (output window)
- **Why:** The tool finished.
- **What to do:** Check the skipped and error counts.

🟡 **Revit's own warnings after Off Axis Sketch**
- **Why:** Finishing a sketch can trigger normal Revit warnings. The tool doesn't hide them.
- **What to do:** Read them as you would after editing a sketch by hand.

🔴 **A pyRevit error window**, or **"Transaction rolled back due to: …"** in the output window
- **Why:** Something unexpected happened. The changes were cancelled.
- **What to do:** Screenshot it and contact the author.

---

## 9. FAQ

**Will the element move a lot?**
No. The correction is tiny. Grids, lines and walls turn around their start point, so the far end shifts very slightly. In sketches, only the far end of the line moves.

**Why were some flagged elements not fixed?**
They may be pinned, curved, or further off axis than the tool corrects. Grids / Lines / Walls only correct very small angles. **Off Axis Sketch** skips lines more than about 5° off, to protect real diagonals.

**Can I fix only some of them?**
No. Each tool fixes **all** flagged elements of its kind. Pin the ones you want to keep as they are, then run the tool.

**Does it work in my project with a rotated True North?**
Yes. It straightens to the model's own horizontal and vertical directions (the ones you see with Project North), not to True North.

**Does Off Axis Sketch keep my floor outline closed?**
Yes. The connected line follows the moved end, so the loop stays closed.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the buttons | B-Dare95 tab missing or not loaded | Restart Revit. Check that the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| "No … found" but Review Warnings shows the warning | Wrong tool for that element, or Revit isn't in English | Check [Section 6](#6-which-tool-do-i-need) | ✅ If it's the right tool |
| "0 of [n] … were aligned" | Elements are further off than the tool corrects, or curved | Fix by hand (Rotate / Align) | ✅ If many are affected |
| Skipped: element is pinned | Element is pinned | Unpin it, then run again | ❌ |
| Off Axis Lines reports errors | It may have picked up sketch lines | Run **Off Axis Sketch** for those | ✅ If errors remain |
| **Sketches with errors** above 0 | The sketch couldn't be edited (e.g. borrowed by another user) | Sync, then run again. Or fix in sketch mode by hand. | ✅ If it keeps failing |
| Warning still there after running | Element was skipped or not corrected | Check the output window | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. **Which tool** you used (Off Axis Grids, Lines, Sketch or Walls)
2. A **screenshot** of the confirmation window and of the output window or **Done.** window
3. A screenshot of the **warning text** from Review Warnings
4. Your **Revit version** (e.g. 2025) and **language** of Revit
5. The **model name**, and the **ID** of an element that wasn't fixed
