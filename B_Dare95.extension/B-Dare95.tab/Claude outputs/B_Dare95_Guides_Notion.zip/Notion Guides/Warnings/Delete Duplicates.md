# Delete Duplicates

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Warnings** panel → **Resolvers** dropdown → **Delete Duplicates**
> 🧩 **Works with:** Revit 2024 and newer (project files only)
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Delete Duplicates** clears Revit's warning:

> *"There are identical instances in the same place."*

It reads **all** these warnings in the model, finds each set of duplicates, and **keeps one element per set**: the **oldest** one (the lowest Element ID). All the others are **deleted**.

If the same set is reported in several warnings (e.g. three identical chairs → three warnings), it's treated as **one set**, so exactly **one** element survives.

> 💡 Think of it as stacking identical plates: you keep the bottom one (the first one placed) and remove the copies on top.

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Look for duplicates on its own | It only acts on elements **Revit already flags** with the *identical instances* warning. |
| Let you choose which copy to keep | It always keeps the **lowest Element ID**. It doesn't compare parameter values. |
| Handle rebar, fabric sheets or points | Only the standard *identical instances* warning is resolved. |
| Delete elements borrowed by others | In workshared models, elements owned by another user are **skipped**. |
| Respect pins | **Pinned duplicates are unpinned and deleted.** The kept element is not touched. |
| Work in family files | Run it in a **project**. |

---

## 3. Before you start

- [ ] A **project** is open (not a family).
- [ ] You've **saved** the model. This tool **deletes elements**.
- [ ] In a workshared model: you've **synced / reloaded latest**, so the duplicates aren't held by other users.
- [ ] *(Optional)* You've looked at the duplicates in **Manage → Review Warnings**. If the **newer** copy is the one with the right data, fix that by hand first.

---

## 4. How to use it

1. Click **Resolvers** → **Delete Duplicates**.
2. A confirmation window **"Delete Identical Instances"** tells you how many warnings, duplicate groups and elements were found.
3. Click **Yes** to delete, or **No** to stop. Nothing has changed yet.
4. The **pyRevit output window** opens and shows the progress, one group at a time.
5. At the end, a **Summary** shows what was deleted and what was skipped. ✅

📸 *[Screenshot: the confirmation window]*

---

## 5. What gets deleted

| Situation | What happens |
|---|---|
| Normal duplicate | **Deleted** |
| Pinned duplicate | **Unpinned, then deleted** (marked *"was pinned"* in the report) |
| Duplicate owned by another user | **Skipped** (*"owned by '[name]'"*) |
| Revit refuses the delete (e.g. element in a group) | **Skipped**, with Revit's reason. *"member of group '[name]'"* is added when it's in a group. |
| Element already gone | **Skipped** (*"no longer in the model"*), or noted as *"already removed with a previous deletion"* |
| The oldest element of each set | **Kept**, untouched |

> ⚠️ **Dependent elements:** when Revit deletes an element, it also deletes things that depend on it (for example its tags or elements hosted on it). The report shows this as **[+n dependent element(s)]**.

> 💡 A skipped element doesn't stop the run. The tool carries on with the next one.

---

## 6. Reading the output window

| Line | Meaning |
|---|---|
| **⚑ Keeping [ID] – [Category: Name]** | The survivor of this group |
| **✔ Deleted [ID] – …** | Deleted. *(was pinned)* and *[+n dependent element(s)]* may follow. |
| **✖ Skipped [ID] – [reason]** | Not deleted, with the reason |
| **Summary** | Warnings matched, duplicate groups, elements kept, deleted, unpinned first, removed as dependents, skipped |
| **Failed deletions** | Each skipped element with its reason, plus a comma-separated list of IDs to paste into **Manage → Inquiry → Select by ID** |
| **Deleted element IDs** | Every deleted element |
| **Warnings without a usable pair** | Warnings that reported fewer than two elements. They're left alone. |

📸 *[Screenshot: the output window summary]*

---

## 7. Undoing

All deletions are made as **one step**. Press **Ctrl + Z** once, or pick **Delete Identical Instances** from Revit's Undo list. This also brings back the pins.

| You want to… | Do this |
|---|---|
| Stop before anything happens | Click **No** in the confirmation window |
| Undo everything | **Ctrl + Z** → **Delete Identical Instances** |

---

## 8. Messages you may see

🔵 **"No 'identical instances in the same place' warnings found in this document."** (title *Nothing to delete*)
- **Why:** The model has no such warnings.
- **What to do:** Nothing.

🟡 **"Found [n] warning(s) resolving to [n] duplicate group(s). [n] element(s) will be deleted, keeping the oldest ID in each group. Proceed?"**
- **Why:** The confirmation before deleting.
- **What to do:** **Yes** to delete, **No** to stop.

🟡 **"This tool runs on project documents only."**
- **Why:** You ran it in a family file.
- **What to do:** Open a project.

🔴 **"The run was aborted and everything was rolled back:"** (with an error)
- **Why:** Something unexpected stopped the run. Nothing was deleted.
- **What to do:** Screenshot it and contact the author.

---

## 9. FAQ

**Which copy is kept?**
The one with the **lowest Element ID**, which is normally the one placed first.

**What if the newer copy has the correct parameters?**
The tool doesn't compare data. Delete the wrong copy by hand first, or copy the values over, then run the tool.

**It deleted a pinned element!**
Yes, pinned **duplicates** are unpinned and deleted on purpose. The report marks them *(was pinned)*. **Ctrl + Z** brings them back.

**Why were some elements skipped?**
Usually they're owned by another user or inside a group. Check the **Failed deletions** list in the output window.

**How do I find the skipped elements?**
Copy the ID list under **Failed deletions**, then go to **Manage → Inquiry → Select by ID** and paste it.

**The warning is still there after running.**
Check the **Skipped** list. Those duplicates weren't deleted.

---

## 10. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check that the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| "No … warnings found" but Review Warnings shows some | Different warning (e.g. rebar or points duplicates) | Compare the warning text exactly | ✅ If it's the same text |
| Skipped: *owned by …* | Element borrowed by another user | Ask them to sync and release, then run again | ❌ |
| Skipped: *member of group* | Elements inside groups can't be deleted this way | Edit the group and delete the copy by hand | ❌ |
| More elements disappeared than expected | Dependent elements (tags, hosted elements) went with the duplicate | Check *[+n dependent element(s)]* in the report. Undo if needed. | ❌ |
| The wrong copy was kept | Tool always keeps the lowest ID | Undo, fix by hand, run again | ❌ |
| "The run was aborted…" | Unexpected problem | Screenshot it | ✅ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 11. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the confirmation window
2. The **Summary** and **Failed deletions** sections from the output window
3. A screenshot of any **error**
4. Your **Revit version** (e.g. 2025)
5. The **model name**, and the **IDs** of elements that didn't behave as expected
