# Wipe Unplaced Elements

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Warnings** panel → **Resolvers** dropdown → **Wipe Unplaced Elements**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🏷️ **Version:** 1.0.0
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

**Wipe Unplaced Elements** deletes **unplaced** Rooms, Areas and MEP Spaces from the model.

An "unplaced" element exists in the model (you see it in schedules as *Not Placed*) but isn't placed in any plan. They pile up when rooms are deleted from a plan but not from the model.

You tick which categories to clean, see how many will go, confirm, and they're deleted.

| Category | Counted as unplaced when… |
|---|---|
| **Rooms** | It has no location (not placed in any plan) |
| **Areas** | Its **Level** has no value |
| **MEP Spaces** | It has no location (not placed in any plan) |

> 💡 Think of it as emptying the drawer of room labels that were never stuck on a wall.

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Delete placed rooms | Rooms that are placed are kept, even if they're **Not Enclosed** or **Redundant**. |
| Let you pick individual rooms | All unplaced elements in a ticked category are deleted. |
| Show which rooms will be deleted | You see **counts only**. Check names in a schedule first if needed. |
| Touch other categories | Only Rooms, Areas and MEP Spaces. |

---

## 3. Before you start

- [ ] You've **saved** the model. This tool **deletes elements**.
- [ ] *(Recommended)* You've checked a **Room / Area / Space schedule** for *Not Placed* items you might still want to re-place (their names and numbers will be lost).
- [ ] In a workshared model: you've **synced / reloaded latest**, so the elements aren't held by other users.

---

## 4. How to use it

1. Click **Resolvers** → **Wipe Unplaced Elements**.
2. The **Wipe Unplaced Elements** window opens.
3. **Tick** the categories you want to clean: **Rooms**, **Areas**, **MEP Spaces**.
4. Under each ticked box, a line shows how many unplaced elements were found (e.g. *✔ 12 unplaced Rooms found*).
5. Click **OK**.
6. The **Confirm Deletion** window lists what will be **permanently deleted** and the total.
7. Click **OK** to delete, or **Cancel** to stop. Nothing has changed yet.
8. A message shows how many were **Deleted** and how many **Failed**. ✅

📸 *[Screenshot: the Wipe Unplaced Elements window with Rooms ticked]*

### Window controls

| Control | What it does |
|---|---|
| **Rooms / Areas / MEP Spaces** tick boxes | Choose what to clean. The count appears when you tick a box. |
| **✔ [n] unplaced … found** | That many will be deleted for this category. |
| **⚠ No unplaced … found** | Nothing to delete in this category. |
| **Cancel** / window **X** | Closes the window. Nothing changes. |
| **OK** | Goes to the confirmation step. |

---

## 5. Undoing

All deletions are made as **one step**. Press **Ctrl + Z** once, or pick **Wipe Unplaced Elements** from Revit's Undo list.

| You want to… | Do this |
|---|---|
| Stop before anything happens | Click **Cancel** in either window |
| Undo everything | **Ctrl + Z** → **Wipe Unplaced Elements** |

---

## 6. Messages you may see

🟡 **"The following unplaced elements will be permanently deleted: … Total: [n] element(s). Do you want to proceed?"** (title *Confirm Deletion*)
- **Why:** The last check before deleting.
- **What to do:** **OK** to delete, **Cancel** to stop.

🔵 **"No categories were selected. Nothing to purge."**
- **Why:** You didn't tick anything, **or** the categories you ticked have no unplaced elements.
- **What to do:** Nothing, or tick a category that shows *✔ … found*.

🟢 **"Operation complete. ✔ Deleted : [n] ⚠ Failed : [n]"**
- **Why:** The tool finished.
- **What to do:** If **Failed** is above 0, some elements couldn't be deleted (see [FAQ](#7-faq)).

🔴 **A pyRevit error window**
- **Why:** Something unexpected happened.
- **What to do:** Screenshot it and contact the author.

---

## 7. FAQ

**Will it delete rooms that show "Not Enclosed"?**
No. Those are placed. Only rooms with no placement at all are deleted.

**Can I see which rooms will be deleted?**
Not in the tool. Make a Room schedule and look for *Not Placed* before running it.

**Why did some fail?**
Usually because they're borrowed by another user or are in a group. The tool doesn't list which ones. Check your schedule for remaining *Not Placed* items.

**I deleted rooms I needed.**
Press **Ctrl + Z** right away. All deletions undo together.

**Why does it say "No categories were selected" when I ticked Rooms?**
Because there were no unplaced rooms to delete. The message is shown whenever there's nothing to delete.

---

## 8. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check that the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| Count is 0 but schedule shows *Not Placed* | Different idea of "unplaced" (e.g. areas still have a Level) | Compare with your schedule | ✅ |
| Count for **Areas** looks far too high | Areas may be detected by the wrong rule in your setup | **Cancel**, don't delete | ✅ Right away |
| **Failed** above 0 | Element borrowed by another user, or in a group | Sync, then run again | ✅ If it keeps failing |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 9. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the window with the counts, and of the **Confirm Deletion** window
2. A screenshot of the final message (Deleted / Failed)
3. Your **Revit version** (e.g. 2025) and **language** of Revit
4. The **model name**
5. What you **expected** to be deleted, and what actually was
