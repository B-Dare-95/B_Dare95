# Shaft Boundary Cleanup

> 📍 **Where to find it:** Revit ribbon → **B-Dare95** tab → **Warnings** panel → **Resolvers** dropdown → **Shaft Boundary Cleanup**
> 🧩 **Works with:** Revit 2024 and newer
> 👤 **Tool author:** Mohamed Bedair — [contact email / Teams]
> 🗓️ **Last updated:** [Date]

---

## 1. What this tool does

A **Shaft Opening** sketch has two kinds of lines:

- **Boundary lines**: the outline of the shaft (the hole).
- **Symbolic lines**: extra lines that show in plan, like the **X** across the shaft.

Sometimes symbolic lines are drawn **right on top of the boundary**, doubling the outline. **Shaft Boundary Cleanup** removes those **symbolic lines that sit on the boundary** and **keeps** the rest (e.g. the X diagonals).

You choose the shafts by **dragging a box** in the view.

> 💡 Think of it as erasing pencil lines someone traced over the edge of a hole, while leaving the X drawn inside it.

📸 *[Screenshot: a shaft before and after, with the X kept]*

---

## 2. What this tool does NOT do

| ❌ It does NOT… | What this means for you |
|---|---|
| Ask for confirmation | As soon as you finish the box, the lines are **deleted**. Use **Ctrl + Z** if needed. |
| Change the shaft's boundary | The outline (the hole itself) is **never** deleted or moved. |
| Delete symbolic lines that aren't on the boundary | Diagonals, the X, and any line inside the shaft are kept. |
| Delete lines that only partly touch the boundary | A line is removed only if it lies **fully** on the boundary (within about 1.5 mm). |
| Touch lines with other line styles | Only symbolic lines using the default **&lt;Lines&gt;** style inside the shaft sketch are checked. |
| Select anything other than shafts | The box only picks **Shaft Openings**. Walls, floors etc. are ignored. |

---

## 3. Before you start

- [ ] A **plan view** (or any view) is open where the shafts are **visible**.
- [ ] You're **not** in sketch mode.
- [ ] In a workshared model: the shafts aren't borrowed by someone else.
- [ ] You've **saved** the model. Lines are deleted without a confirmation step.

---

## 4. How to use it

1. Click **Resolvers** → **Shaft Boundary Cleanup**.
2. The status bar says **"Drag a rectangle across the shaft openings to clean."**
3. **Drag a box** around the shafts you want to clean. Only Shaft Openings are picked up.
4. The tool cleans each shaft. Pinned lines are unpinned and removed.
5. A **"Clean Shaft Boundary Lines"** window shows the results. ✅

> 💡 To stop before step 3, press **Esc**. The tool ends quietly and nothing changes.

---

## 5. Reading the result

| Line in the result window | Meaning |
|---|---|
| **Shafts selected** | Shaft Openings caught by your box |
| **Symbolic lines found** | All &lt;Lines&gt; symbolic lines in those shafts |
| **Boundary-clashing lines removed** | Lines that sat on the boundary and were **deleted** |
| **Symbolic lines kept (e.g. X)** | Symbolic lines left in place (found minus removed) |
| **Shafts skipped** | Shafts the tool couldn't read (no boundary or sketch found). Nothing changed there. |
| **Shafts with errors** | Shafts where something went wrong. Nothing changed there. |
| **Lines with errors** | Lines on the boundary that **couldn't** be deleted |

📸 *[Screenshot: the "Clean Shaft Boundary Lines" result window]*

---

## 6. Undoing

Each cleaned shaft is a **separate step** in Revit's Undo list, so you may need to press **Ctrl + Z** several times (once per cleaned shaft).

| You want to… | Do this |
|---|---|
| Stop before anything happens | Press **Esc** while dragging the box |
| Undo one shaft | **Ctrl + Z** once |
| Undo all shafts | Open the **Undo** dropdown and go back to before the tool's entries |

---

## 7. Messages you may see

🟡 **"No shaft openings were inside the selection rectangle."**
- **Why:** Your box didn't catch any Shaft Opening.
- **What to do:** Run again and draw a bigger box. Check that the shafts are visible in the view.

🟢 **"Done." with the counts**
- **Why:** The tool finished. See [Section 5](#5-reading-the-result).
- **What to do:** If **Lines with errors** or **Shafts with errors** is above 0, check those shafts by hand.

🔴 **A pyRevit error window**
- **Why:** Something unexpected happened.
- **What to do:** Screenshot it and contact the author.

---

## 8. FAQ

**Will it delete the X in my shaft?**
No. The X diagonals don't lie on the boundary, so they're kept.

**Does it change the shaft's size or shape?**
No. Boundary lines are never touched.

**I have a line that runs along half of the boundary edge and then into the shaft. Is it deleted?**
No. Only lines that lie **completely** on the boundary are removed.

**Can I preview what will be deleted?**
No. Run it, check the result, and press **Ctrl + Z** if you don't like it.

**Why was a shaft skipped?**
The tool couldn't find that shaft's sketch or outline. Check it by editing the shaft sketch yourself.

**Does it work on curved shafts?**
It checks any line or arc against the boundary, so curved edges are handled the same way.

---

## 9. Troubleshooting

| Symptom | Likely cause | What you can check | Contact author? |
|---|---|---|---|
| Can't find the button | B-Dare95 tab missing or not loaded | Restart Revit. Check that the **B-Dare95** tab is on the ribbon. | ✅ If it's still missing |
| No shafts picked up | Shafts hidden in the view, or box too small | Check visibility of **Shaft Openings**. Draw a bigger box. | ❌ |
| **0** lines removed | No symbolic lines lie fully on the boundary, or they use another line style | Edit the shaft sketch and look at the lines | ❌ |
| **Lines with errors** above 0 | Revit refused the delete (e.g. shaft borrowed by another user) | Sync, then run again. Or delete by hand in sketch mode. | ✅ If it keeps failing |
| **Shafts skipped** above 0 | Shaft sketch couldn't be read | Edit the shaft sketch by hand | ✅ If many shafts are skipped |
| Many Undo steps | One step per shaft | Use the **Undo** dropdown | ❌ |
| Red pyRevit error window | Unexpected problem | Screenshot it | ✅ |

---

## 10. Contact the author

If your problem isn't solved by the steps above, **please don't try to fix the tool yourself**. Contact:

> 👤 **Mohamed Bedair**
> ✉️ [email] · 💬 [Teams / chat]

**Please include:**

1. A **screenshot** of the result window
2. A screenshot of a shaft that didn't behave as expected, ideally in **sketch mode**
3. Your **Revit version** (e.g. 2025)
4. The **model name**, the **view**, and the shaft's **Element ID**
